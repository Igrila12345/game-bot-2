'use strict';

const C = require('./constants');

function distanceKm(x1, y1, x2, y2) {
  return Math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2);
}

function nextFactoryPrice(currentCount) {
  return Math.round(C.FACTORY_BASE_PRICE * Math.pow(C.FACTORY_PRICE_GROWTH, currentCount));
}

// Активные (не заблокированные) заводы = всего заводов - сумма заблокированных - заводы в производстве (учитывается отдельно вызывающим кодом)
function sumBlocked(blockedFactories) {
  if (!blockedFactories || !Array.isArray(blockedFactories)) return 0;
  const now = Date.now();
  return blockedFactories
    .filter((b) => new Date(b.unblock_at).getTime() > now)
    .reduce((sum, b) => sum + b.count, 0);
}

function isVipActive(player) {
  return !!(player && player.vip_until && new Date(player.vip_until) > new Date());
}

function incomePerHour(player, factoriesInProduction = 0) {
  const blocked = sumBlocked(player.blocked_factories);
  const normalFactories = player.factories - player.gold_mine_count;
  const goldFactories = player.gold_mine_count;
  // Считаем усреднённо: доход пропорционален доле активных заводов
  const totalActive = Math.max(player.factories - blocked - factoriesInProduction, 0);
  const activeRatio = player.factories > 0 ? totalActive / player.factories : 0;
  let income =
    normalFactories * C.FACTORY_INCOME_PER_HOUR * activeRatio +
    goldFactories * C.FACTORY_INCOME_PER_HOUR * C.GOLD_MINE_MULTIPLIER * activeRatio;

  // Научные центры — не подвержены блокировке/производству, доход стабильный
  const scienceCenters = player.science_centers || 0;
  income += scienceCenters * C.SCIENCE_INCOME_PER_HOUR;

  const radiationActive = player.radiation_until && new Date(player.radiation_until) > new Date();
  if (radiationActive) income *= 1 - C.RADIATION_INCOME_PENALTY;

  // VIP: +25% к пассивному доходу
  if (isVipActive(player)) income *= 1 + C.VIP_INCOME_BONUS;

  if (player.factories <= 0 && scienceCenters <= 0) return 0;
  return Math.round(income);
}

function formatNumber(n) {
  return Math.round(n).toLocaleString('ru-RU');
}

function formatDuration(ms) {
  if (ms <= 0) return '0 сек';
  // Меньше минуты — показываем секунды, а не округлённые "0 мин" (это вводило в заблуждение:
  // бот писал "ждите" и тут же "осталось 0 мин", будто ждать не нужно).
  if (ms < 60000) {
    const totalSeconds = Math.max(1, Math.round(ms / 1000));
    return `${totalSeconds} сек`;
  }
  const totalMinutes = Math.round(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const parts = [];
  if (hours > 0) parts.push(`${hours} ч`);
  if (minutes > 0 || hours === 0) parts.push(`${minutes} мин`);
  return parts.join(' ');
}

function formatHours(hoursFloat) {
  if (Number.isInteger(hoursFloat)) return `${hoursFloat} ч`;
  return `${hoursFloat} ч`;
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pickRandom(arr, count) {
  const copy = [...arr];
  const result = [];
  while (copy.length && result.length < count) {
    const idx = Math.floor(Math.random() * copy.length);
    result.push(copy.splice(idx, 1)[0]);
  }
  return result;
}

// Возвращает наивысший достигнутый скилл-тир по количеству заводов (или null, если ни один не достигнут)
function getSkillTier(factories) {
  let best = null;
  for (const tier of C.SKILL_TIERS) {
    if (factories >= tier.factories) best = tier;
  }
  return best;
}

// Текущий лимит заводов игрока с учётом купленных расширений
function currentFactoryLimit(factoryLimitLevel) {
  const level = factoryLimitLevel || 0;
  const row = C.FACTORY_LIMIT_LEVELS.find((l) => l.level === level) || C.FACTORY_LIMIT_LEVELS[0];
  return row.limit;
}

// Текущий лимит научных центров игрока с учётом купленных расширений
function currentScienceLimit(scienceLimitLevel) {
  const level = scienceLimitLevel || 1;
  const row = C.SCIENCE_LIMIT_LEVELS.find((l) => l.level === level) || C.SCIENCE_LIMIT_LEVELS[0];
  return row.limit;
}

module.exports = {
  distanceKm,
  nextFactoryPrice,
  sumBlocked,
  isVipActive,
  incomePerHour,
  formatNumber,
  formatDuration,
  formatHours,
  randomInt,
  pickRandom,
  getSkillTier,
  currentFactoryLimit,
  currentScienceLimit,
};
