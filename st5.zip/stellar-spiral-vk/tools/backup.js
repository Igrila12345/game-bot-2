'use strict';
/* Резервная копия базы: согласованный снимок SQLite (VACUUM INTO) даже во время работы игры, сжатие gzip, ротация.
   Запуск: node tools/backup.js   (по расписанию его вызывает служба stellar-backup.timer)
   Переменные: BACKUP_DIR (по умолчанию ./backups), BACKUP_KEEP (сколько копий хранить, 14),
   BACKUP_HOOK (команда, которой передаётся путь к копии, например для отправки на другой сервер). */
const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib'),cp=require('node:child_process');
const {DatabaseSync}=require('node:sqlite');
const {parseEnv,readConfig}=require('../server.js');

const root=path.join(__dirname,'..');
let fileEnv={};try{fileEnv=parseEnv(fs.readFileSync(path.join(root,'.env'),'utf8'));}catch(e){}
const cfg=readConfig(Object.assign({},fileEnv,process.env));
const dir=path.resolve(root,process.env.BACKUP_DIR||fileEnv.BACKUP_DIR||'backups');
const keep=Math.max(1,+(process.env.BACKUP_KEEP||fileEnv.BACKUP_KEEP)||14);
const hook=process.env.BACKUP_HOOK||fileEnv.BACKUP_HOOK||'';

if(!fs.existsSync(cfg.dbPath)){console.error('База не найдена: '+cfg.dbPath);process.exit(1);}
fs.mkdirSync(dir,{recursive:true});
const d=new Date(),p2=n=>String(n).padStart(2,'0');
const stamp=d.getFullYear()+p2(d.getMonth()+1)+p2(d.getDate())+'-'+p2(d.getHours())+p2(d.getMinutes())+p2(d.getSeconds());
const raw=path.join(dir,'stellar-'+stamp+'.db'),gz=raw+'.gz';

const db=new DatabaseSync(cfg.dbPath);
db.exec("VACUUM INTO '"+raw.replace(/'/g,"''")+"'");
db.close();
fs.writeFileSync(gz,zlib.gzipSync(fs.readFileSync(raw),{level:9}));
fs.unlinkSync(raw);
console.log('Копия создана: '+gz+' ('+fs.statSync(gz).size+' байт)');

const old=fs.readdirSync(dir).filter(f=>/^stellar-\d{8}-\d{6}\.db\.gz$/.test(f)).sort().reverse().slice(keep);
for(const f of old){fs.unlinkSync(path.join(dir,f));console.log('Удалена старая копия: '+f);}

if(hook){
  try{cp.execFileSync('/bin/sh',['-c',hook+' "$1"','backup-hook',gz],{stdio:'inherit',timeout:10*60*1000});console.log('Команда BACKUP_HOOK выполнена');}
  catch(e){console.error('BACKUP_HOOK завершилась с ошибкой: '+e.message);process.exit(2);}
}
