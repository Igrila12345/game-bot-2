#!/bin/bash
# Показывает, какую базу использует игра, и все найденные на сервере файлы stellar.db (размер, дата, число игроков).
# Нужно, если после перезапуска пропали игроки: обычно игру запускали из другой папки и появилась вторая база.
cd "$(dirname "$0")/.." || exit 1
echo "Игра использует базу:"
node -e "const fs=require('fs');const {readConfig,parseEnv}=require('./server.js');let e={};try{e=parseEnv(fs.readFileSync('.env','utf8'))}catch(x){};console.log('  '+readConfig(e).dbPath)" 2>/dev/null
echo
echo "Все найденные базы:"
find / -name 'stellar.db' -not -path '/proc/*' 2>/dev/null | while read -r f; do
  n=$(node -e "const {DatabaseSync}=require('node:sqlite');try{const d=new DatabaseSync(process.argv[1],{readOnly:true});console.log(d.prepare('SELECT COUNT(*) c FROM players').get().c)}catch(e){console.log('?')}" "$f" 2>/dev/null)
  echo "  $f | $(stat -c '%y' "$f" | cut -c1-16) | $(stat -c %s "$f") байт | игроков: $n"
done
