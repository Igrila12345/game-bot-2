'use strict';
/**
 * Обфускатор клиентского кода без внешних зависимостей (парсер acorn лежит в tools/vendor).
 * Что делает:
 *   1. Переименовывает все локальные переменные, параметры и функции (с учётом областей видимости).
 *   2. Выносит строки в зашифрованную таблицу (XOR + base64), в коде остаются вызовы декодера.
 *   3. Удаляет комментарии и лишние пробелы.
 * Что не делает: имена свойств (obj.name) остаются, глобальные имена Core и Sign остаются.
 * Это защита от копирования «в лоб», а не криптография: код всё равно выполняется в браузере игрока.
 */
const acorn=require('./vendor/acorn.js');
const crypto=require('node:crypto');

const OPTS={ecmaVersion:2022,sourceType:'script'};
const SKIP=new Set(['type','start','end','loc','range','_scope','_sh','raw','value_']);

function prng(seedStr){
  let a=crypto.createHash('sha256').update(seedStr).digest().readUInt32LE(0);
  return()=>{a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};
}
const isNode=v=>v&&typeof v==='object'&&typeof v.type==='string';
function forEachChild(node,fn){
  for(const k of Object.keys(node)){
    if(SKIP.has(k))continue;
    const v=node[k];
    if(Array.isArray(v)){for(const x of v)if(isNode(x))fn(x,k);}
    else if(isNode(v))fn(v,k);
  }
}

/* ---------- области видимости ---------- */
class Scope{
  constructor(kind,parent,keep){this.kind=kind;this.parent=parent;this.vars=new Map();this.keep=!!keep;}
  declare(name){let b=this.vars.get(name);if(!b){b={name,newName:null,keep:this.keep};this.vars.set(name,b);}return b;}
  lookup(name){for(let s=this;s;s=s.parent){const b=s.vars.get(name);if(b)return b;}return null;}
}
function declarePattern(p,scope){
  if(!p)return;
  switch(p.type){
    case 'Identifier':scope.declare(p.name);break;
    case 'ObjectPattern':for(const pr of p.properties)declarePattern(pr.type==='RestElement'?pr.argument:pr.value,scope);break;
    case 'ArrayPattern':for(const e of p.elements)declarePattern(e,scope);break;
    case 'AssignmentPattern':declarePattern(p.left,scope);break;
    case 'RestElement':declarePattern(p.argument,scope);break;
  }
}
const isFn=n=>n.type==='FunctionDeclaration'||n.type==='FunctionExpression'||n.type==='ArrowFunctionExpression';
function collectVars(node,scope){
  if(node.type==='VariableDeclaration'&&node.kind==='var')for(const d of node.declarations)declarePattern(d.id,scope);
  forEachChild(node,c=>{if(!isFn(c))collectVars(c,scope);});
}
function collectLexical(stmts,scope){
  for(const s of stmts){
    if(!s)continue;
    if(s.type==='VariableDeclaration'&&s.kind!=='var')for(const d of s.declarations)declarePattern(d.id,scope);
    else if((s.type==='FunctionDeclaration'||s.type==='ClassDeclaration')&&s.id)scope.declare(s.id.name);
  }
}
function scan(node,scope){
  let cur=scope;
  if(node.type==='Program'){cur=node._scope=new Scope('program',null,true);collectVars(node,cur);collectLexical(node.body,cur);}
  else if(isFn(node)){
    cur=node._scope=new Scope('function',scope);
    for(const p of node.params)declarePattern(p,cur);
    if(node.type==='FunctionExpression'&&node.id)cur.declare(node.id.name);
    if(node.body.type==='BlockStatement'){collectVars(node.body,cur);collectLexical(node.body.body,cur);}
    else collectVars(node.body,cur);
    // тело функции разбираем в той же области
    if(node.body.type==='BlockStatement'){node.body._scope=cur;for(const c of node.body.body)scan(c,cur);}
    else scan(node.body,cur);
    for(const p of node.params)scan(p,cur);
    return;
  }
  else if(node.type==='BlockStatement'){cur=node._scope=new Scope('block',scope);collectLexical(node.body,cur);}
  else if(node.type==='SwitchStatement'){
    scan(node.discriminant,scope);
    cur=node._scope=new Scope('block',scope);
    for(const c of node.cases)collectLexical(c.consequent,cur);
    for(const c of node.cases)scan(c,cur);
    return;
  }
  else if(node.type==='ForStatement'||node.type==='ForInStatement'||node.type==='ForOfStatement'){
    cur=node._scope=new Scope('block',scope);
    const d=node.type==='ForStatement'?node.init:node.left;
    if(d&&d.type==='VariableDeclaration'&&d.kind!=='var')collectLexical([d],cur);
  }
  else if(node.type==='CatchClause'){cur=node._scope=new Scope('block',scope);declarePattern(node.param,cur);}
  forEachChild(node,c=>scan(c,cur));
}

/* ---------- имена ---------- */
function nameGen(rand){
  const used=new Set();let n=0;
  const base=Math.floor(rand()*40000)+1000;
  return()=>{
    let name;
    do{name='_0x'+((base+n*7919)%65536).toString(16).padStart(4,'0');n++;}while(used.has(name));
    used.add(name);return name;
  };
}
function assignNames(scope,gen){
  for(const b of scope.vars.values())if(!b.keep&&!b.newName)b.newName=gen();
}
function collectScopes(node,out){
  if(node._scope)out.push(node._scope);
  forEachChild(node,c=>collectScopes(c,out));
}

/* ---------- обход и правки ---------- */
function visit(node,parent,key,scope,edits,strs){
  const cur=node._scope||scope;
  switch(node.type){
    case 'Identifier':{
      if(parent){
        if(parent.type==='MemberExpression'&&key==='property'&&!parent.computed)return;
        if(parent.type==='Property'&&key==='key'&&!parent.computed)return;
        if((parent.type==='MethodDefinition'||parent.type==='PropertyDefinition')&&key==='key'&&!parent.computed)return;
        if((parent.type==='LabeledStatement'||parent.type==='BreakStatement'||parent.type==='ContinueStatement')&&key==='label')return;
        if(parent.type==='MetaProperty')return;
      }
      const b=scope.lookup(node.name);
      if(b&&!b.keep&&b.newName)edits.push({start:node.start,end:node.end,text:node._sh?node.name+':'+b.newName:b.newName});
      return;
    }
    case 'Literal':{
      if(typeof node.value==='string'&&node.value.length>=3&&parent){
        if(parent.type==='Property'&&key==='key'&&!parent.computed)return;
        if((parent.type==='MethodDefinition'||parent.type==='PropertyDefinition')&&key==='key'&&!parent.computed)return;
        if(parent.type==='ExpressionStatement'&&parent.directive)return;
        if(parent.type==='ImportDeclaration'||parent.type==='ExportNamedDeclaration'||parent.type==='ExportAllDeclaration')return;
        edits.push({start:node.start,end:node.end,str:node.value});
      }
      return;
    }
    case 'Property':{
      if(node.shorthand){
        const v=node.value;
        if(v.type==='Identifier')v._sh=v.name;
        else if(v.type==='AssignmentPattern'&&v.left.type==='Identifier')v.left._sh=v.left.name;
        if(v.type==='AssignmentPattern'){visit(v.left,v,'left',cur,edits,strs);visit(v.right,v,'right',cur,edits,strs);}
        else visit(v,node,'value',cur,edits,strs);
        return;
      }
      break;
    }
    case 'FunctionDeclaration':{
      if(node.id)visit(node.id,node,'id',scope,edits,strs);
      forEachChild(node,(c,k)=>{if(k!=='id')visit(c,node,k,cur,edits,strs);});
      return;
    }
    case 'FunctionExpression':{
      if(node.id)visit(node.id,node,'id',cur,edits,strs);
      forEachChild(node,(c,k)=>{if(k!=='id')visit(c,node,k,cur,edits,strs);});
      return;
    }
    case 'ExpressionStatement':break;
  }
  forEachChild(node,(c,k)=>visit(c,node,k,cur,edits,strs));
}

/* ---------- таблица строк ---------- */
function buildStringTable(edits,rand,prefix){
  const strs=[...new Set(edits.filter(e=>e.str!==undefined).map(e=>e.str))];
  if(!strs.length)return {prelude:'',replace:e=>e};
  const keyLen=12+Math.floor(rand()*8),key=Array.from({length:keyLen},()=>Math.floor(rand()*255)+1);
  const order=strs.map((_,i)=>i);
  for(let i=order.length-1;i>0;i--){const j=Math.floor(rand()*(i+1));[order[i],order[j]]=[order[j],order[i]];}
  const pos=new Map();
  const table=new Array(strs.length);
  order.forEach((si,p)=>{
    pos.set(strs[si],p);
    const bytes=Buffer.from(strs[si],'utf8');
    for(let i=0;i<bytes.length;i++)bytes[i]^=key[i%key.length];
    table[p]=bytes.toString('base64');
  });
  const T=prefix+'t',K=prefix+'k',C=prefix+'c',D=prefix+'d';
  const prelude='var '+T+'='+JSON.stringify(table)+','+K+'='+JSON.stringify(key)+','+C+'=[];'+
    'function '+D+'(i){if(void 0!==('+C+'[i]))return '+C+'[i];var s=atob('+T+'[i]),b=new Uint8Array(s.length),j=0;for(;j<s.length;j++)b[j]=s.charCodeAt(j)^'+K+'[j%'+K+'.length];return '+C+'[i]=new TextDecoder().decode(b)}\n';
  return {prelude,call:s=>D+'('+pos.get(s)+')'};
}

/* ---------- минификация: токены без комментариев и лишних пробелов ---------- */
const WORD=/[A-Za-z0-9_$\u0080-\uFFFF]/;
function minify(src){
  if(src.indexOf('`')>=0)throw new Error('template literals are not supported by the minifier');
  const toks=[...acorn.tokenizer(src,OPTS)].filter(t=>t.type.label!=='eof');
  let out='',prev=null;
  for(const t of toks){
    const text=src.slice(t.start,t.end);
    if(prev){
      const gap=src.slice(prev.end,t.start),pl=out[out.length-1],cf=text[0];
      const nl=/\n/.test(gap)||/\/\*[\s\S]*?\n[\s\S]*?\*\//.test(gap);
      if(nl)out+='\n';
      else if((WORD.test(pl)&&WORD.test(cf))||(pl==='+'&&cf==='+')||(pl==='-'&&cf==='-')||(prev.type.label==='num'&&cf==='.')||(pl==='/'&&cf==='/'))out+=' ';
    }
    out+=text;prev=t;
  }
  return out;
}

function obfuscate(src,opt){
  opt=opt||{};
  const seed=(opt.seed||'')+crypto.createHash('sha256').update(src).digest('hex');
  const rand=prng(seed);
  const ast=acorn.parse(src,OPTS);
  scan(ast,null);
  const scopes=[];collectScopes(ast,scopes);
  const gen=nameGen(rand);
  for(const s of scopes)assignNames(s,gen);
  const edits=[];
  visit(ast,null,null,ast._scope,edits,null);
  const prefix='_0x'+crypto.createHash('sha256').update(seed).digest('hex').slice(0,3);
  const tbl=buildStringTable(edits,rand,prefix);
  const final=edits.map(e=>e.str!==undefined?{start:e.start,end:e.end,text:tbl.call(e.str)}:e).sort((a,b)=>b.start-a.start);
  let out=src;
  for(const e of final)out=out.slice(0,e.start)+e.text+out.slice(e.end);
  const min=minify(out);
  const res=tbl.prelude+min;
  if(/<\/script/i.test(res)||res.indexOf('<!--')>=0)throw new Error('output contains a sequence unsafe for inline <script>');
  acorn.parse(res,OPTS);   // проверка синтаксиса результата
  return res;
}
module.exports={obfuscate,minify};
