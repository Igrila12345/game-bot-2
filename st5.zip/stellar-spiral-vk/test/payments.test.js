'use strict';
process.env.NODE_ENV='test';
const test=require('node:test'),assert=require('node:assert/strict');
const os=require('node:os'),path=require('node:path'),fs=require('node:fs');
const {createApp,readConfig,paymentSig}=require('../server.js');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'stellar-pay-'));
const cfg=readConfig({DB_PATH:path.join(dir,'p.db'),VK_APP_ID:'1234',VK_SECRET:'topsecret',PUBLIC_DIR:path.join(__dirname,'..','public')});
let app,base;
test.before(async()=>{app=createApp(cfg);await new Promise(r=>app.server.listen(0,'127.0.0.1',r));base='http://127.0.0.1:'+app.server.address().port;});
test.after(async()=>{await app.close();});
const post=async params=>{
  const p=Object.assign({app_id:'1234',user_id:'501',receiver_id:'501',lang:'ru',version:'1'},params);
  p.sig=paymentSig(p,'topsecret');
  return (await fetch(base+'/vk/payments',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(p).toString()})).json();
};
test('production default: test payment notifications are rejected, real ones are answered',async()=>{
  assert.equal(cfg.allowTestPayments,false);
  assert.ok((await post({notification_type:'get_item_test',item:'crystals_p1'})).error,'get_item_test rejected');
  assert.ok((await post({notification_type:'order_status_change_test',status:'chargeable',order_id:'1',item:'crystals_p1'})).error,'order test rejected');
  const r=await post({notification_type:'get_item',item:'crystals_p1'});
  assert.equal(r.response.price,5);
});
