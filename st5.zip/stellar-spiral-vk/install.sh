#!/bin/bash
# Установка «Звёздной спирали» на Debian/Ubuntu под root: Node.js, игра как служба, HTTPS через Caddy.
# Запуск:  APP_ID=... SECRET=... VKID=... bash install.sh
# APP_ID  ID приложения VK, SECRET  защищённый ключ, VKID  ваш VK id (роль разработчика).
# Домен (по желанию): DOMAIN=game.example.ru, иначе будет адрес вида 89-23-115-251.sslip.io
# Файервол (по желанию): FIREWALL=1 (разрешит SSH, 80 и 443, остальное закроет)
set -e
: "${APP_ID:?Укажите APP_ID (ID приложения VK)}" "${SECRET:?Укажите SECRET (защищённый ключ)}" "${VKID:?Укажите VKID (ваш VK id)}"
[ "$(id -u)" = "0" ] || { echo "Запускайте от root"; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST=/opt/stellar-spiral-vk
export DEBIAN_FRONTEND=noninteractive

echo "== 1/5 Node.js"
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 22 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
apt-get install -y unzip curl gpg apt-transport-https openssl >/dev/null
node -v

echo "== 2/5 Файлы игры"
mkdir -p "$DEST"
cp -a "$SRC"/. "$DEST"/
cd "$DEST"
if [ ! -f .env ]; then
  cp .env.example .env
  sed -i "s|^VK_APP_ID=.*|VK_APP_ID=$APP_ID|; s|^VK_SECRET=.*|VK_SECRET=$SECRET|; s|^DEV_IDS=.*|DEV_IDS=$VKID|; s|^TRUST_PROXY=.*|TRUST_PROXY=1|; s|^SIGN_KEY=.*|SIGN_KEY=$(openssl rand -hex 32)|" .env
  echo "создан .env"
else
  echo ".env уже есть, оставляю как есть (чтобы поменять значения, удалите $DEST/.env и запустите снова)"
fi
chmod 600 .env
id stellar >/dev/null 2>&1 || useradd -r -s /usr/sbin/nologin stellar
chown -R stellar:stellar "$DEST"

echo "== 3/5 Автозапуск игры"
cat > /etc/systemd/system/stellar.service <<UNIT
[Unit]
Description=Stellar Spiral
After=network.target

[Service]
WorkingDirectory=$DEST
ExecStart=$(command -v node) server.js
Restart=always
User=stellar

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable stellar >/dev/null 2>&1
systemctl restart stellar
sleep 2
if ! curl -fs http://127.0.0.1:3000/api/ping >/dev/null; then
  echo "Игра не запустилась. Последние строки журнала:"; journalctl -u stellar -n 20 --no-pager; exit 1
fi
echo "игра отвечает на 127.0.0.1:3000"

echo "== 4/5 Caddy (HTTPS)"
if ! command -v caddy >/dev/null; then
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y >/dev/null
  apt-get install -y caddy
fi
if [ -z "$DOMAIN" ]; then
  IP="$(curl -4 -s --max-time 8 ifconfig.me)"
  [ -n "$IP" ] || { echo "Не удалось узнать внешний IP, задайте DOMAIN=..."; exit 1; }
  DOMAIN="${IP//./-}.sslip.io"
fi
printf '%s {\n  reverse_proxy 127.0.0.1:3000\n}\n' "$DOMAIN" > /etc/caddy/Caddyfile
systemctl enable caddy >/dev/null 2>&1
systemctl restart caddy

echo "== Резервные копии (раз в сутки в 04:15)"
cat > /etc/systemd/system/stellar-backup.service <<UNIT
[Unit]
Description=Stellar Spiral backup

[Service]
Type=oneshot
User=stellar
WorkingDirectory=$DEST
ExecStart=$(command -v node) tools/backup.js
UNIT
cat > /etc/systemd/system/stellar-backup.timer <<UNIT
[Unit]
Description=Daily Stellar Spiral backup

[Timer]
OnCalendar=*-*-* 04:15:00
Persistent=true

[Install]
WantedBy=timers.target
UNIT
systemctl daemon-reload
systemctl enable --now stellar-backup.timer >/dev/null 2>&1

if [ "$FIREWALL" = "1" ]; then
  echo "== Файервол (разрешены SSH, 80 и 443)"
  apt-get install -y ufw >/dev/null
  SSHP="$(ss -tlnp 2>/dev/null | awk '/sshd/ {n=split($4,a,":"); print a[n]}' | sort -u)"
  for p in ${SSHP:-22}; do ufw allow "$p"/tcp >/dev/null; done
  ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null
  ufw --force enable >/dev/null
  ufw status | head -8
fi

echo "== 5/5 Проверка HTTPS (сертификат выпускается до минуты)"
for i in 1 2 3 4 5 6 7 8; do
  sleep 8
  if curl -fs "https://$DOMAIN/api/ping" >/dev/null; then
    echo
    echo "ГОТОВО."
    echo "Адрес приложения для VK:  https://$DOMAIN/"
    echo "Адрес для платежей:        https://$DOMAIN/vk/payments"
    exit 0
  fi
done
echo "HTTPS пока не отвечает. Возможные причины: провайдер закрыл порты 80 и 443, домен не указывает на этот сервер."
echo "Журнал Caddy:"; journalctl -u caddy -n 25 --no-pager
exit 1
