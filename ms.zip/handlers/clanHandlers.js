'use strict';

const clan = require('../game/clan');
const clansDb = require('../db/clans');
const players = require('../db/players');
const calc = require('../game/calc');
const C = require('../game/constants');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return null;
  }
  return player;
}

async function handleCreate(ctx, name) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!name) {
    await ctx.send('⛔ Укажите название: !клан создать [название]');
    return;
  }

  const result = await clan.createClan(ctx.senderId, name);
  if (!result.ok) {
    const reasons = {
      invalid_name_length: `⛔ Название клана должно быть от ${C.CLAN_NAME_MIN} до ${C.CLAN_NAME_MAX} символов.`,
      already_in_clan: '⛔ Вы уже состоите в клане.',
      name_taken: '⛔ Это название уже занято.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось создать клан.');
    return;
  }

  await ctx.send(`✅ Клан «${result.clan.name}» создан бесплатно! Вы — глава клана.`);
}

async function handleInvite(ctx, targetId) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!targetId) {
    await ctx.send('⛔ Укажите игрока: !клан пригласить @юзер');
    return;
  }

  const result = await clan.invite(ctx.senderId, targetId);
  if (!result.ok) {
    const reasons = {
      not_leader: '⛔ Только глава клана может приглашать.',
      target_not_registered: '⛔ Этот игрок не зарегистрирован.',
      target_already_in_clan: '⛔ Этот игрок уже состоит в клане.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось пригласить игрока.');
    return;
  }

  await ctx.send('✅ Приглашение отправлено!');

  if (ctx.bot) {
    const clanData = await clansDb.getClanById(result.clanId);
    await ctx.bot
      .notifyUser(targetId, `👥 Вас пригласили в клан «${clanData.name}»! Введите: !клан вступить ${clanData.name}`)
      .catch(() => {});
  }
}

async function handleJoin(ctx, name) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!name) {
    await ctx.send('⛔ Укажите название клана: !клан вступить [название]');
    return;
  }

  const result = await clan.join(ctx.senderId, name);
  if (!result.ok) {
    const reasons = {
      already_in_clan: '⛔ Вы уже состоите в клане.',
      clan_not_found: '⛔ Клан с таким названием не найден.',
      no_invite: '⛔ У вас нет приглашения в этот клан.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось вступить в клан.');
    return;
  }

  await ctx.send(`✅ Вы вступили в клан «${result.clan.name}»!`);
}

async function handleKick(ctx, targetId) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!targetId) {
    await ctx.send('⛔ Укажите игрока: !клан кик @юзер');
    return;
  }

  const result = await clan.kick(ctx.senderId, targetId);
  if (!result.ok) {
    const reasons = {
      not_leader: '⛔ Только глава клана может исключать участников.',
      not_member: '⛔ Этот игрок не состоит в вашем клане.',
      cannot_kick_self: '⛔ Нельзя исключить самого себя.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось исключить игрока.');
    return;
  }

  await ctx.send('✅ Игрок исключён из клана.');
  if (ctx.bot) {
    await ctx.bot.notifyUser(targetId, '👥 Вас исключили из клана.').catch(() => {});
  }
}

async function handleLeave(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await clan.leave(ctx.senderId);
  if (!result.ok) {
    const reasons = {
      not_in_clan: '⛔ Вы не состоите в клане.',
      leader_cannot_leave: '⛔ Глава не может покинуть клан. Передайте главенство или удалите клан вручную у администратора.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Не удалось покинуть клан.');
    return;
  }

  await ctx.send('✅ Вы покинули клан.');
}

async function handleBonus(ctx, bonusName) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!bonusName) {
    await ctx.send('⛔ Укажите бонус: !клан бонус [форсаж/эшелон/индустриализация]');
    return;
  }

  const result = await clan.useBonus(ctx.senderId, bonusName);
  if (!result.ok) {
    if (result.reason === 'not_leader') {
      await ctx.send('⛔ Только глава клана может покупать бонусы.');
    } else if (result.reason === 'unknown_bonus') {
      await ctx.send('⛔ Неизвестный бонус. Доступны: Форсаж, Эшелон, Индустриализация.');
    } else if (result.reason === 'cooldown') {
      await ctx.send(`⛔ Бонус на кулдауне до ${new Date(result.until).toLocaleTimeString('ru-RU')}.`);
    } else if (result.reason === 'not_enough_vault') {
      await ctx.send(
        `⛔ Недостаточно средств в сейфе. Нужно ${calc.formatNumber(result.cost)}, есть ${calc.formatNumber(
          result.have
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось применить бонус.');
    }
    return;
  }

  await ctx.send(
    `✅ Бонус «${result.bonus.name}» активирован на ${result.bonus.durationHours} ч!\n${result.bonus.description}\nСтоимость: ${calc.formatNumber(
      result.cost
    )} вирт из сейфа.`
  );
}

async function handleVault(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!player.clan_id) {
    await ctx.send('⛔ Вы не состоите в клане.');
    return;
  }

  const clanData = await clansDb.getClanById(player.clan_id);
  const clanFactories = await clansDb.getClanFactoriesSum(player.clan_id);
  const maxVault = clanFactories * C.CLAN_VAULT_PER_FACTORY;

  await ctx.send(
    `👥 СЕЙФ КЛАНА «${clanData.name}»:\n💰 ${calc.formatNumber(clanData.vault)} / ${calc.formatNumber(
      maxVault
    )} вирт`
  );
}

async function handleInfo(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if (!player.clan_id) {
    await ctx.send('⛔ Вы не состоите в клане.');
    return;
  }

  const clanData = await clansDb.getClanById(player.clan_id);
  const members = await clansDb.getClanMembers(player.clan_id);

  let text = `👥 КЛАН «${clanData.name}»\n\n`;
  for (const m of members) {
    const role = m.clan_role === 'leader' ? '👑 Глава' : 'Участник';
    text += `${role}: ${m.state_name} — 🏭 ${m.factories} заводов\n`;
  }

  await ctx.send(text.trim());
}

module.exports = {
  handleCreate,
  handleInvite,
  handleJoin,
  handleKick,
  handleLeave,
  handleBonus,
  handleVault,
  handleInfo,
};
