'use strict';

const combat = require('../game/combat');
const players = require('../db/players');
const calc = require('../game/calc');
const C = require('../game/constants');

function findWeaponKey(name) {
  const lower = (name || '').toLowerCase();
  return Object.keys(C.WEAPONS).find((k) => k.toLowerCase() === lower);
}

async function handleAttack(ctx, targetId, weaponArg, qtyArg, peerId) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!targetId) {
    await ctx.send('⛔ Укажите цель: !атака @юзер [оружие] [количество]');
    return;
  }

  const weaponKey = findWeaponKey(weaponArg);
  if (!weaponKey) {
    await ctx.send('⛔ Неизвестное оружие.');
    return;
  }

  const quantity = parseInt(qtyArg, 10) || 1;

  const result = await combat.launchAttack(vkId, targetId, weaponKey, quantity, peerId);

  if (!result.ok) {
    const reasons = {
      self_attack: '⛔ Нельзя атаковать самого себя.',
      not_registered: '⛔ Цель не зарегистрирована в игре.',
      defender_too_small: `⛔ Нельзя атаковать игрока с менее чем ${C.MIN_FACTORIES_TO_BE_ATTACKED} заводами.`,
      defender_inactive: `⛔ Игрок не заходил более ${C.INACTIVITY_ATTACK_BAN_DAYS} дней, атака запрещена.`,
      invalid_quantity: `⛔ Некорректное количество. Максимум за раз: ${result.max}.`,
      not_enough_weapons: `⛔ У вас недостаточно этого оружия (в наличии: ${result.have}).`,
      cooldown: `⛔ Атаковать эту цель можно раз в час. Осталось: ${calc.formatDuration(result.remainingMs)}.`,
      unknown_weapon: '⛔ Неизвестное оружие.',
    };
    await ctx.send(reasons[result.reason] || '⛔ Атака невозможна.');
    return;
  }

  const weapon = C.WEAPONS[weaponKey];
  const effectText =
    weapon.effect === 'block_random'
      ? `Удар по заводам противника.` +
        (weapon.hitsToDestroy
          ? ` Для полного сноса 1 завода нужно ${weapon.hitsToDestroy} попадания этим оружием.`
          : '')
      : weapon.effect === 'block_all_radiation'
      ? `Радиационное заражение: -20% дохода на 2 часа.`
      : weapon.effect === 'destroy_and_block'
      ? `1 завод будет уничтожен навсегда.`
      : weapon.effect === 'wipe_air_defense'
      ? `Всё ПВО противника будет уничтожено.`
      : '';

  await ctx.send(
    `🚀 ГОСУДАРСТВО «${result.attackerName}» ЗАПУСТИЛО:\n` +
      `Оружие: ${weaponKey} (x${quantity})\n` +
      `Цель: ${result.defenderName}\n` +
      `Расстояние: ${Math.round(result.distance)} км\n` +
      `Прилёт через: ${calc.formatDuration(result.flightMs)}\n\n` +
      `Эффект: ${effectText}\n` +
      `⏳ Следующая атака по «${result.defenderName}» доступна через 60 минут.`
  );

  // Уведомление жертве
  if (ctx.bot) {
    await ctx.bot
      .notifyUser(
        targetId,
        `⚠️ Государство «${result.attackerName}» запустило ${weaponKey} по вашему городу! Прилёт через ${calc.formatDuration(
          result.flightMs
        )}.`
      )
      .catch(() => {});

    if (peerId) {
      await ctx.bot
        .sendToChat(
          peerId,
          `⚔️ «${result.attackerName}» атакует «${result.defenderName}» (${weaponKey}). Прилёт через ${calc.formatDuration(
            result.flightMs
          )}.`
        )
        .catch(() => {});
    }
  }
}

async function handleRecon(ctx, targetId) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!targetId) {
    await ctx.send('⛔ Укажите цель: !разведка @юзер');
    return;
  }

  const target = await players.getPlayer(targetId);
  if (!target || target.registration_step !== 'done') {
    await ctx.send('⛔ Эта цель не найдена.');
    return;
  }

  if (Number(player.balance) < C.RECON_COST) {
    await ctx.send(`⛔ Недостаточно вирт. Нужно ${C.RECON_COST}.`);
    return;
  }

  await players.updateBalance(vkId, -C.RECON_COST);

  const exact = calc.distanceKm(player.x, player.y, target.x, target.y);
  const lower = Math.max(0, Math.round(exact - 50));
  const upper = Math.round(exact + 50);

  await ctx.send(
    `🕵️ РАЗВЕДКА ДОЛОЖИЛА:\n` +
      `Цель: ${target.state_name}\n` +
      `Расстояние: примерно ${lower}-${upper} км.\n` +
      `Стоимость: ${C.RECON_COST} вирт.`
  );
}

module.exports = { handleAttack, handleRecon };
