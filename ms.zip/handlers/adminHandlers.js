'use strict';

const players = require('../db/players');
const clansDb = require('../db/clans');
const calc = require('../game/calc');
const C = require('../game/constants');

function isAdmin(vkId) {
  return C.ADMIN_IDS.includes(vkId);
}

function findWeaponKey(name) {
  const lower = (name || '').toLowerCase();
  return Object.keys(C.WEAPONS).find((k) => k.toLowerCase() === lower);
}

function findAirDefenseKey(name) {
  const lower = (name || '').toLowerCase();
  return Object.keys(C.AIR_DEFENSE).find((k) => k.toLowerCase() === lower);
}

const ADMIN_HELP = `🛠️ АДМИН-КОМАНДЫ

!админ баланс @юзер [сумма] — прибавить/отнять вирты (можно с минусом)
!админ завод @юзер [кол-во] — выдать заводы
!админ снести @юзер [кол-во] — принудительно снести заводы (без защиты новичков)
!админ оружие @юзер [название] [кол-во] — выдать оружие
!админ пво @юзер [название] [кол-во] — выдать ПВО
!админ разблок @юзер — снять все блокировки заводов
!админ инфо @юзер — полная информация об игроке
!админ рассылка [текст] — сообщение всем активным игрокам
!админ помощь — этот список

🎟️ Промокоды:
промо создать [код] [тип] [название|-] [кол-во] [лимит] [часов_жизни|0] — создать промокод
  типы: weapon, air_defense, virts, tokens, science
промо список — активные промокоды
промо удалить [код] — удалить промокод`;

async function requireTarget(ctx, targetId) {
  if (!targetId) {
    await ctx.send('⛔ Укажите игрока: !админ [команда] @юзер ...');
    return null;
  }
  const target = await players.getPlayer(targetId);
  if (!target || target.registration_step !== 'done') {
    await ctx.send('⛔ Этот игрок не зарегистрирован.');
    return null;
  }
  return target;
}

async function handleAdmin(ctx, sub, targetId, rest) {
  const vkId = ctx.senderId;
  if (!isAdmin(vkId)) {
    await ctx.send('⛔ Команда недоступна.');
    return;
  }

  switch (sub) {
    case 'помощь': {
      await ctx.send(ADMIN_HELP);
      return;
    }

    case 'баланс': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const amount = parseInt(rest[0], 10);
      if (!Number.isInteger(amount)) {
        await ctx.send('⛔ Формат: !админ баланс @юзер [сумма]');
        return;
      }
      const newBalance = await players.updateBalance(targetId, amount);
      await ctx.send(
        `✅ Баланс «${target.state_name}» изменён на ${amount > 0 ? '+' : ''}${amount}. Текущий баланс: ${calc.formatNumber(
          newBalance
        )} вирт.`
      );
      return;
    }

    case 'завод': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const amount = parseInt(rest[0], 10);
      if (!Number.isInteger(amount) || amount <= 0) {
        await ctx.send('⛔ Формат: !админ завод @юзер [кол-во]');
        return;
      }
      await players.addFactories(targetId, amount, false);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано ${amount} завод(ов).`);
      return;
    }

    case 'снести': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const amount = parseInt(rest[0], 10);
      if (!Number.isInteger(amount) || amount <= 0) {
        await ctx.send('⛔ Формат: !админ снести @юзер [кол-во]');
        return;
      }
      let destroyed = 0;
      for (let i = 0; i < amount; i++) {
        const current = await players.getPlayer(targetId);
        if (!current || current.factories <= 0) break;
        await players.destroyOneFactory(targetId);
        destroyed++;
      }
      await ctx.send(`✅ У игрока «${target.state_name}» снесено ${destroyed} завод(ов).`);
      return;
    }

    case 'оружие': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const qty = parseInt(rest[rest.length - 1], 10);
      const weaponName = rest.slice(0, -1).join(' ');
      const weaponKey = findWeaponKey(weaponName);
      if (!weaponKey || !Number.isInteger(qty) || qty <= 0) {
        await ctx.send('⛔ Формат: !админ оружие @юзер [название] [кол-во]');
        return;
      }
      await players.addToArsenal(targetId, weaponKey, qty);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано ${weaponKey} x${qty}.`);
      return;
    }

    case 'пво': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const qty = parseInt(rest[rest.length - 1], 10);
      const adName = rest.slice(0, -1).join(' ');
      const adKey = findAirDefenseKey(adName);
      if (!adKey || !Number.isInteger(qty) || qty <= 0) {
        await ctx.send('⛔ Формат: !админ пво @юзер [название] [кол-во]');
        return;
      }
      await players.addToAirDefense(targetId, adKey, qty);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано ПВО ${adKey} x${qty}.`);
      return;
    }

    case 'разблок': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      await players.setBlockedFactories(targetId, []);
      await ctx.send(`✅ Все блокировки заводов «${target.state_name}» сняты.`);
      return;
    }

    case 'инфо': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      let clanName = null;
      if (target.clan_id) {
        const clan = await clansDb.getClanById(target.clan_id);
        clanName = clan ? clan.name : null;
      }
      await ctx.send(
        `🛠️ ИНФО: ${target.state_name} (id${target.vk_id})\n` +
          `Баланс: ${calc.formatNumber(target.balance)}\n` +
          `Заводов: ${target.factories} (золотых: ${target.gold_mine_count})\n` +
          `Уничтожено (получено): ${target.destroyed_factories}\n` +
          `Снесено врагу: ${target.enemy_factories_destroyed || 0}\n` +
          `Урон накоплен на заводах: ${target.factory_damage || 0}\n` +
          `Клан: ${clanName || 'нет'}\n` +
          `Координаты: (${target.x}, ${target.y})\n` +
          `Последний визит: ${new Date(target.last_seen).toLocaleString('ru-RU')}`
      );
      return;
    }

    case 'рассылка': {
      const text = rest.join(' ');
      if (!text) {
        await ctx.send('⛔ Формат: !админ рассылка [текст]');
        return;
      }
      const all = await players.getAllActivePlayers();
      let sent = 0;
      for (const p of all) {
        if (ctx.bot) {
          await ctx.bot.notifyUser(p.vk_id, `📢 ОБЪЯВЛЕНИЕ:\n${text}`).catch(() => {});
          sent++;
        }
      }
      await ctx.send(`✅ Рассылка отправлена ${sent} игрокам.`);
      return;
    }

    default: {
      await ctx.send('⛔ Неизвестная админ-команда. !админ помощь — список команд.');
    }
  }
}

module.exports = { handleAdmin, isAdmin };
