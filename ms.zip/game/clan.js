'use strict';

const C = require('./constants');
const players = require('../db/players');
const clansDb = require('../db/clans');

async function createClan(vkId, name) {
  if (name.length < C.CLAN_NAME_MIN || name.length > C.CLAN_NAME_MAX) {
    return { ok: false, reason: 'invalid_name_length' };
  }
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };
  if (player.clan_id) return { ok: false, reason: 'already_in_clan' };

  const existing = await clansDb.getClanByName(name);
  if (existing) return { ok: false, reason: 'name_taken' };

  if (C.CLAN_CREATE_COST > 0) {
    await players.updateBalance(vkId, -C.CLAN_CREATE_COST);
  }
  const clan = await clansDb.createClan(name, vkId);
  await players.setClan(vkId, clan.id, 'leader');

  return { ok: true, clan };
}

async function invite(leaderId, targetId) {
  const leader = await players.getPlayer(leaderId);
  if (!leader || !leader.clan_id || leader.clan_role !== 'leader') {
    return { ok: false, reason: 'not_leader' };
  }
  const target = await players.getPlayer(targetId);
  if (!target) return { ok: false, reason: 'target_not_registered' };
  if (target.clan_id) return { ok: false, reason: 'target_already_in_clan' };

  await clansDb.createInvite(leader.clan_id, targetId);
  return { ok: true, clanId: leader.clan_id };
}

async function join(playerId, clanName) {
  const player = await players.getPlayer(playerId);
  if (!player) return { ok: false, reason: 'not_registered' };
  if (player.clan_id) return { ok: false, reason: 'already_in_clan' };

  const clan = await clansDb.getClanByName(clanName);
  if (!clan) return { ok: false, reason: 'clan_not_found' };

  const invited = await clansDb.hasInvite(clan.id, playerId);
  if (!invited) return { ok: false, reason: 'no_invite' };

  await players.setClan(playerId, clan.id, 'member');
  await clansDb.removeInvite(clan.id, playerId);

  return { ok: true, clan };
}

async function kick(leaderId, targetId) {
  const leader = await players.getPlayer(leaderId);
  if (!leader || !leader.clan_id || leader.clan_role !== 'leader') {
    return { ok: false, reason: 'not_leader' };
  }
  const target = await players.getPlayer(targetId);
  if (!target || target.clan_id !== leader.clan_id) {
    return { ok: false, reason: 'not_member' };
  }
  if (targetId === leaderId) return { ok: false, reason: 'cannot_kick_self' };

  await players.setClan(targetId, null, null);
  return { ok: true };
}

async function leave(playerId) {
  const player = await players.getPlayer(playerId);
  if (!player || !player.clan_id) return { ok: false, reason: 'not_in_clan' };
  if (player.clan_role === 'leader') {
    return { ok: false, reason: 'leader_cannot_leave' };
  }
  await players.setClan(playerId, null, null);
  return { ok: true };
}

async function useBonus(leaderId, bonusKey) {
  const bonus = C.CLAN_BONUSES[bonusKey.toLowerCase()];
  if (!bonus) return { ok: false, reason: 'unknown_bonus' };

  const leader = await players.getPlayer(leaderId);
  if (!leader || !leader.clan_id || leader.clan_role !== 'leader') {
    return { ok: false, reason: 'not_leader' };
  }

  const clan = await clansDb.getClanById(leader.clan_id);
  const cooldownField = `bonus_${bonus.key}_cooldown`;
  if (clan[cooldownField] && new Date(clan[cooldownField]) > new Date()) {
    return { ok: false, reason: 'cooldown', until: clan[cooldownField] };
  }

  const clanFactories = await clansDb.getClanFactoriesSum(clan.id);
  const maxVault = clanFactories * C.CLAN_VAULT_PER_FACTORY;
  const cost = Math.round(maxVault * bonus.costRateOfMaxVault);

  if (Number(clan.vault) < cost) {
    return { ok: false, reason: 'not_enough_vault', cost, have: Number(clan.vault) };
  }

  await clansDb.spendVault(clan.id, cost);
  const until = new Date(Date.now() + bonus.durationHours * 60 * 60 * 1000);
  const cooldownUntil = new Date(Date.now() + bonus.cooldownHours * 60 * 60 * 1000);
  await clansDb.setBonusActive(clan.id, bonus.key, until, cooldownUntil);

  return { ok: true, bonus, cost, until };
}

module.exports = { createClan, invite, join, kick, leave, useBonus };
