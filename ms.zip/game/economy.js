'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const production = require('../db/production');
const clans = require('../db/clans');
const factoryBuilds = require('../db/factoryBuilds');
const { query } = require('../db/pool');

// Начисление часового дохода всем игрокам + налоги + перевод в клан-сейф
async function hourlyTick(bot) {
  const all = await players.getAllActivePlayers();

  for (const player of all) {
    if (player.factories <= 0 && (player.science_centers || 0) <= 0) continue;

    const factoriesInProd = await production.getFactoriesInUse(player.vk_id);
    let income = calc.incomePerHour(player, factoriesInProd);

    // Клановый бонус "Индустриализация"
    if (player.clan_id) {
      const clan = await clans.getClanById(player.clan_id);
      if (clan && clan.bonus_industry_until && new Date(clan.bonus_industry_until) > new Date()) {
        income = Math.round(income * 1.2);
      }
    }

    if (income > 0) {
      await players.updateBalance(player.vk_id, income);

      // Клановый налог: 10% от дохода в сейф
      if (player.clan_id) {
        const clanFactories = await clans.getClanFactoriesSum(player.clan_id);
        const maxVault = clanFactories * C.CLAN_VAULT_PER_FACTORY;
        const clanShare = Math.round(income * C.CLAN_TAX_RATE);
        if (clanShare > 0 && maxVault > 0) {
          await clans.addVault(player.clan_id, clanShare, maxVault);
        }
      }
    }

    // Налог на богатство
    const updated = await players.getPlayer(player.vk_id);
    let balance = Number(updated.balance);
    if (balance > C.WEALTH_TAX_THRESHOLD) {
      const excess = balance - C.WEALTH_TAX_THRESHOLD;
      const tax = Math.round(excess * C.WEALTH_TAX_RATE);
      if (tax > 0) await players.updateBalance(player.vk_id, -tax);
    }
  }

  // Дополнительный налог для топ-3 по виртам
  const top3 = await players.getTopByBalance(3);
  for (let i = 0; i < top3.length; i++) {
    const rule = C.TOP_TAX[i];
    const p = top3[i];
    const balance = Number(p.balance);
    if (balance > rule.threshold) {
      const excess = balance - rule.threshold;
      const tax = Math.round(excess * rule.rate);
      if (tax > 0) {
        await players.updateBalance(p.vk_id, -tax);
        if (bot) {
          bot.notifyUser(
            p.vk_id,
            `💰 Налог для топ-${rule.place} по виртам: -${calc.formatNumber(tax)} вирт (${Math.round(
              rule.rate * 100
            )}% от суммы сверх ${calc.formatNumber(rule.threshold)}).`
          ).catch(() => {});
        }
      }
    }
  }
}

// Постройка завода
async function buildFactory(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };
  const maxFactories = calc.currentFactoryLimit(player.factory_limit_level);
  if (player.factories >= maxFactories) {
    return { ok: false, reason: 'max_reached', max: maxFactories };
  }

  const recentBuilds = await factoryBuilds.countRecentBuilds(vkId, 60 * 60 * 1000);
  if (recentBuilds >= C.FACTORY_BUILD_LIMIT_PER_HOUR) {
    return { ok: false, reason: 'build_limit', limit: C.FACTORY_BUILD_LIMIT_PER_HOUR };
  }

  const price = calc.nextFactoryPrice(player.factories);
  if (Number(player.balance) < price) {
    return { ok: false, reason: 'not_enough_money', price, missing: price - Number(player.balance) };
  }

  const isGoldMine = Math.random() < C.GOLD_MINE_CHANCE;
  await players.updateBalance(vkId, -price);
  await players.addFactories(vkId, 1, isGoldMine);
  await factoryBuilds.logBuild(vkId);

  return { ok: true, price, isGoldMine };
}

// Досрочная разблокировка завода
async function earlyUnblock(vkId, factoryIndex) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const blocked = player.blocked_factories || [];
  if (!blocked.length || factoryIndex < 0 || factoryIndex >= blocked.length) {
    return { ok: false, reason: 'invalid_index' };
  }

  const entry = blocked[factoryIndex];
  const now = Date.now();
  const unblockAt = new Date(entry.unblock_at).getTime();
  if (unblockAt <= now) return { ok: false, reason: 'already_unblocked' };

  const hoursLeft = Math.ceil((unblockAt - now) / (60 * 60 * 1000));
  const cost = C.EARLY_UNBLOCK_COST_PER_HOUR * hoursLeft;

  if (Number(player.balance) < cost) {
    return { ok: false, reason: 'not_enough_money', cost, missing: cost - Number(player.balance) };
  }

  await players.updateBalance(vkId, -cost);
  blocked.splice(factoryIndex, 1);
  await players.setBlockedFactories(vkId, blocked);

  return { ok: true, cost };
}

// Обработка разблокировки заводов по истечении времени (очистка списка blocked_factories)
async function processFactoryUnblocks() {
  const all = await players.getAllActivePlayers();
  const now = Date.now();
  for (const player of all) {
    const blocked = player.blocked_factories || [];
    if (!blocked.length) continue;
    const stillBlocked = blocked.filter((b) => new Date(b.unblock_at).getTime() > now);
    if (stillBlocked.length !== blocked.length) {
      await players.setBlockedFactories(player.vk_id, stillBlocked);
    }
  }
}

// Обработка снятия радиации
async function processRadiationExpiry() {
  await query(
    `UPDATE players SET radiation_until = NULL WHERE radiation_until IS NOT NULL AND radiation_until <= NOW()`
  );
}

module.exports = {
  hourlyTick,
  buildFactory,
  earlyUnblock,
  processFactoryUnblocks,
  processRadiationExpiry,
};
