'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const combatDb = require('../db/combat');
const clans = require('../db/clans');

async function launchAttack(attackerId, defenderId, weaponKey, quantity, peerId) {
  const weapon = C.WEAPONS[weaponKey];
  if (!weapon) return { ok: false, reason: 'unknown_weapon' };

  if (attackerId === defenderId) return { ok: false, reason: 'self_attack' };

  const attacker = await players.getPlayer(attackerId);
  const defender = await players.getPlayer(defenderId);
  if (!attacker || !defender) return { ok: false, reason: 'not_registered' };

  if (defender.factories < C.MIN_FACTORIES_TO_BE_ATTACKED) {
    return { ok: false, reason: 'defender_too_small' };
  }

  const daysSinceLastSeen = (Date.now() - new Date(defender.last_seen).getTime()) / (1000 * 60 * 60 * 24);
  if (daysSinceLastSeen > C.INACTIVITY_ATTACK_BAN_DAYS) {
    return { ok: false, reason: 'defender_inactive' };
  }

  if (quantity <= 0 || quantity > weapon.maxPerAttack) {
    return { ok: false, reason: 'invalid_quantity', max: weapon.maxPerAttack };
  }

  const arsenal = attacker.arsenal || {};
  if ((arsenal[weaponKey] || 0) < quantity) {
    return { ok: false, reason: 'not_enough_weapons', have: arsenal[weaponKey] || 0 };
  }

  const lastAttack = await combatDb.getCooldown(attackerId, defenderId);
  if (lastAttack) {
    const elapsed = Date.now() - new Date(lastAttack).getTime();
    if (elapsed < C.ATTACK_COOLDOWN_MS) {
      return { ok: false, reason: 'cooldown', remainingMs: C.ATTACK_COOLDOWN_MS - elapsed };
    }
  }

  // Списываем оружие
  arsenal[weaponKey] -= quantity;
  if (arsenal[weaponKey] <= 0) delete arsenal[weaponKey];
  await players.setArsenal(attackerId, arsenal);

  // Расстояние и время полёта
  const distance = calc.distanceKm(attacker.x, attacker.y, defender.x, defender.y);
  let speed = weapon.speedKmh;

  // Клановый бонус "Форсаж" x2 скорости
  if (attacker.clan_id) {
    const clan = await clans.getClanById(attacker.clan_id);
    if (clan && clan.bonus_forsazh_until && new Date(clan.bonus_forsazh_until) > new Date()) {
      speed *= 2;
    }
  }

  const flightHours = distance / speed;
  const arrivalAt = new Date(Date.now() + flightHours * 60 * 60 * 1000);

  const attackRecord = await combatDb.createAttack(
    attackerId,
    defenderId,
    weaponKey,
    quantity,
    distance,
    arrivalAt,
    peerId
  );

  await combatDb.setCooldown(attackerId, defenderId);
  await players.touchLastSeen(attackerId);

  return {
    ok: true,
    attackRecord,
    distance,
    flightMs: flightHours * 60 * 60 * 1000,
    attackerName: attacker.state_name,
    defenderName: defender.state_name,
  };
}

// Определяем, какое ПВО сработает против данного оружия (выбираем случайное подходящее)
function pickDefendingAirDefense(airDefense, weaponCategory) {
  const candidates = Object.entries(airDefense || {})
    .filter(([key, qty]) => qty > 0 && C.AIR_DEFENSE[key] && C.AIR_DEFENSE[key].covers.includes(weaponCategory));
  if (!candidates.length) return null;
  const [key] = candidates[Math.floor(Math.random() * candidates.length)];
  return key;
}

async function resolveAttack(attackRecord) {
  const weapon = C.WEAPONS[attackRecord.weapon];
  const attacker = await players.getPlayer(attackRecord.attacker_id);
  const defender = await players.getPlayer(attackRecord.defender_id);

  if (!attacker || !defender) {
    return { ok: false, reason: 'player_missing' };
  }

  const airDefense = defender.air_defense || {};
  const adKey = pickDefendingAirDefense(airDefense, weapon.category);

  let intercepted = false;
  let adUsed = null;

  if (adKey) {
    let chance = C.AIR_DEFENSE[adKey].chance;

    // Клановый бонус "Эшелон" +20% точности ПВО
    if (defender.clan_id) {
      const clan = await clans.getClanById(defender.clan_id);
      if (clan && clan.bonus_eshelon_until && new Date(clan.bonus_eshelon_until) > new Date()) {
        chance = Math.min(chance * 1.2, 1);
      }
    }

    // Скилл защитника: бонус к шансу перехвата ПВО за количество заводов
    const defenderSkill = calc.getSkillTier(defender.factories);
    if (defenderSkill) {
      chance = Math.min(chance + defenderSkill.airDefenseBonus, 1);
    }

    // Итоговый шанс перехвата: точность ПВО (с учётом клановых/скилл-бонусов).
    // Раньше здесь ошибочно использовался фиксированный weapon.counterChance,
    // из-за чего апгрейд ПВО и бонусы не влияли на результат — теперь исправлено.
    const roll = Math.random();
    if (roll < chance) {
      intercepted = true;
      adUsed = adKey;
      // ПВО расходуется в любом случае при перехвате
      airDefense[adKey] -= 1;
      if (airDefense[adKey] <= 0) delete airDefense[adKey];
      await players.setAirDefense(defender.vk_id, airDefense);
    }
  }

  if (intercepted) {
    return {
      ok: true,
      intercepted: true,
      adUsed,
      attacker,
      defender,
      weapon,
    };
  }

  // Оружие прорвалось — применяем эффект
  const effectResult = await applyWeaponEffect(defender, weapon, attackRecord.quantity, attacker);

  // Трофеи атакующему
  const calc_ = require('./calc');
  const productionDb = require('../db/production');
  const factoriesInProd = await productionDb.getFactoriesInUse(defender.vk_id);
  const defenderIncome = calc_.incomePerHour(await players.getPlayer(defender.vk_id), factoriesInProd);
  let loot = Math.round(defenderIncome * C.LOOT_RATE);
  loot = Math.max(C.LOOT_MIN, Math.min(C.LOOT_MAX, loot));
  await players.updateBalance(attacker.vk_id, loot);

  return {
    ok: true,
    intercepted: false,
    attacker,
    defender,
    weapon,
    effectResult,
    loot,
  };
}

async function applyWeaponEffect(defender, weapon, quantity, attacker) {
  const player = await players.getPlayer(defender.vk_id);

  if (weapon.effect === 'block_random') {
    // Блокировка заводов отключена по решению администрации — оружие бьёт напрямую по ХП заводов.
    // ===== Система ХП заводов: накапливаем урон и сносим заводы навсегда =====
    // Каждое попадание даёт (FACTORY_HP_UNIT / hitsToDestroy) единиц урона.
    // Например: Герань-2 (hitsToDestroy=3) -> 2 ед./попадание, нужно 3 шт. чтобы снести завод (3*2=6).
    // Молния (hitsToDestroy=1) -> 6 ед./попадание, сносит завод с одного попадания.
    let destroyedCount = 0;
    if (weapon.hitsToDestroy) {
      const baseDamagePerHit = Math.floor(C.FACTORY_HP_UNIT / weapon.hitsToDestroy);

      // Скилл атакующего: бонус к урону по заводам за количество своих заводов
      let damagePerHit = baseDamagePerHit;
      if (attacker) {
        const attackerSkill = calc.getSkillTier(attacker.factories);
        if (attackerSkill) {
          damagePerHit = Math.round(baseDamagePerHit * (1 + attackerSkill.damageBonus));
        }
      }

      let accumulated = (player.factory_damage || 0) + damagePerHit * quantity;

      while (accumulated >= C.FACTORY_HP_UNIT) {
        // Защита новичков: не сносим заводы ниже порога защиты
        const current = await players.getPlayer(defender.vk_id);
        if (current.factories <= C.NEWBIE_PROTECTION_FACTORIES) break;
        await players.destroyOneFactory(defender.vk_id);
        destroyedCount += 1;
        accumulated -= C.FACTORY_HP_UNIT;
      }

      await players.setFactoryDamage(defender.vk_id, accumulated);

      if (destroyedCount > 0 && attacker) {
        await players.incrementEnemyFactoriesDestroyed(attacker.vk_id, destroyedCount);
      }
    }

    return { type: 'block', count: quantity, destroyedCount };
  }

  if (weapon.effect === 'block_all_radiation') {
    // Блокировка заводов отключена — остаётся только радиационный эффект (-20% дохода на 2 часа).
    const radiationUntil = new Date(Date.now() + C.RADIATION_DURATION_MS);
    await players.setRadiationUntil(defender.vk_id, radiationUntil);
    return { type: 'block_all_radiation', count: player.factories };
  }

  if (weapon.effect === 'destroy_and_block') {
    // Блокировка заводов отключена — остаётся необратимое уничтожение 1 завода.
    let destroyed = false;
    if (player.factories > 0) {
      await players.destroyOneFactory(defender.vk_id);
      destroyed = true;
      if (attacker) {
        await players.incrementEnemyFactoriesDestroyed(attacker.vk_id, 1);
      }
    }
    return { type: 'destroy_and_block', destroyed };
  }

  if (weapon.effect === 'wipe_air_defense') {
    // Блокировка заводов отключена — остаётся снос всего ПВО защитника.
    await players.setAirDefense(defender.vk_id, {});
    return { type: 'wipe_air_defense' };
  }

  return { type: 'none' };
}

module.exports = {
  launchAttack,
  resolveAttack,
  applyWeaponEffect,
};
