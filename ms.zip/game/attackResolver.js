'use strict';

const combat = require('./combat');
const combatDb = require('../db/combat');
const calc = require('./calc');
const C = require('./constants');

async function resolvePendingAttacks(bot) {
  const due = await combatDb.getDueAttacks();

  for (const attackRecord of due) {
    await combatDb.markAttackResolved(attackRecord.id);

    const result = await combat.resolveAttack(attackRecord);
    if (!result.ok) continue;

    const { attacker, defender, weapon, intercepted } = result;
    const qty = attackRecord.quantity;

    if (intercepted) {
      await bot
        .notifyUser(
          attacker.vk_id,
          `💥 Ваше ${weapon.key} (x${qty}) сбито ПВО «${result.adUsed}» противника (${defender.state_name}). Потери: ${qty} шт.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `🎯 Ваше ПВО «${result.adUsed}» сбило вражеское ${weapon.key} (${qty} шт.)!`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `🛡️ «${defender.state_name}» отразил атаку с помощью ПВО «${result.adUsed}»`
          )
          .catch(() => {});
      }
      continue;
    }

    const { effectResult, loot } = result;

    if (effectResult.type === 'block') {
      const destroyedLine = effectResult.destroyedCount
        ? `\n💀 Снесено навсегда: ${effectResult.destroyedCount} завод(ов)!`
        : '';

      await bot
        .notifyUser(
          attacker.vk_id,
          `🔥 ПРЯМОЕ ПОПАДАНИЕ по городу «${defender.state_name}»!${destroyedLine} Трофеи: +${loot} вирт.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `💥 Враг прорвал оборону!${destroyedLine}`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `💥 «${attacker.state_name}» нанёс удар по «${defender.state_name}»${
              effectResult.destroyedCount ? `, снесено ${effectResult.destroyedCount}` : ''
            }`
          )
          .catch(() => {});
      }
    } else if (effectResult.type === 'block_all_radiation') {
      await bot
        .notifyUser(
          attacker.vk_id,
          `☢️ Радиационное заражение! Все заводы «${defender.state_name}» получают -20% дохода на 2 часа.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `☢️ Радиационная атака! Доход снижен на 20% на 2 часа.`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `☢️ «${attacker.state_name}» нанёс ядерный удар по «${defender.state_name}»: радиация`
          )
          .catch(() => {});
      }
    } else if (effectResult.type === 'destroy_and_block') {
      await bot
        .notifyUser(
          attacker.vk_id,
          `☢️ ЯДЕРНЫЙ УДАР! Завод города «${defender.state_name}» уничтожен навсегда! Трофеи: +${loot} вирт.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `☢️ ВАШ ЗАВОД УНИЧТОЖЕН! Один завод стёрт с лица земли безвозвратно.`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `☢️ «${attacker.state_name}» уничтожил завод «${defender.state_name}» ядерным ударом!`
          )
          .catch(() => {});
      }
    } else if (effectResult.type === 'wipe_air_defense') {
      await bot
        .notifyUser(
          attacker.vk_id,
          `🌊 ЦУНАМИ! Всё ПВО «${defender.state_name}» сметено! Трофеи: +${loot} вирт.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `🌊 Всё ваше ПВО уничтожено!`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `🌊 «${attacker.state_name}» смыл ПВО «${defender.state_name}» ударом Посейдона!`
          )
          .catch(() => {});
      }
    }
  }
}

module.exports = { resolvePendingAttacks };
