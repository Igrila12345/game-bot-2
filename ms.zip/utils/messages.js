'use strict';

const calc = require('../game/calc');
const C = require('../game/constants');

function arsenalToText(obj) {
  const entries = Object.entries(obj || {}).filter(([, qty]) => qty > 0);
  if (!entries.length) return 'пусто';
  return entries.map(([k, v]) => `${k} (${v})`).join(', ');
}

function profileMessage(player, rank, income, clanName) {
  const clanLine = player.clan_id
    ? `👥 Клан: 【${clanName}】 (${player.clan_role === 'leader' ? 'глава' : 'участник'})`
    : '👥 Клан: нет';

  const skillTier = calc.getSkillTier(player.factories);
  const skillLine = skillTier
    ? `🎖️ Скилл: ${skillTier.name} (+${Math.round(skillTier.damageBonus * 100)}% урон, +${Math.round(
        skillTier.airDefenseBonus * 100
      )} п.п. ПВО)`
    : `🎖️ Скилл: нет (откроется от ${C.SKILL_TIERS[0].factories} заводов)`;

  return (
    `🏙️ ГОСУДАРСТВО: ${mentionLink(player.vk_id, player.state_name)}\n` +
    `📍 Координаты: (${player.x}, ${player.y})\n` +
    `🏆 Место в топе заводов: #${rank}\n` +
    `🏭 Заводов: ${player.factories} | Доход: ${income} вирт/час\n` +
    `💰 Баланс: ${calc.formatNumber(player.balance)} вирт\n` +
    `💥 Уничтожено вражеских заводов: ${player.enemy_factories_destroyed || 0}\n` +
    `${skillLine}\n` +
    `⚔️ Арсенал: ${arsenalToText(player.arsenal)}\n` +
    `🛅 ПВО: ${arsenalToText(player.air_defense)}\n` +
    `${clanLine}`
  );
}

function shopMessage(items, balance, msUntilRefresh) {
  const shopGame = require('../game/shop');
  const ordered = shopGame.orderedShopItems(items);
  const weapons = ordered.filter((i) => i.type === 'weapon' && C.WEAPONS[i.key].category !== 'nuke');
  const nukes = ordered.filter((i) => i.type === 'weapon' && C.WEAPONS[i.key].category === 'nuke');
  const ad = ordered.filter((i) => i.type === 'air_defense');

  let text = `🛒 ВОЕННЫЙ МАГАЗИН (обновление через ${calc.formatDuration(msUntilRefresh)})\n💰 Ваш баланс: ${calc.formatNumber(balance)} вирт\n\n`;

  let index = 1;

  if (weapons.length) {
    text += `🔹 Вооружение:\n`;
    for (const item of weapons) {
      const w = C.WEAPONS[item.key];
      text += `${index}. ${item.key} ⭐ ${item.qty} шт. | Цена: ${w.price}\n`;
      index++;
    }
    text += '\n';
  }

  if (ad.length) {
    text += `🔹 ПВО:\n`;
    for (const item of ad) {
      const a = C.AIR_DEFENSE[item.key];
      const coverage = a.covers.length >= 4 ? 'всё' : a.covers.join(', ');
      text += `${index}. ${item.key} ⭐ ${item.qty} шт. | Сбивает: ${coverage} | Шанс: ${Math.round(a.chance * 100)}% | Цена: ${a.price}\n`;
      index++;
    }
    text += '\n';
  }

  if (nukes.length) {
    text += `☢️ Ядерное:\n`;
    for (const item of nukes) {
      const w = C.WEAPONS[item.key];
      text += `${index}. ${item.key} ⭐ ${item.qty} шт. | Цена: ${w.price}\n`;
      index++;
    }
  }

  if (!items.length) {
    text += 'Магазин пуст. Ждите обновления.';
  }

  text += `\n🛍️ Купить: купить [номер или название] [количество]\nПример: купить 3 2  (или: купить Молния 2)`;

  return text.trim();
}

// Кликабельная ссылка на страницу игрока ВКонтакте вида [id123|Название]
function mentionLink(vkId, label) {
  return `[id${vkId}|${label}]`;
}

function topFactoriesMessage(list, viewerCoords) {
  const medals = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
  let text = `🏭 ТОП ИГРОКОВ ПО ЗАВОДАМ\n`;
  list.forEach((p, i) => {
    let distancePart = '';
    if (viewerCoords) {
      const d = Math.round(calc.distanceKm(viewerCoords.x, viewerCoords.y, p.x, p.y));
      distancePart = ` (расстояние: ${d} км)`;
    }
    const crown = i === 0 ? ' 👑' : '';
    text += `${medals[i] || i + 1} ${mentionLink(p.vk_id, p.state_name)} — ${p.factories} заводов${distancePart}${crown}\n`;
  });
  text += `\n💰 Ежедневный бонус за 1-3 места!`;
  return text;
}

function topBalanceMessage(list) {
  const medals = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
  let text = `💰 ТОП ИГРОКОВ ПО ВИРТАМ\n`;
  list.forEach((p, i) => {
    text += `${medals[i] || i + 1} ${mentionLink(p.vk_id, p.state_name)} — ${calc.formatNumber(p.balance)} вирт\n`;
  });
  text += `\n⚠️ Топ-3 платят дополнительный налог: 10% / 7% / 5% в час от суммы сверх 5 000 вирт.`;
  return text;
}

function topClansMessage(list) {
  const medals = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣'];
  let text = `👥 ТОП КЛАНОВ ПО ЗАВОДАМ\n`;
  list.forEach((c, i) => {
    const leaderLink = c.leader_id ? ` (глава: ${mentionLink(c.leader_id, 'профиль')})` : '';
    text += `${medals[i] || i + 1} ${c.name} — ${c.total_factories} заводов (сейф: ${calc.formatNumber(c.vault)})${leaderLink}\n`;
  });
  text += `\n🏆 Ежедневный бонус в сейф за 1-3 места!`;
  return text;
}

const HELP_INTRO =
  `📚 ПОМОЩЬ\n` +
  `Команды работают и с «!», и без него (например: старт или !старт). Работает и в ЛС, и в беседах.\n\n` +
  `Выберите раздел кнопкой под этим сообщением 👇`;

// Разделы помощи по кнопкам. Ключ — короткий код для payload кнопки.
const HELP_SECTIONS = {
  main: {
    label: '🏛️ Основное',
    text:
      `🏛️ ОСНОВНОЕ\n\n` +
      `старт (или: начать) — регистрация\n` +
      `профиль (@юзер) — статистика\n` +
      `переименовать [новое_название] — сменить название (200 вирт)\n` +
      `бонус — забрать ежедневный бонус (раз в 24 ч)\n` +
      `перевод @юзер [сумма] — перевести вирты игроку (раз в 2 ч одному игроку)\n\n` +
      `🎖️ Скиллы (пассивные бонусы за количество заводов):\n` +
      `50 заводов — +15% урон по вражеским заводам, +5 п.п. к перехвату ПВО\n` +
      `150 заводов — +35% урон по вражеским заводам, +10 п.п. к перехвату ПВО`,
  },
  economy: {
    label: '💰 Экономика',
    text:
      `💰 ЭКОНОМИКА\n\n` +
      `построить — построить завод (не более 10 в час)\n` +
      `магазин — ассортимент магазина\n` +
      `купить [название или номер] [количество] — купить оружие/ПВО\n` +
      `арсенал — ваше оружие\n` +
      `лимит — статус лимита заводов (100 → 1000)\n` +
      `лимит расширить — увеличить лимит\n\n` +
      `🔬 Научные центры:\n` +
      `наука — статус (доход 24 вирт/час за центр)\n` +
      `наука построить — построить центр (10 заводов + 500 вирт)\n` +
      `наука расширить — увеличить лимит центров`,
  },
  combat: {
    label: '⚔️ Бой',
    text:
      `⚔️ БОЙ И ПРОИЗВОДСТВО\n\n` +
      `атака @юзер [оружие] [количество] — атаковать\n` +
      `разведка @юзер — узнать расстояние (50 вирт)\n\n` +
      `произвести [оружие] [количество] [заводов] — запустить производство\n` +
      `производство — статус очередей\n` +
      `забрать [оружие] [количество] — забрать готовое оружие`,
  },
  clan: {
    label: '👥 Кланы',
    text:
      `👥 КЛАНЫ\n\n` +
      `клан создать [название] — бесплатно\n` +
      `клан пригласить @юзер\n` +
      `клан вступить [название]\n` +
      `клан кик @юзер\n` +
      `клан бонус [название]\n` +
      `клан сейф\n` +
      `клан инфо\n` +
      `клан покинуть`,
  },
  work: {
    label: '👷 Работа',
    text:
      `👷 РАБОТА И ЖЕТОНЫ\n\n` +
      `работа — пройти мини-игру и сразу получить жетоны, до 40 попыток в день, кулдаун между попытками — 1 минута\n` +
      `склад — открыть кейс за 100 жетонов (заводы, вооружение или вирты)\n` +
      `выбрать [номер] — выбрать коробку в открытом кейсе\n` +
      `обменять — обменять 50 жетонов на 1 завод напрямую, без рандома\n\n` +
      `🤖 Робот:\n` +
      `робот — статус, уровень, доход\n` +
      `робот старт — запустить добычу\n` +
      `робот забрать — забрать накопленный доход\n` +
      `робот прокачать — повысить уровень (до 50)`,
  },
  market: {
    label: '🛎️ Аукцион и промо',
    text:
      `🛎️ АУКЦИОН\n\n` +
      `аукцион — список активных лотов\n` +
      `аукцион [номер] — подробности лота\n` +
      `продать [товар] [кол-во] [старт_цена] [шаг] [часов] — выставить лот\n` +
      `ставка [номер] [сумма] — сделать ставку\n` +
      `отмена [номер] — отменить свой лот (если ставок ещё нет)\n` +
      `лоты — ваши лоты\n\n` +
      `🎟️ Промокоды:\n` +
      `промо [код] — активировать промокод`,
  },
  social: {
    label: '📊 Рейтинги и рефералы',
    text:
      `📊 РЕЙТИНГИ\n\n` +
      `топ заводы\n` +
      `топ вирты\n` +
      `топ кланы\n\n` +
      `👥 Рефералы:\n` +
      `рефералы — ваша реферальная ссылка и статистика приглашений`,
  },
};

const HELP_SECTION_ORDER = ['main', 'economy', 'combat', 'clan', 'work', 'market', 'social'];

module.exports = {
  arsenalToText,
  profileMessage,
  shopMessage,
  topFactoriesMessage,
  topBalanceMessage,
  topClansMessage,
  HELP_INTRO,
  HELP_SECTIONS,
  HELP_SECTION_ORDER,
};
