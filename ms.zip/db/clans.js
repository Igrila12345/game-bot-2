'use strict';

const { query } = require('./pool');

async function getClanById(id) {
  const res = await query('SELECT * FROM clans WHERE id = $1', [id]);
  return res.rows[0] || null;
}

async function getClanByName(name) {
  const res = await query('SELECT * FROM clans WHERE LOWER(name) = LOWER($1)', [name]);
  return res.rows[0] || null;
}

async function createClan(name, leaderId) {
  const res = await query(
    `INSERT INTO clans (name, leader_id) VALUES ($1, $2) RETURNING *`,
    [name, leaderId]
  );
  return res.rows[0];
}

async function getClanMembers(clanId) {
  const res = await query('SELECT * FROM players WHERE clan_id = $1', [clanId]);
  return res.rows;
}

async function addVault(clanId, amount, maxVault) {
  const res = await query(
    `UPDATE clans SET vault = LEAST(vault + $2, $3) WHERE id = $1 RETURNING vault`,
    [clanId, amount, maxVault]
  );
  return res.rows[0] ? Number(res.rows[0].vault) : null;
}

async function spendVault(clanId, amount) {
  const res = await query(
    `UPDATE clans SET vault = vault - $2 WHERE id = $1 AND vault >= $2 RETURNING vault`,
    [clanId, amount]
  );
  return res.rows[0] ? Number(res.rows[0].vault) : null;
}

async function setBonusActive(clanId, bonusKey, until, cooldownUntil) {
  const colUntil = `bonus_${bonusKey}_until`;
  const colCd = `bonus_${bonusKey}_cooldown`;
  await query(
    `UPDATE clans SET ${colUntil} = $2, ${colCd} = $3 WHERE id = $1`,
    [clanId, until, cooldownUntil]
  );
}

async function createInvite(clanId, playerId) {
  await query(
    `INSERT INTO clan_invites (clan_id, player_id) VALUES ($1, $2)
     ON CONFLICT (clan_id, player_id) DO NOTHING`,
    [clanId, playerId]
  );
}

async function hasInvite(clanId, playerId) {
  const res = await query(
    'SELECT 1 FROM clan_invites WHERE clan_id = $1 AND player_id = $2',
    [clanId, playerId]
  );
  return res.rows.length > 0;
}

async function removeInvite(clanId, playerId) {
  await query('DELETE FROM clan_invites WHERE clan_id = $1 AND player_id = $2', [
    clanId,
    playerId,
  ]);
}

async function getClanFactoriesSum(clanId) {
  const res = await query(
    'SELECT COALESCE(SUM(factories), 0) AS total FROM players WHERE clan_id = $1',
    [clanId]
  );
  return Number(res.rows[0].total);
}

async function getTopClansByFactories(limit = 10) {
  const res = await query(
    `SELECT c.id, c.name, c.vault, c.leader_id, COALESCE(SUM(p.factories), 0) AS total_factories
     FROM clans c
     LEFT JOIN players p ON p.clan_id = c.id
     GROUP BY c.id
     ORDER BY total_factories DESC
     LIMIT $1`,
    [limit]
  );
  return res.rows;
}

async function getAllClans() {
  const res = await query('SELECT * FROM clans');
  return res.rows;
}

module.exports = {
  getClanById,
  getClanByName,
  createClan,
  getClanMembers,
  addVault,
  spendVault,
  setBonusActive,
  createInvite,
  hasInvite,
  removeInvite,
  getClanFactoriesSum,
  getTopClansByFactories,
  getAllClans,
};
