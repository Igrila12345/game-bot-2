'use strict';

const { query } = require('./pool');
const C = require('../game/constants');

async function getPlayer(vkId) {
  const res = await query('SELECT * FROM players WHERE vk_id = $1', [vkId]);
  return res.rows[0] || null;
}

async function getPlayerByName(stateName) {
  const res = await query(
    'SELECT * FROM players WHERE LOWER(state_name) = LOWER($1)',
    [stateName]
  );
  return res.rows[0] || null;
}

async function createPlayerStub(vkId, referredBy) {
  const res = await query(
    `INSERT INTO players (vk_id, balance, registration_step, referred_by)
     VALUES ($1, $2, 'awaiting_name', $3)
     ON CONFLICT (vk_id) DO NOTHING
     RETURNING *`,
    [vkId, C.START_BALANCE, referredBy || null]
  );
  if (res.rows[0]) return res.rows[0];
  return getPlayer(vkId);
}

function randCoord() {
  return Math.floor(Math.random() * (C.MAP_MAX - C.MAP_MIN + 1)) + C.MAP_MIN;
}

async function finalizeRegistration(vkId, stateName) {
  const x = randCoord();
  const y = randCoord();
  const res = await query(
    `UPDATE players
     SET state_name = $2, x = $3, y = $4, registration_step = 'done', last_seen = NOW()
     WHERE vk_id = $1
     RETURNING *`,
    [vkId, stateName, x, y]
  );
  return res.rows[0];
}

async function touchLastSeen(vkId) {
  await query('UPDATE players SET last_seen = NOW() WHERE vk_id = $1', [vkId]);
}

async function updateBalance(vkId, delta) {
  const res = await query(
    'UPDATE players SET balance = balance + $2 WHERE vk_id = $1 RETURNING balance',
    [vkId, delta]
  );
  return res.rows[0] ? Number(res.rows[0].balance) : null;
}

async function setBalance(vkId, value) {
  await query('UPDATE players SET balance = $2 WHERE vk_id = $1', [vkId, value]);
}

async function renamePlayer(vkId, newName) {
  await query('UPDATE players SET state_name = $2 WHERE vk_id = $1', [vkId, newName]);
}

async function addFactories(vkId, count, isGoldMine) {
  const res = await query(
    `UPDATE players
     SET factories = factories + $2,
         gold_mine_count = gold_mine_count + $3
     WHERE vk_id = $1
     RETURNING *`,
    [vkId, count, isGoldMine ? 1 : 0]
  );
  return res.rows[0];
}

async function setArsenal(vkId, arsenal) {
  await query('UPDATE players SET arsenal = $2::jsonb WHERE vk_id = $1', [
    vkId,
    JSON.stringify(arsenal),
  ]);
}

async function setAirDefense(vkId, airDefense) {
  await query('UPDATE players SET air_defense = $2::jsonb WHERE vk_id = $1', [
    vkId,
    JSON.stringify(airDefense),
  ]);
}

async function addToArsenal(vkId, weaponKey, qty) {
  const player = await getPlayer(vkId);
  const arsenal = player.arsenal || {};
  arsenal[weaponKey] = (arsenal[weaponKey] || 0) + qty;
  await setArsenal(vkId, arsenal);
  return arsenal;
}

async function addToAirDefense(vkId, adKey, qty) {
  const player = await getPlayer(vkId);
  const ad = player.air_defense || {};
  ad[adKey] = (ad[adKey] || 0) + qty;
  await setAirDefense(vkId, ad);
  return ad;
}

async function setBlockedFactories(vkId, blockedList) {
  await query('UPDATE players SET blocked_factories = $2::jsonb WHERE vk_id = $1', [
    vkId,
    JSON.stringify(blockedList),
  ]);
}

async function setRadiationUntil(vkId, until) {
  await query('UPDATE players SET radiation_until = $2 WHERE vk_id = $1', [vkId, until]);
}

async function setClan(vkId, clanId, role) {
  await query('UPDATE players SET clan_id = $2, clan_role = $3 WHERE vk_id = $1', [
    vkId,
    clanId,
    role,
  ]);
}

async function getTopByFactories(limit = 10) {
  const res = await query(
    `SELECT * FROM players WHERE registration_step = 'done' ORDER BY factories DESC, balance DESC LIMIT $1`,
    [limit]
  );
  return res.rows;
}

async function getTopByBalance(limit = 10) {
  const res = await query(
    `SELECT * FROM players WHERE registration_step = 'done' ORDER BY balance DESC LIMIT $1`,
    [limit]
  );
  return res.rows;
}

async function getAllActivePlayers() {
  const res = await query(`SELECT * FROM players WHERE registration_step = 'done'`);
  return res.rows;
}

async function destroyOneFactory(vkId) {
  const player = await getPlayer(vkId);
  if (!player || player.factories <= 0) return null;
  // Восстановление заводов отключено: снесённый завод пропадает навсегда,
  // игрока это стимулирует достраивать новые заводы вместо ожидания.
  await query(
    'UPDATE players SET factories = factories - 1, destroyed_factories = destroyed_factories + 1 WHERE vk_id = $1',
    [vkId]
  );
  return true;
}

// ===================== ХП ЗАВОДОВ (накопительный урон) =====================

async function setFactoryDamage(vkId, value) {
  await query('UPDATE players SET factory_damage = $2 WHERE vk_id = $1', [vkId, value]);
}

async function addFactoryDamage(vkId, delta) {
  const res = await query(
    'UPDATE players SET factory_damage = factory_damage + $2 WHERE vk_id = $1 RETURNING factory_damage',
    [vkId, delta]
  );
  return res.rows[0] ? res.rows[0].factory_damage : null;
}

// ===================== ЕЖЕДНЕВНЫЙ БОНУС =====================

async function setLastDailyBonus(vkId, when) {
  await query('UPDATE players SET last_daily_bonus = $2 WHERE vk_id = $1', [vkId, when]);
}

// ===================== СТАТИСТИКА =====================

async function incrementEnemyFactoriesDestroyed(vkId, count) {
  if (!count) return;
  await query(
    'UPDATE players SET enemy_factories_destroyed = enemy_factories_destroyed + $2 WHERE vk_id = $1',
    [vkId, count]
  );
}

// ===================== ПИТОМЕЦ-РОБОТ =====================

async function setPetLevel(vkId, level) {
  await query('UPDATE players SET pet_level = $2 WHERE vk_id = $1', [vkId, level]);
}

async function setPetMiningStarted(vkId, when) {
  await query('UPDATE players SET pet_mining_started_at = $2 WHERE vk_id = $1', [vkId, when]);
}

async function setPetLastCollected(vkId, when) {
  await query('UPDATE players SET pet_last_collected_at = $2 WHERE vk_id = $1', [vkId, when]);
}

// ===================== РАБОТА И ЖЕТОНЫ =====================

async function addTokens(vkId, delta) {
  const res = await query(
    'UPDATE players SET tokens = tokens + $2 WHERE vk_id = $1 RETURNING tokens',
    [vkId, delta]
  );
  return res.rows[0] ? res.rows[0].tokens : null;
}

async function incrementWorkCount(vkId, dayStr) {
  await query(
    `UPDATE players SET work_count_today = work_count_today + 1, last_work_time = NOW(), work_day = $2 WHERE vk_id = $1`,
    [vkId, dayStr]
  );
}

async function resetWorkDay(vkId, dayStr) {
  await query('UPDATE players SET work_count_today = 0, work_day = $2 WHERE vk_id = $1', [vkId, dayStr]);
}

// Текущая сессия мини-игры "работа" (раунд, коробки, дедлайн). NULL — сессии нет.
async function setWorkSession(vkId, session) {
  await query('UPDATE players SET work_session = $2::jsonb WHERE vk_id = $1', [
    vkId,
    session ? JSON.stringify(session) : null,
  ]);
}

// ===================== РЕФЕРАЛЬНАЯ ПРОГРАММА =====================

async function setReferralRewarded(vkId) {
  await query('UPDATE players SET referral_rewarded = TRUE WHERE vk_id = $1', [vkId]);
}

async function countReferrals(vkId) {
  const res = await query(
    `SELECT COUNT(*)::int AS count FROM players WHERE referred_by = $1 AND registration_step = 'done'`,
    [vkId]
  );
  return res.rows[0] ? res.rows[0].count : 0;
}

// ===================== НАУЧНЫЕ ЦЕНТРЫ =====================

async function addScienceCenters(vkId, count) {
  await query('UPDATE players SET science_centers = science_centers + $2 WHERE vk_id = $1', [
    vkId,
    count,
  ]);
}

async function setScienceLimitLevel(vkId, level) {
  await query('UPDATE players SET science_limit_level = $2 WHERE vk_id = $1', [vkId, level]);
}

// ===================== ЛИМИТ ЗАВОДОВ =====================

async function setFactoryLimitLevel(vkId, level) {
  await query('UPDATE players SET factory_limit_level = $2 WHERE vk_id = $1', [vkId, level]);
}

async function decrementFactories(vkId, count) {
  await query('UPDATE players SET factories = GREATEST(factories - $2, 0) WHERE vk_id = $1', [
    vkId,
    count,
  ]);
}

module.exports = {
  getPlayer,
  getPlayerByName,
  createPlayerStub,
  finalizeRegistration,
  touchLastSeen,
  updateBalance,
  setBalance,
  renamePlayer,
  addFactories,
  setArsenal,
  setAirDefense,
  addToArsenal,
  addToAirDefense,
  setBlockedFactories,
  setRadiationUntil,
  setClan,
  getTopByFactories,
  getTopByBalance,
  getAllActivePlayers,
  destroyOneFactory,
  setFactoryDamage,
  addFactoryDamage,
  setLastDailyBonus,
  incrementEnemyFactoriesDestroyed,
  setPetLevel,
  setPetMiningStarted,
  setPetLastCollected,
  addTokens,
  incrementWorkCount,
  resetWorkDay,
  setWorkSession,
  addScienceCenters,
  setScienceLimitLevel,
  setFactoryLimitLevel,
  decrementFactories,
  setReferralRewarded,
  countReferrals,
};
