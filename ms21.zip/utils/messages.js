'use strict';

const calc = require('../game/calc');
const C = require('../game/constants');

function arsenalToText(obj) {
  const entries = Object.entries(obj || {}).filter(([, qty]) => qty > 0);
  if (!entries.length) return 'пусто';
  return entries.map(([k, v]) => `${k} (${v})`).join(', ');
}

function profileMessage(player, income, clanName) {
  const clanLine = player.clan_id
    ? `👥 Клан: 【${clanName}】 (${player.clan_role === 'leader' ? 'глава' : player.clan_role === 'deputy' ? 'зам' : 'участник'})`
    : '👥 Клан: нет';

  const skillTier = calc.getSkillTier(player.factories);
  const skillLine = skillTier
    ? `🎖️ Скилл: ${skillTier.name} (+${Math.round(skillTier.damageBonus * 100)}% урон, +${Math.round(
        skillTier.airDefenseBonus * 100
      )} п.п. ПВО)`
    : `🎖️ Скилл: нет (откроется от ${C.SKILL_TIERS[0].factories} заводов)`;

  const vipLine = calc.isVipActive(player)
    ? `👑 VIP до ${new Date(player.vip_until).toLocaleDateString('ru-RU')} (+${Math.round(
        C.VIP_INCOME_BONUS * 100
      )}% к доходу)\n`
    : '';

  const minerLine = calc.isMinerActive(player)
    ? `⛏️ Майнер до ${new Date(player.miner_until).toLocaleDateString('ru-RU')} (пассивно приносит вирты и жетоны)\n`
    : '';

  const superRobotLevel = player.super_robot_level || 0;
  const superRobotLine = superRobotLevel > 0 ? `🤖 Суперробот: ур. ${superRobotLevel}/${C.SUPER_ROBOT_MAX_LEVEL}\n` : '';

  const scienceCenters = player.science_centers || 0;
  const scienceLimit = calc.currentScienceLimit(player.science_limit_level);
  const scienceLine = `🔬 Научных центров: ${scienceCenters}/${scienceLimit}\n`;

  const enemyDestroyed = player.enemy_factories_destroyed || 0;
  const destroyedLine = `💥 Уничтожено вражеских заводов: ${calc.formatNumber(enemyDestroyed)}\n`;

  const arsenalText = arsenalToText(player.arsenal);
  const arsenalLine = arsenalText && arsenalText !== 'пусто' ? `⚔️ Арсенал: ${arsenalText}\n` : '';

  const airDefenseText = arsenalToText(player.air_defense);
  const airDefenseLine = airDefenseText && airDefenseText !== 'пусто' ? `🛅 ПВО: ${airDefenseText}\n` : '';

  return (
    `🏙️ ГОСУДАРСТВО: ${mentionLink(player.vk_id, player.state_name)}\n` +
    `${vipLine}` +
    `${minerLine}` +
    `${superRobotLine}` +
    `💰 Баланс: ${calc.formatNumber(player.balance)} вирт\n` +
    `🏭 Заводов: ${player.factories} | Доход: ${income} вирт/час\n` +
    `${destroyedLine}` +
    `${scienceLine}` +
    `${skillLine}\n` +
    `${arsenalLine}` +
    `${airDefenseLine}` +
    `${clanLine}`
  );
}

const CATEGORY_LABELS = {
  drone: '\ud83d\udee9\ufe0f БПЛА (слабее ракет)',
  missile: '\ud83d\ude80 Ракеты (сильнее БПЛА)',
  nuke: '\u2622\ufe0f Ядерное (сильнее всех ракет)',
  saboteur: '\ud83d\udd76\ufe0f Диверсанты',
};

const CATEGORY_ORDER = ['drone', 'missile', 'nuke', 'saboteur'];

// Русское склонение "завод/завода/заводов" по числу
function pluralFactories(n) {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return 'завод';
  if ([2, 3, 4].includes(mod10) && ![12, 13, 14].includes(mod100)) return 'завода';
  return 'заводов';
}

// "Сколько заводов сносит" одним попаданием этого оружия — короткая и понятная фраза.
// Единая логика для ЛЮБОГО оружия с effect 'block_random' или 'nuke_strike':
//   • factoriesPerHit — сильное оружие, сносит несколько заводов за 1 попадание
//   • hitsToDestroy    — слабое оружие, нужно несколько попаданий на 1 завод
function destroyDescription(w) {
  if (w.factoriesPerHit) {
    return w.factoriesPerHit === 1
      ? `💀 Сносит 1 завод с ОДНОГО попадания`
      : `💀 Сносит ${w.factoriesPerHit} ${pluralFactories(w.factoriesPerHit)} с ОДНОГО попадания`;
  }
  if (w.hitsToDestroy) {
    return w.hitsToDestroy === 1
      ? `💀 Сносит 1 завод с ОДНОГО попадания`
      : `💀 Сносит 1 завод за ${w.hitsToDestroy} попадания`;
  }
  return '';
}

// Доп. эффекты у ядерного оружия (помимо сноса заводов)
function extraEffectDescription(w) {
  const parts = [];
  if (w.radiation) parts.push('☢️ + радиация: -20% дохода на 2 ч всем оставшимся заводам');
  if (w.wipeAirDefense) parts.push('🌊 + уничтожает ВСЁ ПВО противника');
  return parts;
}

// Короткое описание эффекта одного запуска — используется в сообщении об атаке (команда "атака")
function weaponEffectSummary(w) {
  const lines = [destroyDescription(w), ...extraEffectDescription(w)].filter(Boolean);
  return lines.join('\n');
}

// Полный список оружия и ПВО с характеристиками и ценами (команда "оружие")
function weaponsInfoMessage() {
  let text = `📋 ОРУЖИЕ — ХАРАКТЕРИСТИКИ И ЦЕНЫ\n`;

  for (const category of CATEGORY_ORDER) {
    const entries = Object.values(C.WEAPONS)
      .filter((w) => w.category === category)
      .sort((a, b) => (a.tier || 0) - (b.tier || 0));
    if (!entries.length) continue;
    text += `\n${CATEGORY_LABELS[category] || category}:\n`;
    for (const w of entries) {
      const flightPer100km = w.speedKmh ? `${Math.round((100 / w.speedKmh) * 3600)} сек/100км` : 'н/д';
      text += `\n${w.tier ? `Ур.${w.tier} ` : ''}${w.key}\n`;
      text += `💰 Цена: ${w.price} вирт\n`;
      text += `🚀 Скорость: ${flightPer100km}\n`;
      text += `🔫 За 1 атаку: до ${w.maxPerAttack} шт.\n`;
      text += `${destroyDescription(w)}\n`;
      for (const extra of extraEffectDescription(w)) text += `${extra}\n`;
      text += `🏭 Произвести самому: ${w.productionCost} вирт, ${w.productionMinutes} мин (ускорено в ${C.PRODUCTION_SPEED_MULTIPLIER} раза)\n`;
    }
  }

  text += `\n🛡️ ПВО:\n`;
  for (const a of Object.values(C.AIR_DEFENSE)) {
    const coverage = a.covers.length >= 4 ? 'всё' : a.covers.join(', ');
    text += `• ${a.key} — цена: ${a.price} вирт | сбивает: ${coverage} | шанс: ${Math.round(a.chance * 100)}%\n`;
  }

  text += `\n🛍️ Купить в магазине: магазин → купить [название] [количество]`;

  return text.trim();
}

// Команда "вооружение": подробный гайд "как произвести оружие самому" — синтаксис команды,
// откуда берётся стоимость и время, какие бонусы ускоряют производство, и живой пример.
function productionGuideMessage() {
  let text = `🏭 КАК ПРОИЗВЕСТИ ОРУЖИЕ САМОМУ\n\n`;

  text += `Синтаксис:\n`;
  text += `произвести [оружие] [количество] [заводов]\n`;
  text += `Пример: произвести Калибр 5 10\n`;
  text += `(запустить производство 5 шт. «Калибр», выделив под это 10 своих заводов)\n\n`;

  text += `📋 Как это работает:\n`;
  text += `1️⃣ Указываете название оружия (как в списке команды «оружие»), сколько штук хотите\n` +
    `   и сколько СВОБОДНЫХ заводов выделяете под производство.\n`;
  text += `2️⃣ Пока заводы заняты производством, они НЕ приносят обычный доход — деньги вместо\n` +
    `   этого идут в производимое оружие.\n`;
  text += `3️⃣ Итоговая стоимость = цена производства оружия (см. «оружие») × количество.\n` +
    `   Это ДЕШЕВЛЕ, чем купить в магазине, но нужно подождать.\n`;
  text += `4️⃣ Время изготовления зависит от количества выделенных заводов: чем больше заводов —\n` +
    `   тем быстрее. Базовое время производства уже ускорено в ${C.PRODUCTION_SPEED_MULTIPLIER} раза.\n`;
  text += `5️⃣ Если выделяете ${C.MASS_PRODUCTION_FACTORY_THRESHOLD}+ заводов сразу — дополнительный бонус:\n` +
    `   ещё −${Math.round(C.MASS_PRODUCTION_TIME_BONUS * 100)}% ко времени производства.\n\n`;

  text += `📦 Когда оружие готово:\n`;
  text += `забрать [оружие] [количество] — забрать готовое оружие в арсенал (иначе оно просто ждёт)\n` +
    `производство — посмотреть статус всех своих очередей и когда что будет готово\n\n`;

  text += `💰 Цены на производство и время для каждого вида оружия — в команде «оружие».\n`;
  text += `🛒 Купить готовое оружие без ожидания — в команде «магазин».`;

  return text.trim();
}

// Описание содержимого кейса и шансов выпадения (команда "склад" / "кейс шансы")
function warehouseRewardLabel(reward) {
  const qtyPart = reward.min === reward.max ? `${reward.min}` : `${reward.min}–${reward.max}`;
  switch (reward.type) {
    case 'virts':
      return `💰 Вирты: ${qtyPart}`;
    case 'tokens':
      return `🪙 Жетоны: ${qtyPart}`;
    case 'factory':
      return `🏭 Бесплатный завод: ${qtyPart} шт.`;
    case 'gold_mine':
      return `✨ Золотая жила (доход x2)`;
    case 'weapon':
      return `⚔️ ${reward.key}: ${qtyPart} шт.`;
    case 'air_defense':
      return `🛡️ ${reward.key}: ${qtyPart} шт.`;
    default:
      return `${reward.key || reward.type}: ${qtyPart}`;
  }
}

function warehouseRewardsMessage() {
  let text = `📦 СОДЕРЖИМОЕ КЕЙСА И ШАНСЫ (цена кейса: ${C.WAREHOUSE_COST_TOKENS} жетонов)\n\n`;
  const sorted = [...C.WAREHOUSE_REWARDS].sort((a, b) => b.chance - a.chance);
  for (const reward of sorted) {
    text += `${reward.chance}% — ${warehouseRewardLabel(reward)}\n`;
  }
  return text.trim();
}

function shopMessage(items, player, msUntilRefresh) {
  const shopGame = require('../game/shop');
  const calcMod = require('../game/calc');
  const ordered = shopGame.orderedShopItems(items);
  const weapons = ordered.filter((i) => i.type === 'weapon' && C.WEAPONS[i.key].category !== 'nuke');
  const nukes = ordered.filter((i) => i.type === 'weapon' && C.WEAPONS[i.key].category === 'nuke');
  const ad = ordered.filter((i) => i.type === 'air_defense');

  let text = `🛒 ВОЕННЫЙ МАГАЗИН (обновление через ${calc.formatDuration(msUntilRefresh)})\n💰 Ваш баланс: ${calc.formatNumber(player.balance)} вирт\n\n`;

  let index = 1;

  if (weapons.length) {
    text += `🔹 Вооружение:\n`;
    for (const item of weapons) {
      const w = C.WEAPONS[item.key];
      text += `${index}. ${item.key} ⭐ ${item.qty} шт. | Цена: ${w.price}\n`;
      index++;
    }
    text += '\n';
  }

  if (ad.length) {
    text += `🔹 ПВО:\n`;
    for (const item of ad) {
      const a = C.AIR_DEFENSE[item.key];
      const coverage = a.covers.length >= 4 ? 'всё' : a.covers.join(', ');
      text += `${index}. ${item.key} ⭐ ${item.qty} шт. | Сбивает: ${coverage} | Шанс: ${Math.round(a.chance * 100)}% | Цена: ${a.price}\n`;
      index++;
    }
    text += '\n';
  }

  if (nukes.length) {
    text += `☢️ Ядерное:\n`;
    for (const item of nukes) {
      const w = C.WEAPONS[item.key];
      text += `${index}. ${item.key} ⭐ ${item.qty} шт. | Цена: ${w.price}\n`;
      index++;
    }
  }

  if (!items.length) {
    text += 'Магазин пуст. Ждите обновления.';
  }

  text += `\n🛍️ Купить: купить [номер или название] [количество]\nПример: купить 3 2  (или: купить Молния 2)`;

  // Расширение лимита заводов — тоже часть магазина, показываем прямо тут
  const level = player.factory_limit_level || 0;
  const currentLimit = calcMod.currentFactoryLimit(level);
  const nextRow = C.FACTORY_LIMIT_LEVELS.find((l) => l.level === level + 1);
  text += `\n\n🏭 Лимит заводов: ${currentLimit}`;
  if (nextRow) {
    text += ` (расширить до ${nextRow.limit} за ${calc.formatNumber(nextRow.cost)} вирт — лимит расширить)`;
  } else {
    text += ` (максимум достигнут)`;
  }

  return text.trim();
}

// Кликабельная ссылка на страницу игрока ВКонтакте вида [id123|Название].
// Обратите внимание: такая ссылка отправляет пользователю уведомление-упоминание
// (пинг) в VK — это ожидаемо и используется в том числе в топах по явному запросу,
// чтобы имена в топах были кликабельными.
function mentionLink(vkId, label) {
  return `[id${vkId}|${label}]`;
}

// Обычное имя без ссылки/пинга — доступно на случай, если где-то понадобится
// показать имя без уведомления адресата.
function plainName(vkId, label) {
  return label;
}

function topFactoriesMessage(list, viewerCoords) {
  const medals = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
  let text = `🏭 ТОП ИГРОКОВ ПО ЗАВОДАМ\n`;
  list.forEach((p, i) => {
    let distancePart = '';
    if (viewerCoords) {
      const d = Math.round(calc.distanceKm(viewerCoords.x, viewerCoords.y, p.x, p.y));
      distancePart = ` (расстояние: ${d} км)`;
    }
    const crown = i === 0 ? ' 👑' : '';
    text += `${medals[i] || i + 1} ${mentionLink(p.vk_id, p.state_name)} — ${p.factories} заводов${distancePart}${crown}\n`;
  });
  text += `\n💰 Ежедневный бонус за 1-3 места!`;
  return text;
}

function topBalanceMessage(list) {
  const medals = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
  let text = `💰 ТОП ИГРОКОВ ПО ВИРТАМ\n`;
  list.forEach((p, i) => {
    text += `${medals[i] || i + 1} ${mentionLink(p.vk_id, p.state_name)} — ${calc.formatNumber(p.balance)} вирт\n`;
  });
  text += `\n⚠️ Топ-3 платят дополнительный налог: 10% / 7% / 5% в час от суммы сверх 5 000 вирт.`;
  return text;
}

function topRobotMessage(list) {
  const robotGame = require('../game/robot');
  const medals = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
  let text = `🤖 ТОП ИГРОКОВ ПО УРОВНЮ РОБОТА\n`;
  list.forEach((p, i) => {
    const level = p.robot_level || 1;
    text += `${medals[i] || i + 1} ${mentionLink(p.vk_id, p.state_name)} — ур. ${level} (${robotGame.levelName(
      level
    )})\n`;
  });
  return text.trim();
}

function topSuperRobotMessage(list) {
  const superRobotGame = require('../game/superRobot');
  const medals = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
  if (!list.length) {
    return `🤖 ТОП ИГРОКОВ ПО УРОВНЮ СУПЕРРОБОТА\n\nПока никто не построил суперробота. Постройка: суперробот прокачать`;
  }
  let text = `🤖 ТОП ИГРОКОВ ПО УРОВНЮ СУПЕРРОБОТА\n`;
  list.forEach((p, i) => {
    const level = p.super_robot_level || 0;
    text += `${medals[i] || i + 1} ${mentionLink(p.vk_id, p.state_name)} — ур. ${level} (${superRobotGame.levelName(
      level
    )})\n`;
  });
  return text.trim();
}

function topClansMessage(list) {
  const medals = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣'];
  let text = `👥 ТОП КЛАНОВ ПО ЗАВОДАМ\n`;
  list.forEach((c, i) => {
    const leaderLine = c.leader_id ? ` (глава: ${mentionLink(c.leader_id, 'профиль')})` : '';
    text += `${medals[i] || i + 1} ${c.name} — ${c.total_factories} заводов (сейф: ${calc.formatNumber(c.vault)})${leaderLine}\n`;
  });
  text += `\n🏆 Ежедневный бонус в сейф за 1-3 места!`;
  return text;
}

const HELP_INTRO =
  `📚 ПОМОЩЬ\n` +
  `Команды работают и с «!», и без него (например: старт или !старт). Работает и в ЛС, и в беседах.\n` +
  `Новичок? Нажмите «🧭 С чего начать» ниже или напишите гайд.\n\n` +
  `Выберите раздел кнопкой под этим сообщением 👇`;

// Разделы помощи по кнопкам. Ключ — короткий код для payload кнопки.
const HELP_SECTIONS = {
  guide: {
    label: '🧭 С чего начать',
    text:
      `🧭 С ЧЕГО НАЧАТЬ (пошаговый гайд)\n\n` +
      `1️⃣ старт — регистрация, придумайте название своего государства\n` +
      `2️⃣ построить — стройте заводы, они приносят доход каждый час (в профиль → «Доход»)\n` +
      `3️⃣ профиль — проверяйте баланс, доход и место в топе в любой момент\n` +
      `4️⃣ магазин → купить [номер] [количество] — покупайте оружие и ПВО, пока копите на заводы\n` +
      `5️⃣ атака @юзер [оружие] [количество] — атакуйте других игроков, чтобы получить трофеи вирт\n` +
      `6️⃣ произвести [оружие] [количество] [заводов] — производите оружие сами на своих заводах, дешевле магазина\n` +
      `7️⃣ работа — бесплатная мини-игра на жетоны (до 40 раз в день), жетоны меняются на заводы и призы через склад\n` +
      `8️⃣ клан создать [название] (или клан вступить [название]) — вступайте в клан, чтобы получать бонусы из общего сейфа\n\n` +
      `💡 Совет: сначала стройте заводы (это основа дохода), затем покупайте ПВО для защиты, и только потом — оружие для атак.\n` +
      `📖 Остальные разделы помощи ниже раскрывают каждую механику подробнее.`,
  },
  main: {
    label: '🏛️ Основное',
    text:
      `🏛️ ОСНОВНОЕ\n\n` +
      `старт (или: начать) — регистрация\n` +
      `профиль (@юзер) — статистика\n` +
      `переименовать [новое_название] — сменить название (200 вирт)\n` +
      `бонус — забрать ежедневный бонус (раз в 24 ч)\n` +
      `перевод @юзер [сумма] — перевести вирты игроку (раз в 2 ч одному игроку)\n` +
      `донат — прайс-лист VIP / майнера / суперробота\n\n` +
      `🎖️ Скиллы (пассивные бонусы за количество заводов):\n` +
      `50 заводов — +15% урон по вражеским заводам, +5 п.п. к перехвату ПВО\n` +
      `150 заводов — +35% урон по вражеским заводам, +10 п.п. к перехвату ПВО`,
  },
  economy: {
    label: '💰 Экономика',
    text:
      `💰 ЭКОНОМИКА\n\n` +
      `построить [количество] — построить завод(ы), максимум ${C.FACTORY_BUILD_MAX_PER_COMMAND} за раз, не более 10 в час\n` +
      `оружие — характеристики, эффекты и цены всего оружия и ПВО (с производством)\n` +
      `вооружение — гайд «как произвести оружие самому» (синтаксис, стоимость, бонусы, пример)\n` +
      `магазин — ассортимент магазина\n` +
      `купить [название или номер] [количество] — купить оружие/ПВО\n` +
      `арсенал — ваше оружие\n` +
      `лимит — статус лимита заводов (100 → 1000)\n` +
      `лимит расширить — увеличить лимит\n\n` +
      `🔬 Научные центры:\n` +
      `наука — статус (доход 24 вирт/час за центр)\n` +
      `наука построить — построить центр (10 заводов + 500 вирт)\n` +
      `наука расширить — увеличить лимит центров`,
  },
  combat: {
    label: '⚔️ Бой',
    text:
      `⚔️ БОЙ И ПРОИЗВОДСТВО\n\n` +
      `атака @юзер [оружие] [количество] — атаковать\n` +
      `разведка @юзер — узнать расстояние (50 вирт)\n\n` +
      `🌊 Волновая тактика: кулдауна на цель больше нет — атаковать одного и того же игрока можно ` +
      `сколько угодно раз подряд, ограничивает только запас оружия в вашем арсенале. Каждая единица ` +
      `оружия теперь пробивается через ПВО отдельно, поэтому можно сначала закидать дешёвыми дронами, ` +
      `чтобы истощить ПВО противника, а затем добить дорогим оружием по ослабленной обороне.\n\n` +
      `произвести [оружие] [количество] [заводов] — запустить производство\n` +
      `производство — статус очередей\n` +
      `забрать [оружие] [количество] — забрать готовое оружие\n\n` +
      `🦾 Суперробот — отдельный боевой юнит (см. раздел «Работа»): суперробот атака @юзер\n\n` +
      `🔔 Уведомления:\n` +
      `Про каждую атаку в игре приходит короткий лог всем игрокам. Отключить: уведомления откл\n` +
      `Включить обратно: уведомления вкл`,
  },
  clan: {
    label: '👥 Кланы',
    text:
      `👥 КЛАНЫ\n\n` +
      `клан создать [название] — бесплатно\n` +
      `клан пригласить @юзер — только глава\n` +
      `клан вступить [название]\n` +
      `клан кик @юзер — только глава\n` +
      `клан зам @юзер — назначить зама (только глава)\n` +
      `клан снять_зама @юзер — снять зама (только глава)\n` +
      `клан бонус [форсаж/эшелон/индустриализация] — только глава, тратит сейф\n` +
      `клан инфо — список участников и уровень сейфа\n` +
      `клан покинуть — если вы глава, главенство автоматически передаётся другому участнику (заму, если есть)\n` +
      `клан удалить [название] — распустить клан безвозвратно (только глава, нужно повторить название, сейф должен быть пуст)\n\n` +
      `🏦 Сейф клана (казна):\n` +
      `клан сейф — баланс, вместимость, уровень и прогресс\n` +
      `клан сейф пополнить [сумма] — пополнить может любой участник из своего баланса\n` +
      `клан сейф забрать [сумма] — снять на свой баланс может глава или зам\n\n` +
      `📈 Уровень сейфа растёт от ВСЕХ поступлений за всё время (30% налог с дохода участников + ручные взносы) — ` +
      `10 000 собранных вирт = 1 уровень, до 100 уровней. Каждый уровень даёт +1% к вместимости сейфа. ` +
      `Траты и снятие главой уровень не понижают.`,
  },
  work: {
    label: '👷 Работа',
    text:
      `👷 РАБОТА И ЖЕТОНЫ\n\n` +
      `работа — меню статистики (сколько попыток сделано, жетоны) с кнопками: обмен на заводы, кейс, начать работу\n` +
      `склад — открыть кейс за 100 жетонов + показывает содержимое и шансы выпадения\n` +
      `склад шансы — только шансы и содержимое кейса, без открытия\n` +
      `выбрать [номер] — выбрать коробку в открытом кейсе\n` +
      `обменять — обменять 50 жетонов на 1 завод напрямую, без рандома\n\n` +
      `🤖 Робот (мгновенная прибыль, без ожидания, НЕ атакует игроков):\n` +
      `робот — мгновенно собрать доход виртами (доступно раз в час)\n` +
      `мой робот — статистика: уровень, доход, кулдауны\n` +
      `робот прокачать — повысить уровень (до ${C.ROBOT_MAX_LEVEL}, каждый уровень дороже предыдущего, цена в виртах)\n` +
      `роботы — список всех ${C.ROBOT_MAX_LEVEL} уровней робота: имена, цена прокачки, доход, жетоны\n` +
      `отправить — мгновенно получить жетоны от робота (доступно раз в час, чем выше уровень — тем больше)\n` +
      `топ робот — рейтинг игроков по уровню робота\n\n` +
      `🦾 Суперробот (боевой юнит, качается ВИРТАМИ, качать тяжело):\n` +
      `суперробот — статус: уровень, сила атаки, кулдаун\n` +
      `суперробот прокачать — повысить уровень за вирты (до ${C.SUPER_ROBOT_MAX_LEVEL}, цена растёт очень быстро)\n` +
      `суперробот атака @юзер — атаковать игрока: сносит заводы напрямую (1 ур. = 1 завод, дальше сильнее), ` +
      `перехватить может только ПВО С-400 Триумф противника (если получится — защитник получает крупную награду виртами, робот не теряется)\n` +
      `суперроботы — список всех ${C.SUPER_ROBOT_MAX_LEVEL} уровней суперробота\n` +
      `топ суперробот — рейтинг игроков по уровню суперробота\n\n` +
      `⛏️ Майнер (донат-предмет, выдаётся администратором):\n` +
      `майнер — проверить статус (активен ли, до какого числа)\n` +
      `Пока активен — каждый час пассивно (без ваших действий) приносит немного вирт и с шансом жетон.`,
  },
  market: {
    label: '🛎️ Аукцион и промо',
    text:
      `🛎️ АУКЦИОН\n\n` +
      `аукцион — список активных лотов\n` +
      `аукцион [номер] — подробности лота\n` +
      `продать [товар] [кол-во] [старт_цена] [шаг] [часов] — выставить лот\n` +
      `ставка [номер] [сумма] — сделать ставку\n` +
      `отмена [номер] — отменить свой лот (если ставок ещё нет)\n` +
      `лоты — ваши лоты\n\n` +
      `🎟️ Промокоды:\n` +
      `промо [код] — активировать промокод`,
  },
  social: {
    label: '📊 Рейтинги',
    text:
      `📊 РЕЙТИНГИ\n\n` +
      `топ заводы\n` +
      `топ вирты\n` +
      `топ кланы`,
  },
};

const HELP_SECTION_ORDER = ['guide', 'main', 'economy', 'combat', 'clan', 'work', 'market', 'social'];

module.exports = {
  arsenalToText,
  mentionLink,
  plainName,
  profileMessage,
  shopMessage,
  weaponsInfoMessage,
  productionGuideMessage,
  weaponEffectSummary,
  pluralFactories,
  warehouseRewardsMessage,
  topFactoriesMessage,
  topBalanceMessage,
  topRobotMessage,
  topClansMessage,
  HELP_INTRO,
  HELP_SECTIONS,
  HELP_SECTION_ORDER,
};
