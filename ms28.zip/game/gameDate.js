'use strict';

// Дата "по игре" — всегда по московскому времени, чтобы дневные лимиты сбрасывались
// ровно в 00:00 МСК (как и остальные ежедневные события), а не в полночь по системному
// часовому поясу сервера. Тот же принцип, что и todayStr() в game/work.js.
function todayStr() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Moscow',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date());
  const map = {};
  for (const p of parts) map[p.type] = p.value;
  return `${map.year}-${map.month}-${map.day}`; // YYYY-MM-DD
}

module.exports = { todayStr };
