'use strict';

const Jimp = require('jimp');
const C = require('./constants');
const casino = require('./casino');

const SIZE = 520;
const CENTER = SIZE / 2;
const OUTER_R = 240;
const INNER_R = 70; // ступица в центре, не закрашиваем секторами
const RIM_R = 252; // тонкий обод по внешнему краю

const BG_COLOR = 0x14181fff;
const RED_COLOR = 0xc62828ff;
const BLACK_COLOR = 0x1a1a1aff;
const GREEN_COLOR = 0x2e7d32ff;
const RIM_COLOR = 0xd4af37ff; // золотой обод
const HUB_COLOR = 0x2a2f3aff;
const HIGHLIGHT_COLOR = 0xffffffff;
const BLUR_STREAK_COLOR = 0xffffff33; // полупрозрачные штрихи-"смаз" для ощущения вращения

const SLOT_ANGLE = (2 * Math.PI) / C.CASINO_SLOT_COUNT;

function colorHex(color) {
  if (color === 'red') return RED_COLOR;
  if (color === 'black') return BLACK_COLOR;
  return GREEN_COLOR;
}

// ВАЖНО про производительность: раньше цвет каждого пикселя (включая фон, обод,
// ступицу и разделители секторов) пересчитывался с нуля на КАЖДЫЙ спин — двойной
// цикл по ~270 000 пикселей синхронно в основном потоке Node. При нескольких
// одновременных спинах это блокировало обработку вообще всех игроков (лаги/таймауты,
// из-за которых мог срабатывать fallback на текст — выглядело как "рендер не работает").
//
// Фон колеса (цвета секторов, разделители, обод, ступица, указатель) не зависит от
// результата спина — он всегда один и тот же. Поэтому считаем его ОДИН РАЗ при первом
// обращении и кэшируем в памяти процесса. На каждый спин дальше просто клонируем готовую
// картинку (дешёвая операция) и дорисовываем только маленький кусок — подсветку
// выигрышного сектора (только его угловой диапазон, а не всё колесо) и текст с итогом.
let baseWheelCache = null;

async function buildBaseWheel() {
  const image = await new Jimp(SIZE, SIZE, BG_COLOR);

  for (let x = 0; x < SIZE; x++) {
    for (let y = 0; y < SIZE; y++) {
      const dx = x - CENTER;
      const dy = y - CENTER;
      const r = Math.sqrt(dx * dx + dy * dy);
      if (r > RIM_R) continue;

      if (r > OUTER_R) {
        image.setPixelColor(RIM_COLOR, x, y);
        continue;
      }
      if (r < INNER_R) {
        image.setPixelColor(HUB_COLOR, x, y);
        continue;
      }

      let angle = Math.atan2(dy, dx) + Math.PI / 2;
      if (angle < 0) angle += 2 * Math.PI;
      const slot = Math.floor(angle / SLOT_ANGLE) % C.CASINO_SLOT_COUNT;
      let px = colorHex(casino.colorOfSlot(slot));

      const angleInSlot = angle % SLOT_ANGLE;
      const edgeDist = Math.min(angleInSlot, SLOT_ANGLE - angleInSlot) * r;
      if (edgeDist < 1.4) px = 0x000000ff;

      image.setPixelColor(px, x, y);
    }
  }

  // Указатель (треугольник) сверху — статичный, часть базового шаблона.
  const pointerHeight = 26;
  const pointerHalfWidth = 16;
  for (let py = 0; py < pointerHeight; py++) {
    const halfW = Math.round(pointerHalfWidth * (1 - py / pointerHeight));
    for (let px = -halfW; px <= halfW; px++) {
      const x = Math.round(CENTER + px);
      const y = Math.round(CENTER - OUTER_R + 4 + py);
      if (x >= 0 && y >= 0 && x < SIZE && y < SIZE) {
        image.setPixelColor(HIGHLIGHT_COLOR, x, y);
      }
    }
  }

  return image;
}

async function getBaseWheel() {
  if (!baseWheelCache) {
    baseWheelCache = await buildBaseWheel();
  }
  return baseWheelCache.clone();
}

// Подсвечивает белой обводкой только сектор winningSlot — сканирует не всю картинку,
// а лишь квадрат, гарантированно накрывающий этот сектор (bounding box по его углу),
// что на порядки дешевле полного прохода по колесу.
function highlightSlot(image, winningSlot) {
  const slotCenter = -Math.PI / 2 + winningSlot * SLOT_ANGLE + SLOT_ANGLE / 2;
  const cx = CENTER + Math.cos(slotCenter) * (OUTER_R * 0.6);
  const cy = CENTER + Math.sin(slotCenter) * (OUTER_R * 0.6);
  const half = OUTER_R * 0.75; // с запасом, чтобы гарантированно накрыть сектор целиком
  const minX = Math.max(0, Math.floor(cx - half));
  const maxX = Math.min(SIZE - 1, Math.ceil(cx + half));
  const minY = Math.max(0, Math.floor(cy - half));
  const maxY = Math.min(SIZE - 1, Math.ceil(cy + half));

  for (let x = minX; x <= maxX; x++) {
    for (let y = minY; y <= maxY; y++) {
      const dx = x - CENTER;
      const dy = y - CENTER;
      const r = Math.sqrt(dx * dx + dy * dy);
      if (r < INNER_R || r > OUTER_R) continue;

      let angle = Math.atan2(dy, dx) + Math.PI / 2;
      if (angle < 0) angle += 2 * Math.PI;
      const slot = Math.floor(angle / SLOT_ANGLE) % C.CASINO_SLOT_COUNT;
      if (slot !== winningSlot) continue;

      const angleInSlot = angle % SLOT_ANGLE;
      const edgeDist = Math.min(angleInSlot, SLOT_ANGLE - angleInSlot) * r;
      if (r > OUTER_R - 10 || edgeDist < 3) {
        image.setPixelColor(HIGHLIGHT_COLOR, x, y);
      }
    }
  }
}

// Лёгкие радиальные штрихи-"смаз" — тоже дешевле полного скана: идём только по
// нескольким десяткам лучей, а не по всем пикселям колеса.
function drawSpinBlur(image) {
  const streaks = 60;
  for (let i = 0; i < streaks; i++) {
    const a = (i / streaks) * 2 * Math.PI + Math.random() * 0.05;
    for (let r = INNER_R + 5; r < OUTER_R - 5; r += 2) {
      const x = Math.round(CENTER + Math.cos(a) * r);
      const y = Math.round(CENTER + Math.sin(a) * r);
      if (x < 0 || y < 0 || x >= SIZE || y >= SIZE) continue;
      image.setPixelColor(BLUR_STREAK_COLOR, x, y);
    }
  }
}

let fontCache = null;
async function getFont() {
  if (!fontCache) fontCache = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
  return fontCache;
}

// winningSlot: если передан, этот сектор подсвечивается белой обводкой (итог спина).
// spinBlur: если true, поверх колеса рисуются лёгкие радиальные штрихи для ощущения
// недавнего вращения.
async function renderWheel(winningSlot, spinBlur) {
  const image = await getBaseWheel();

  if (spinBlur) drawSpinBlur(image);
  if (typeof winningSlot === 'number') highlightSlot(image, winningSlot);

  const font = await getFont();
  image.print(
    font,
    0,
    SIZE - 46,
    {
      text: typeof winningSlot === 'number' ? `Выпало: ${winningSlot}` : 'Крутим...',
      alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER,
      alignmentY: Jimp.VERTICAL_ALIGN_MIDDLE,
    },
    SIZE,
    40
  );

  return image.getBufferAsync(Jimp.MIME_PNG);
}

// Заранее считает и кэширует базовое колесо + шрифт при старте бота, чтобы первый
// же игрок, который крутанёт рулетку, не ждал построение картинки "с нуля".
async function warmup() {
  await getBaseWheel();
  await getFont();
}

module.exports = { renderWheel, warmup };

