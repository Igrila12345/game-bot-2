'use strict';

const C = require('./constants');

// Секторы 1-36 красим по классической схеме рулетки (чтобы совпадало с визуалом
// настоящего колеса, если игрок вдруг станет считать секторы). Сектор 0 — зелёный.
const RED_NUMBERS = new Set([
  1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36,
]);

function colorOfSlot(slot) {
  if (slot === 0) return 'green';
  return RED_NUMBERS.has(slot) ? 'red' : 'black';
}

function spin() {
  const slot = Math.floor(Math.random() * C.CASINO_SLOT_COUNT);
  return { slot, color: colorOfSlot(slot) };
}

const COLOR_ALIASES = {
  красное: 'red',
  красный: 'red',
  красн: 'red',
  red: 'red',
  чёрное: 'black',
  черное: 'black',
  чёрный: 'black',
  черный: 'black',
  black: 'black',
  зелёное: 'green',
  зеленое: 'green',
  зелёный: 'green',
  зеленый: 'green',
  зеро: 'green',
  green: 'green',
};

function parseColor(word) {
  if (!word) return null;
  return COLOR_ALIASES[String(word).toLowerCase()] || null;
}

function multiplierFor(color) {
  return color === 'green' ? C.CASINO_GREEN_MULTIPLIER : C.CASINO_COLOR_MULTIPLIER;
}

// Возвращает { slot, resultColor, win, payout } — payout это сколько зачислить игроку
// (0 при проигрыше, amount*multiplier при выигрыше). Ставка (amount) списывается отдельно
// в хендлере ДО спина, эта функция только определяет исход и выплату.
function resolveBet(amount, betColor) {
  const result = spin();
  const win = result.color === betColor;
  const payout = win ? amount * multiplierFor(betColor) : 0;
  return { slot: result.slot, resultColor: result.color, win, payout };
}

module.exports = {
  colorOfSlot,
  spin,
  parseColor,
  multiplierFor,
  resolveBet,
  RED_NUMBERS,
};
