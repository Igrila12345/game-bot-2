'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');

// Вызывается раз в час общим планировщиком (см. game/scheduler.js). Начисляет всем игрокам
// с активным майнером фиксированную сумму вирт и жетонов каждый час — гарантированно, без шанса.
// Работает молча (без личных уведомлений каждый час) — статус можно проверить командой "майнер".
async function hourlyMinerTick() {
  const all = await players.getAllActivePlayers();

  for (const player of all) {
    if (!calc.isMinerActive(player)) continue;

    const virts = calc.randomInt(C.MINER_HOURLY_VIRTS_MIN, C.MINER_HOURLY_VIRTS_MAX);
    await players.updateBalance(player.vk_id, virts);
    await players.addTokens(player.vk_id, C.MINER_HOURLY_TOKENS);
  }
}

module.exports = { hourlyMinerTick };
