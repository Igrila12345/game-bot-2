'use strict';

const C = require('./constants');
const players = require('../db/players');
const calc = require('./calc');

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];

// Номер "модели" робота (0 = первая, растёт каждые ROBOT_TIER_SIZE уровней)
function tierOf(level) {
  const tier = Math.floor((level - 1) / C.ROBOT_TIER_SIZE);
  return Math.min(tier, C.ROBOT_TIER_NAMES.length - 1);
}

// Название уровня, например "Скрап-Бот I", "Штамповщик VII", "Голиаф-Прораб X"
function levelName(level) {
  const tier = tierOf(level);
  const subIndex = (level - 1) % C.ROBOT_TIER_SIZE;
  return `${C.ROBOT_TIER_NAMES[tier]} ${ROMAN[subIndex]}`;
}

// Цена прокачки С currentLevel НА currentLevel+1
function upgradeCost(currentLevel) {
  const raw = C.ROBOT_UPGRADE_BASE_COST * Math.pow(C.ROBOT_UPGRADE_GROWTH, currentLevel - 1);
  return Math.round(raw / 10) * 10;
}

// Диапазон [min;max] вирт за один мгновенный сбор ("робот") на данном уровне.
// Награда случайная внутри диапазона, оба края растут с уровнем.
function incomeRange(level) {
  const min = C.ROBOT_FARM_MIN_BASE + (level - 1) * C.ROBOT_FARM_MIN_STEP;
  const max = C.ROBOT_FARM_MAX_BASE + (level - 1) * C.ROBOT_FARM_MAX_STEP;
  return { min, max };
}

// Случайная сумма сбора вирт на данном уровне (используется при фактическом сборе).
function rollFarmAmount(level) {
  const { min, max } = incomeRange(level);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Сколько жетонов зачисляется за одну отправку ("отправить") — растёт по "модели" робота
function tokensPerSend(level) {
  return tierOf(level) + 1;
}

// Справочный показатель мощности модели (для команды "роботы") — сколько условно вражеских
// заводов "по силам" снести роботу такого уровня. Чисто информационная характеристика модели,
// растёт на 1 каждые ROBOT_TIER_SIZE уровней прокачки — в бою автоматически не применяется.
function factoriesPower(level) {
  return tierOf(level);
}

function msLeft(lastAt, cooldownMs) {
  if (!lastAt) return 0;
  const left = cooldownMs - (Date.now() - new Date(lastAt).getTime());
  return left > 0 ? left : 0;
}

// Кулдаун с учётом VIP: у VIP-игроков "робот"/"отправить" доступны чаще (x VIP_ROBOT_COOLDOWN_MULT).
function effectiveCooldownMs(player, baseCooldownMs) {
  return calc.isVipActive(player) ? Math.round(baseCooldownMs * C.VIP_ROBOT_COOLDOWN_MULT) : baseCooldownMs;
}

async function upgradeRobot(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.robot_level || 1;
  if (level >= C.ROBOT_MAX_LEVEL) {
    return { ok: false, reason: 'max_level' };
  }

  const cost = upgradeCost(level);
  if (Number(player.balance) < cost) {
    return { ok: false, reason: 'not_enough_money', cost, missing: cost - Number(player.balance) };
  }

  await players.updateBalance(vkId, -cost);
  await players.setRobotLevel(vkId, level + 1);

  return { ok: true, cost, newLevel: level + 1 };
}

// Мгновенный сбор вирт (заменяет старую механику "старт добычи -> забрать"). Не чаще раза в час.
async function farmVirts(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const cooldownMs = effectiveCooldownMs(player, C.ROBOT_FARM_COOLDOWN_MS);
  const left = msLeft(player.robot_last_farm_at, cooldownMs);
  if (left > 0) {
    return { ok: false, reason: 'cooldown', msLeft: left };
  }

  const level = player.robot_level || 1;
  const amount = rollFarmAmount(level);

  await players.updateBalance(vkId, amount);
  await players.setRobotLastFarm(vkId, new Date());

  return { ok: true, amount, level, cooldownMs };
}

// Мгновенная отправка робота за жетонами. Не чаще раза в час.
async function sendForTokens(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const cooldownMs = effectiveCooldownMs(player, C.ROBOT_SEND_COOLDOWN_MS);
  const left = msLeft(player.robot_last_send_at, cooldownMs);
  if (left > 0) {
    return { ok: false, reason: 'cooldown', msLeft: left };
  }

  const level = player.robot_level || 1;
  const amount = tokensPerSend(level);

  await players.addTokens(vkId, amount);
  await players.setRobotLastSend(vkId, new Date());

  return { ok: true, amount, level, cooldownMs };
}

// Полная таблица всех уровней робота — для команды "роботы"
function buildLevelsTable() {
  const rows = [];
  for (let level = 1; level <= C.ROBOT_MAX_LEVEL; level++) {
    rows.push({
      level,
      name: levelName(level),
      costToReach: level === 1 ? 0 : upgradeCost(level - 1),
      incomeRange: incomeRange(level),
      tokensPerSend: tokensPerSend(level),
      factoriesPower: factoriesPower(level),
    });
  }
  return rows;
}

module.exports = {
  levelName,
  tierOf,
  upgradeCost,
  incomeRange,
  rollFarmAmount,
  tokensPerSend,
  factoriesPower,
  msLeft,
  effectiveCooldownMs,
  upgradeRobot,
  farmVirts,
  sendForTokens,
  buildLevelsTable,
};
