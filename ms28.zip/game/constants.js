'use strict';

// ===================== ОБЩИЕ ПАРАМЕТРЫ =====================

const FACTORY_BASE_PRICE = 100;
const FACTORY_PRICE_GROWTH = 1.03; // +3% за каждый следующий завод (снижено с 4.5% — цены слишком быстро росли)
const FACTORY_MAX_COUNT = 100;
const FACTORY_INCOME_PER_HOUR = 8;
const GOLD_MINE_CHANCE = 0.05; // 5% шанс золотой жилы при постройке
const GOLD_MINE_MULTIPLIER = 2;

const START_BALANCE = 250; // увеличено со 100 — старт стал слишком медленным
// Стартовые заводы выдаются сразу при регистрации бесплатно (в дополнение к START_BALANCE),
// чтобы новый игрок не начинал с абсолютного нуля.
const STARTER_FREE_FACTORIES = 5;

// Бонус для новых/маленьких игроков (catch-up): пока заводов меньше порога — доход выше.
// Бонус самозатухающий: чем больше заводов у игрока, тем меньше он получает, и полностью
// исчезает по достижении порога — то есть не помогает топам, только выравнивает старт.
const NEWBIE_BOOST_FACTORY_THRESHOLD = 150;
const NEWBIE_BOOST_INCOME_BONUS = 0.5; // +50% дохода начиная с 1 завода, линейно убывает до 0 к порогу
const RENAME_COST = 200;
const RECON_COST = 50; // разведка
const EARLY_UNBLOCK_COST_PER_HOUR = 50;

const MAP_MIN = 0;
const MAP_MAX = 1000;

const RADIATION_INCOME_PENALTY = 0.2; // -20%
const RADIATION_DURATION_MS = 2 * 60 * 60 * 1000;

// Защита новичков: нельзя атаковать (и, соответственно, сносить заводы) игрока,
// у которого заводов меньше этого значения.
const MIN_FACTORIES_TO_BE_ATTACKED = 3;
const NEWBIE_PROTECTION_FACTORIES = MIN_FACTORIES_TO_BE_ATTACKED;
const INACTIVITY_ATTACK_BAN_DAYS = 7;

// Кулдаун между любыми командами одного игрока боту
const COMMAND_COOLDOWN_MS = 2 * 1000;

// Максимальный "возраст" входящего сообщения, которое ещё разрешено выполнять как команду.
// Защита от повторной обработки СТАРЫХ сообщений (например, VK может повторно прислать
// апдейт с полным текстом старого сообщения при закреплении/пересылке/иных служебных
// действиях — тогда дата самого сообщения (message.date) остаётся старой, а апдейт
// приходит "только что"). Если сообщение старше этого порога — это не живой ввод
// команды прямо сейчас, и его нужно игнорировать, чем бы оно ни было вызвано.
const MAX_COMMAND_MESSAGE_AGE_MS = 20 * 1000;

// Лимит на постройку заводов
const FACTORY_BUILD_LIMIT_PER_HOUR = 10;
// Максимум заводов, которые можно построить одной командой ("построить 10")
const FACTORY_BUILD_MAX_PER_COMMAND = 10;

// Ежедневный бонус для каждого игрока (не путать с наградами топ-3)
const DAILY_BONUS_AMOUNT = 50;
const DAILY_BONUS_COOLDOWN_MS = 24 * 60 * 60 * 1000;

// Перевод вирт другому игроку
const TRANSFER_COOLDOWN_MS = 2 * 60 * 60 * 1000; // 1 раз в 2 часа одному и тому же игроку
const TRANSFER_MIN_AMOUNT = 10;

// ===================== НАЛОГИ =====================

const WEALTH_TAX_THRESHOLD = 10000;
const WEALTH_TAX_RATE = 0.05; // 5% от суммы сверх 10000, раз в час

const TOP_TAX = [
  { place: 1, rate: 0.10, threshold: 5000 },
  { place: 2, rate: 0.07, threshold: 5000 },
  { place: 3, rate: 0.05, threshold: 5000 },
];

// ===================== ОРУЖИЕ =====================
// category: 'drone' | 'missile' | 'nuke' | 'saboteur'
// ПРИМЕЧАНИЕ: поле counterChance больше не используется при расчёте перехвата —
// итоговый шанс перехвата считается только из ПВО защитника (см. game/combat.js).
// Поле оставлено для справки в интерфейсе, на бой не влияет.
//
// ===== ЕДИНАЯ ШКАЛА СИЛЫ ОРУЖИЯ (чтобы не было нестыковок) =====
// Внутри каждой категории 3 уровня, мощность растёт от 1 к 3.
// Категории по мощности: 🛸 БПЛА < 🚀 Ракеты < ☢️ Ядерное.
// Два способа задать урон по заводам:
//   • hitsToDestroy — сколько ПОПАДАНИЙ нужно, чтобы снести 1 завод (для слабого оружия, >1 хита).
//   • factoriesPerHit — сколько заводов сносит КАЖДОЕ попадание (для сильного оружия, ≥1 завод за раз).
// Прогрессия по факту:
//   БПЛА:    Герань-2 (4 попадания) → Орион (3) → Молния (2)
//   Ракеты:  Точка-У (2 попадания) → Калибр (1 попадание) → Искандер-М (2 завода за попадание)
//   Ядерное: Тополь-М (3 завода) → Посейдон (4 завода) → Сармат (5 заводов)
// Т.е. САМАЯ слабая ракета (Точка-У) не слабее самого сильного дрона (Молния),
// а САМАЯ слабая ядерка (Тополь-М) сильнее самой сильной ракеты (Искандер-М). Разрывов нет.

const WEAPONS = {
  // ---------- 🛸 БПЛА (дёшево, массово, слабее всего за 1 попадание) ----------
  'Герань-2': {
    key: 'Герань-2',
    category: 'drone',
    tier: 1,
    speedKmh: 36000, // 100 км за 10 сек
    price: 300,
    counterChance: 0.60,
    maxPerAttack: 20, // дешёвый массовый дрон — можно закидывать волной, чтобы истощить ПВО
    effect: 'block_random',
    hitsToDestroy: 4, // 4 попадания = 1 снесённый завод
    productionCost: 60,
    productionMinutes: 30,
  },
  'Орион': {
    key: 'Орион',
    category: 'drone',
    tier: 2,
    speedKmh: 36000,
    price: 620,
    counterChance: 0.50,
    maxPerAttack: 15,
    effect: 'block_random',
    hitsToDestroy: 3,
    productionCost: 130,
    productionMinutes: 60,
  },
  'Молния': {
    key: 'Молния',
    category: 'drone',
    tier: 3,
    speedKmh: 36000,
    price: 1120,
    counterChance: 0.30,
    maxPerAttack: 3,
    effect: 'block_random',
    hitsToDestroy: 2, // топ-дрон, но всё ещё слабее любой ракеты
    productionCost: 250,
    productionMinutes: 120,
  },

  // ---------- 🚀 Ракеты (сильнее БПЛА) ----------
  'Точка-У': {
    key: 'Точка-У',
    category: 'missile',
    tier: 1,
    speedKmh: 72000, // 100 км за 5 сек
    price: 380,
    counterChance: 0.55,
    maxPerAttack: 8,
    effect: 'block_random',
    hitsToDestroy: 2, // не слабее топ-дрона
    productionCost: 80,
    productionMinutes: 45,
  },
  'Калибр': {
    key: 'Калибр',
    category: 'missile',
    tier: 2,
    speedKmh: 72000,
    price: 1000,
    counterChance: 0.35,
    maxPerAttack: 3,
    effect: 'block_random',
    hitsToDestroy: 1, // сносит завод с одного попадания
    productionCost: 220,
    productionMinutes: 120,
  },
  'Искандер-М': {
    key: 'Искандер-М',
    category: 'missile',
    tier: 3,
    speedKmh: 72000,
    price: 1750,
    counterChance: 0.10,
    maxPerAttack: 2,
    effect: 'block_random',
    factoriesPerHit: 2, // топ-ракета: КАЖДОЕ попадание сносит сразу 2 завода
    productionCost: 400,
    productionMinutes: 240,
  },

  // ---------- ☢️ Ядерное (сильнее всех ракет, редкое, maxPerAttack всегда 1) ----------
  'Тополь-М': {
    key: 'Тополь-М',
    category: 'nuke',
    tier: 1,
    speedKmh: 72000,
    price: 6250,
    counterChance: 0.15,
    maxPerAttack: 1,
    effect: 'nuke_strike',
    factoriesPerHit: 3, // сносит 3 завода за удар
    radiation: true, // + доп. эффект: радиация -20% дохода на 2 ч
    productionCost: 1500,
    productionMinutes: 720,
  },
  'Посейдон': {
    key: 'Посейдон',
    category: 'nuke',
    tier: 2,
    speedKmh: 72000,
    price: 7000,
    counterChance: 0.20,
    maxPerAttack: 1,
    effect: 'nuke_strike',
    factoriesPerHit: 4, // сносит 4 завода за удар
    wipeAirDefense: true, // + доп. эффект: уничтожает всё ПВО противника
    productionCost: 1800,
    productionMinutes: 840,
  },
  'Сармат': {
    key: 'Сармат',
    category: 'nuke',
    tier: 3,
    speedKmh: 72000,
    price: 8750,
    counterChance: 0.05,
    maxPerAttack: 1,
    effect: 'nuke_strike',
    factoriesPerHit: 5, // самое мощное оружие в игре: 5 заводов за удар
    productionCost: 2200,
    productionMinutes: 1080,
  },

  // ---------- 🕵️ Диверсанты (отдельная спецкатегория, не заменяет БПЛА/ракеты/ядерку) ----------
  'Группа захвата': {
    key: 'Группа захвата',
    category: 'saboteur',
    tier: 1,
    speedKmh: 300, // диверсанты идут по земле, а не летят
    price: 150,
    counterChance: 0.40,
    maxPerAttack: 3,
    effect: 'block_random',
    hitsToDestroy: 4,
    productionCost: 30,
    productionMinutes: 60,
  },
};

// ===================== КУЛДАУНЫ ЗАПУСКА ОРУЖИЯ (по категориям) =====================
// Кулдаун на конкретную ЦЕЛЬ убран (см. game/combat.js) — атаковать одного и того же
// игрока можно сколько угодно раз подряд. Вместо этого добавлен общий кулдаун
// атакующего между запусками оружия одной категории (не зависит от цели).
const DRONE_LAUNCH_COOLDOWN_MS = 2 * 60 * 1000; // БПЛА: 2 минуты
const MISSILE_LAUNCH_COOLDOWN_MS = 10 * 60 * 1000; // ракеты: 10 минут
const NUKE_LAUNCH_COOLDOWN_MS = 60 * 60 * 1000; // ядерное: 1 час

// Общий "знаменатель" системы ХП заводов: наименьшее общее кратное всех hitsToDestroy (1,2,3 -> 6).
// Один удар оружием даёт floor(FACTORY_HP_UNIT / hitsToDestroy) единиц урона; когда накоплено
// FACTORY_HP_UNIT единиц — сносится 1 завод противника (сверх защиты новичков).
const FACTORY_HP_UNIT = 6;

// ===================== СКИЛЛЫ (пассивные бонусы за количество заводов) =====================
// Бонусы не суммируются — применяется бонус самого высокого достигнутого порога.
// damageBonus: множитель урона по вражеским заводам (система ХП/снос заводов).
// airDefenseBonus: прибавка к шансу перехвата ПВО (в долях, например 0.05 = +5 п.п.).

const SKILL_TIERS = [
  { factories: 50, damageBonus: 0.15, airDefenseBonus: 0.05, name: 'Опытный полководец' },
  { factories: 150, damageBonus: 0.35, airDefenseBonus: 0.10, name: 'Генералиссимус' },
];

// ===================== АДМИНИСТРАТОРЫ =====================

const ADMIN_IDS = [660964860];

// ===================== ДОНАТ (прайс-лист в рублях, для команды "донат") =====================
// Оплата и выдача — вручную через администратора (см. !админ vip / !админ майнер / !админ суперробот).
// VIP и майнер — это подписка на месяц (30 дней). Суперробот — разовая покупка НАВСЕГДА:
// открывает суперробота (даёт 1 уровень), а прокачка ДАЛЬШЕ идёт как обычно — жетонами
// (см. "суперробот прокачать" в game/superRobot.js), донат за уровни не продаётся.
const DONATE_VIP_PRICE_RUB_MONTH = 400;
const DONATE_MINER_PRICE_RUB_MONTH = 750;
const DONATE_SUPER_ROBOT_PRICE_RUB = 800; // разовая покупка, открывает суперробота навсегда (1 уровень)


// ===================== ПИТОМЕЦ-РОБОТ =====================

// ===================== VIP (донат-статус) =====================
// Выдаётся вручную админом на N дней после оплаты (см. handlers/adminHandlers.js: !админ vip).
// Даёт три бонуса одновременно, пока активен vip_until:
const VIP_INCOME_BONUS = 0.25; // +25% к пассивному доходу с заводов/науки (game/calc.js)
const VIP_ROBOT_COOLDOWN_MULT = 0.7; // кулдауны "робот"/"отправить" короче на 30% (x0.7 от обычных)
const VIP_BUILD_LIMIT_BONUS = 2; // +2 постройки завода в час сверх обычного лимита (game/economy.js)

// ===================== РОБОТ =====================
// Робот прокачивается за вирты (макс. 50 уровней), команда "робот" мгновенно приносит доход
// виртами (раз в час), команда "отправить" мгновенно приносит жетоны (раз в час). Каждые 10
// уровней у робота меняется "модель" (название) — см. ROBOT_TIER_NAMES и game/robot.js.
const ROBOT_MAX_LEVEL = 50;
const ROBOT_TIER_SIZE = 10; // раз в столько уровней меняется модель робота
const ROBOT_TIER_NAMES = ['Скрап-Бот', 'Штамповщик', 'Индустриал', 'Титан-Завод', 'Голиаф-Прораб'];
const ROBOT_UPGRADE_BASE_COST = 75; // цена прокачки с 1 на 2 уровень (снижена вдвое по просьбе игроков)
const ROBOT_UPGRADE_GROWTH = 1.13; // рост цены прокачки за уровень
// Мгновенный сбор ("робот") — награда случайная в диапазоне [min;max], растущем с уровнем:
// min = ROBOT_FARM_MIN_BASE + (уровень-1) * ROBOT_FARM_MIN_STEP
// max = ROBOT_FARM_MAX_BASE + (уровень-1) * ROBOT_FARM_MAX_STEP
const ROBOT_FARM_MIN_BASE = 10;
const ROBOT_FARM_MIN_STEP = 4;
const ROBOT_FARM_MAX_BASE = 30;
const ROBOT_FARM_MAX_STEP = 8;
const ROBOT_FARM_COOLDOWN_MS = 60 * 60 * 1000; // "робот" — мгновенный доход не чаще раза в час
const ROBOT_SEND_COOLDOWN_MS = 60 * 60 * 1000; // "отправить" — жетоны не чаще раза в час

const NUKE_KEYS = Object.keys(WEAPONS).filter((k) => WEAPONS[k].category === 'nuke');

// ===================== МАЙНЕР (донат-предмет) =====================
// Выдаётся вручную админом на N дней после оплаты — аналогично VIP (см. handlers/adminHandlers.js:
// !админ майнер @юзер [дни]). Пока активен miner_until, каждый час (в общем часовом тике,
// game/miner.js) начисляет небольшое случайное количество вирт и с некоторым шансом — 1 жетон.
// Награды намеренно скромные: майнер — это приятный бонус для донатеров, а не решающее
// преимущество и не способ обогнать заводы/робота/работу по эффективности, чтобы не мешать
// балансу новичков.
const MINER_HOURLY_VIRTS_MIN = 1500; // снижено с 4000 — майнер давал слишком быстрое читерское развитие
const MINER_HOURLY_VIRTS_MAX = 1500;
const MINER_HOURLY_TOKENS = 150; // снижено с 500, гарантированно каждый час, без шанса

// ===================== СУПЕРРОБОТ =====================
// Отдельный от обычного робота боевой юнит. Прокачивается ЖЕТОНАМИ (не виртами!) и специально
// сделан ДОРОГИМ в прокачке — рост стоимости за уровень намного круче обычного робота
// (x${SUPER_ROBOT_UPGRADE_GROWTH} против x${ROBOT_UPGRADE_GROWTH} у обычного робота), максимум
// тоже 50 уровней. В отличие от обычного робота (который только пассивно фармит вирты/жетоны
// и НЕ может атаковать игроков), суперробот — боевой: им можно атаковать другого игрока,
// снося ему заводы напрямую (1 уровень = 1 снесённый завод за удар, дальше сила растёт на
// +1 завод каждые SUPER_ROBOT_FACTORIES_PER_LEVEL уровней, до 10 заводов на 50 уровне).
// Атака летит как обычное оружие (расстояние/скорость), а на подлёте её может перехватить
// только САМОЕ мощное ПВО (С-400 Триумф) — если "охота" защитника удалась, он получает
// повышенную награду виртами (см. SUPER_ROBOT_HUNT_REWARD_*), а суперробот при этом не
// теряется — просто эта конкретная атака сорвалась. Если прорвался — заводы сносятся,
// а атакующий получает повышенные трофеи виртами (см. SUPER_ROBOT_LOOT_*).
const SUPER_ROBOT_MAX_LEVEL = 50;
const SUPER_ROBOT_TIER_SIZE = 10;
const SUPER_ROBOT_TIER_NAMES = ['Прототип', 'Штурмовик', 'Терминатор', 'Разрушитель', 'Апокалипсис'];
const SUPER_ROBOT_UPGRADE_BASE_COST = 800; // вирт с 0 на 1 уровень (прокачка виртами, не жетонами)
const SUPER_ROBOT_UPGRADE_GROWTH = 1.18; // рост цены за уровень — качать тяжело, к максимуму цена уходит в миллионы вирт
const SUPER_ROBOT_FACTORIES_PER_LEVEL = 5; // +1 завод сноса каждые столько уровней (1 ур. = 1 завод)
const SUPER_ROBOT_SPEED_KMH = 90000;
const SUPER_ROBOT_ATTACK_COOLDOWN_MS = 2 * 60 * 60 * 1000; // 2 часа между атаками суперроботом
const SUPER_ROBOT_HUNT_REWARD_MIN = 250; // вирт защитнику за успешную "охоту" (перехват С-400)
const SUPER_ROBOT_HUNT_REWARD_MAX = 600;
const SUPER_ROBOT_LOOT_RATE = 0.25; // трофеи атакующему при прорыве — выше обычных 15%
const SUPER_ROBOT_LOOT_MIN = 150;
const SUPER_ROBOT_LOOT_MAX = 700;
// Специальный "ключ оружия" для записей в attacks_in_flight — не входит в WEAPONS,
// не продаётся и не производится, обрабатывается отдельной веткой в attackResolver.js.
const SUPER_ROBOT_WEAPON_KEY = 'Суперробот';

// ===================== ПВО =====================
// covers: 'drone' | 'missile' | 'all' (диверсанты также перехватываются, если covers === 'all' или 'saboteur' входит)

const AIR_DEFENSE = {
  'Панцирь-С1': {
    key: 'Панцирь-С1',
    covers: ['drone'],
    chance: 0.60,
    price: 220, // было 100
  },
  'Бук-М3': {
    key: 'Бук-М3',
    covers: ['drone', 'missile'],
    chance: 0.70,
    price: 480, // было 220
  },
  'С-400 Триумф': {
    key: 'С-400 Триумф',
    covers: ['drone', 'missile', 'nuke', 'saboteur'],
    chance: 0.90,
    price: 1100, // было 500
  },
};

// ===================== МАГАЗИН =====================

const SHOP_REFRESH_MINUTES = 5;
const SHOP_WEAPON_TYPES_MIN = 2;
const SHOP_WEAPON_TYPES_MAX = 3;
const SHOP_AD_TYPES_MIN = 1;
const SHOP_AD_TYPES_MAX = 2;
const SHOP_NUKE_CHANCE = 0.05;
const SHOP_ITEM_QTY_MIN = 1;
const SHOP_ITEM_QTY_MAX = 3;
const SHOP_LOCKOUT_AFTER_NUKE_MIN = 30;

const NON_NUKE_WEAPON_KEYS = Object.keys(WEAPONS).filter((k) => WEAPONS[k].category !== 'nuke');

// ===================== ПРОИЗВОДСТВО =====================

const MASS_PRODUCTION_FACTORY_THRESHOLD = 10;
const MASS_PRODUCTION_TIME_BONUS = 0.20; // -20% доп. времени
// Общее ускорение производства оружия в 3 раза (делит итоговое время изготовления)
const PRODUCTION_SPEED_MULTIPLIER = 3;

// ===================== КЛАНЫ =====================

// Создание клана бесплатно
const CLAN_CREATE_COST = 0;
const CLAN_NAME_MIN = 2;
const CLAN_NAME_MAX = 20;
const CLAN_VAULT_INCOME_RATE = 0.15; // 15% от дохода каждого участника ДОПОЛНИТЕЛЬНО капает в сейф клана,
// НЕ вычитаясь из дохода самого игрока (игрок получает полный доход + отдельно клан получает свою часть)
const CLAN_VAULT_PER_FACTORY = 100;

// Уровень сейфа: копится от ВСЕХ поступлений в сейф за всё время (налог + ручные пополнения),
// не уменьшается при трате/снятии. Level = floor(всего_собрано / CLAN_VAULT_LEVEL_STEP), максимум 100.
// Например: собрали 10 000 вирт всего — уровень 1, собрали 20 000 — уровень 2, и т.д. до 1 000 000 (ур. 100).
const CLAN_VAULT_LEVEL_STEP = 10000;
const CLAN_VAULT_MAX_LEVEL = 100;
// Каждый уровень сейфа увеличивает его максимальную вместимость на 1% (до +100% на 100 уровне)
const CLAN_VAULT_LEVEL_CAPACITY_BONUS = 0.01;

const CLAN_BONUSES = {
  'форсаж': {
    key: 'форсаж',
    dbColumn: 'forsazh', // ВАЖНО: имя колонки в БД (db/schema.sql), латиница, не путать с key
    name: 'Форсаж',
    description: 'Скорость полёта оружия x2 на 1 час',
    costRateOfMaxVault: 0.5,
    cooldownHours: 6,
    durationHours: 1,
  },
  'эшелон': {
    key: 'эшелон',
    dbColumn: 'eshelon',
    name: 'Эшелон',
    description: 'ПВО работает на 20% точнее на 1 час',
    costRateOfMaxVault: 0.4,
    cooldownHours: 4,
    durationHours: 1,
  },
  'индустриализация': {
    key: 'индустриализация',
    dbColumn: 'industry',
    name: 'Индустриализация',
    description: '+20% дохода всем на 1 час',
    costRateOfMaxVault: 0.3,
    cooldownHours: 3,
    durationHours: 1,
  },
};

// ===================== АТАКА / ТРОФЕИ =====================

const LOOT_RATE = 0.15; // 15% от дохода жертвы за 1 час
const LOOT_MIN = 30;
const LOOT_MAX = 250;

// Штраф на трофеи при атаке слабого противника (см. calc.weakTargetLootMultiplier)
const WEAK_TARGET_RATIO_THRESHOLD = 0.3; // защитнику нужно иметь от 30% заводов атакующего для полных трофеев
const WEAK_TARGET_MIN_LOOT_MULTIPLIER = 0.3; // минимум 30% от обычных трофеев даже на полностью беззащитном новичке

// ===================== КАЗИНО (РУЛЕТКА) =====================
// Честная европейская рулетка: 37 секторов (0 — зелёное, 1-36 — 18 красных/18 чёрных).
// Ставка на цвет платит x2 (профит = ставке), на зелёное — x14. Математическое ожидание
// игрока отрицательное (~-2.7% на ставках цвета, ещё сильнее на зелёном) — это встроенное,
// честное преимущество казино за счёт зелёного сектора, а не подкрутка конкретных раздач.
// На длинной дистанции даже у самых везучих игроков итог уходит в минус — это гарантирует
// сама математика (house edge), без обмана в сторону конкретных игроков.
const CASINO_SLOT_COUNT = 37;
const CASINO_MIN_BET = 10;
const CASINO_MAX_BET = 2000;
const CASINO_COLOR_MULTIPLIER = 2; // красное/чёрное: x2 (ставка возвращается + столько же профита)
const CASINO_GREEN_MULTIPLIER = 14; // зелёное (только сектор 0): x14
const CASINO_COOLDOWN_MS = 3000; // чтобы не спамили спинами быстрее, чем рисуется колесо

// ===================== РЕЙТИНГИ / НАГРАДЫ =====================

const DAILY_FACTORY_REWARDS = [
  { place: 1, virts: 300, weapon: 'Калибр', qty: 1 },
  { place: 2, virts: 200, weapon: 'Герань-2', qty: 1 },
  { place: 3, virts: 100, weapon: 'Герань-2', qty: 1 },
];

const DAILY_CLAN_REWARDS = [
  { place: 1, virts: 500 },
  { place: 2, virts: 300 },
  { place: 3, virts: 100 },
];

// ===================== РАБОТА И ЖЕТОНЫ =====================

// Работа теперь мгновенная: игрок проходит мини-игру (10 раундов "найди коробку
// с заводами повыше плотностью") и сразу получает жетоны, без часового ожидания.
const WORK_TOKENS_MIN = 5;
const WORK_TOKENS_MAX = 10;
const WORK_MAX_PER_DAY = 40;
const WORK_COOLDOWN_MS = 60 * 1000; // 1 минута между попытками работы

// ---- Мини-игра "работа": N раундов, в каждом нужно выбрать коробку с самой
// высокой плотностью заводов (коробки одинакового размера, но разного заполнения,
// и каждый раунд перемешиваются заново, так что нельзя жать одну и ту же кнопку).
const WORK_ROUNDS = 5;
const WORK_BOX_COUNT = 3; // сколько коробок показывается за раунд
const WORK_BOX_MIN_ICONS = 2;
const WORK_BOX_MAX_ICONS = 10;
const WORK_ROUND_TIMEOUT_MS = 25 * 1000; // если раунд не отвечен вовремя — попытка сгорает

// ===================== СКЛАД (КЕЙСЫ ЗА ЖЕТОНЫ) =====================

const WAREHOUSE_COST_TOKENS = 100;
const WAREHOUSE_BOX_COUNT = 5; // чисто визуально — какую бы коробку ни выбрал, шансы одинаковые

// Прямой обмен жетонов на завод (без рандома)
const EXCHANGE_FACTORY_COST_TOKENS = 50;

// Дневные лимиты на прямые обмены (сбрасываются в 00:00 МСК, см. game/warehouse.js)
const EXCHANGE_FACTORY_MAX_PER_DAY = 50; // "обменять" — не больше 50 заводов в день
const EXCHANGE_CASE_MAX_PER_DAY = 15; // "выбрать" (открытие кейса) — не больше 15 раз в день

// Прямой обмен жетонов на научный центр — только для игроков с активным VIP-статусом.
// Не больше EXCHANGE_SCIENCE_MAX_PER_DAY раз в день, и нельзя превысить обычный лимит числа
// научных центров (тот же, что и при постройке за заводы+вирты — см. game/science.js).
const EXCHANGE_SCIENCE_COST_TOKENS = 200;
const EXCHANGE_SCIENCE_MAX_PER_DAY = 10;

// Сумма шансов = 100. Пустых коробок нет. Кейс даёт только заводы, вооружение и вирты.
const WAREHOUSE_REWARDS = [
  { type: 'virts', chance: 30, min: 300, max: 900 },
  { type: 'weapon', key: 'Герань-2', chance: 18, min: 3, max: 5 },
  { type: 'weapon', key: 'Калибр', chance: 14, min: 1, max: 2 },
  { type: 'weapon', key: 'Орион', chance: 12, min: 2, max: 3 },
  { type: 'weapon', key: 'Искандер-М', chance: 9, min: 1, max: 2 },
  { type: 'air_defense', key: 'С-400 Триумф', chance: 8, min: 1, max: 2 },
  { type: 'factory', chance: 6, min: 1, max: 2 },
  { type: 'weapon', key: 'Сармат', chance: 3, min: 1, max: 1 },
];

// ===================== НАУЧНЫЕ ЦЕНТРЫ =====================

const SCIENCE_BUILD_FACTORY_COST = 10; // обычных заводов списывается за 1 центр
const SCIENCE_BUILD_VIRT_COST = 500;
const SCIENCE_INCOME_PER_HOUR = 24; // вирт/час за центр (в 3 раза больше обычного завода)

// level: текущий уровень, limit: сколько центров разрешено, cost: цена перехода НА этот уровень (0 для базового)
const SCIENCE_LIMIT_LEVELS = [
  { level: 1, limit: 5, cost: 0 },
  { level: 2, limit: 10, cost: 2000 },
  { level: 3, limit: 20, cost: 5000 },
  { level: 4, limit: 35, cost: 10000 },
  { level: 5, limit: 55, cost: 20000 },
  { level: 6, limit: 80, cost: 35000 },
  { level: 7, limit: 110, cost: 55000 },
  { level: 8, limit: 150, cost: 80000 },
  { level: 9, limit: 200, cost: 110000 },
  { level: 10, limit: 300, cost: 150000 },
];

// ===================== РАСШИРЕНИЕ ЛИМИТА ЗАВОДОВ =====================

const FACTORY_LIMIT_LEVELS = [
  { level: 0, limit: 100, cost: 0 },
  { level: 1, limit: 150, cost: 1000 },
  { level: 2, limit: 200, cost: 2000 },
  { level: 3, limit: 300, cost: 4000 },
  { level: 4, limit: 400, cost: 8000 },
  { level: 5, limit: 500, cost: 15000 },
  { level: 6, limit: 600, cost: 30000 },
  { level: 7, limit: 700, cost: 50000 },
  { level: 8, limit: 800, cost: 80000 },
  { level: 9, limit: 900, cost: 120000 },
  { level: 10, limit: 1000, cost: 200000 },
];

// ===================== АУКЦИОН =====================

const AUCTION_COMMISSION_RATE = 0.05; // 5% с продавца от финальной цены
const AUCTION_EXTEND_WINDOW_MS = 60 * 1000; // если ставка за 1 минуту до конца — продлеваем
const AUCTION_EXTEND_BY_MS = 5 * 60 * 1000; // продление на 5 минут
const AUCTION_MAX_DURATION_HOURS = 48;

module.exports = {
  FACTORY_BASE_PRICE,
  FACTORY_PRICE_GROWTH,
  FACTORY_MAX_COUNT,
  FACTORY_INCOME_PER_HOUR,
  GOLD_MINE_CHANCE,
  GOLD_MINE_MULTIPLIER,
  START_BALANCE,
  STARTER_FREE_FACTORIES,
  NEWBIE_BOOST_FACTORY_THRESHOLD,
  NEWBIE_BOOST_INCOME_BONUS,
  RENAME_COST,
  RECON_COST,


  EARLY_UNBLOCK_COST_PER_HOUR,
  MAP_MIN,
  MAP_MAX,
  RADIATION_INCOME_PENALTY,
  RADIATION_DURATION_MS,
  MIN_FACTORIES_TO_BE_ATTACKED,
  NEWBIE_PROTECTION_FACTORIES,
  INACTIVITY_ATTACK_BAN_DAYS,
  COMMAND_COOLDOWN_MS,
  MAX_COMMAND_MESSAGE_AGE_MS,
  FACTORY_BUILD_LIMIT_PER_HOUR,
  FACTORY_BUILD_MAX_PER_COMMAND,
  DAILY_BONUS_AMOUNT,
  DAILY_BONUS_COOLDOWN_MS,
  TRANSFER_COOLDOWN_MS,
  TRANSFER_MIN_AMOUNT,
  FACTORY_HP_UNIT,
  DRONE_LAUNCH_COOLDOWN_MS,
  MISSILE_LAUNCH_COOLDOWN_MS,
  NUKE_LAUNCH_COOLDOWN_MS,
  SKILL_TIERS,
  ADMIN_IDS,

  DONATE_VIP_PRICE_RUB_MONTH,
  DONATE_MINER_PRICE_RUB_MONTH,
  DONATE_SUPER_ROBOT_PRICE_RUB,
  ROBOT_MAX_LEVEL,
  ROBOT_TIER_SIZE,
  ROBOT_TIER_NAMES,
  ROBOT_UPGRADE_BASE_COST,
  ROBOT_UPGRADE_GROWTH,
  VIP_INCOME_BONUS,
  VIP_ROBOT_COOLDOWN_MULT,
  VIP_BUILD_LIMIT_BONUS,
  ROBOT_FARM_MIN_BASE,
  ROBOT_FARM_MIN_STEP,
  ROBOT_FARM_MAX_BASE,
  ROBOT_FARM_MAX_STEP,
  ROBOT_FARM_COOLDOWN_MS,
  ROBOT_SEND_COOLDOWN_MS,

  MINER_HOURLY_VIRTS_MIN,
  MINER_HOURLY_VIRTS_MAX,
  MINER_HOURLY_TOKENS,

  SUPER_ROBOT_MAX_LEVEL,
  SUPER_ROBOT_TIER_SIZE,
  SUPER_ROBOT_TIER_NAMES,
  SUPER_ROBOT_UPGRADE_BASE_COST,
  SUPER_ROBOT_UPGRADE_GROWTH,
  SUPER_ROBOT_FACTORIES_PER_LEVEL,
  SUPER_ROBOT_SPEED_KMH,
  SUPER_ROBOT_ATTACK_COOLDOWN_MS,
  SUPER_ROBOT_HUNT_REWARD_MIN,
  SUPER_ROBOT_HUNT_REWARD_MAX,
  SUPER_ROBOT_LOOT_RATE,
  SUPER_ROBOT_LOOT_MIN,
  SUPER_ROBOT_LOOT_MAX,
  SUPER_ROBOT_WEAPON_KEY,

  WEALTH_TAX_THRESHOLD,
  WEALTH_TAX_RATE,
  TOP_TAX,
  WEAPONS,
  NUKE_KEYS,
  AIR_DEFENSE,
  SHOP_REFRESH_MINUTES,
  SHOP_WEAPON_TYPES_MIN,
  SHOP_WEAPON_TYPES_MAX,
  SHOP_AD_TYPES_MIN,
  SHOP_AD_TYPES_MAX,
  SHOP_NUKE_CHANCE,
  SHOP_ITEM_QTY_MIN,
  SHOP_ITEM_QTY_MAX,
  SHOP_LOCKOUT_AFTER_NUKE_MIN,
  NON_NUKE_WEAPON_KEYS,
  MASS_PRODUCTION_FACTORY_THRESHOLD,
  MASS_PRODUCTION_TIME_BONUS,
  PRODUCTION_SPEED_MULTIPLIER,
  CLAN_CREATE_COST,
  CLAN_NAME_MIN,
  CLAN_NAME_MAX,
  CLAN_VAULT_INCOME_RATE,
  CLAN_VAULT_PER_FACTORY,
  CLAN_VAULT_LEVEL_STEP,
  CLAN_VAULT_MAX_LEVEL,
  CLAN_VAULT_LEVEL_CAPACITY_BONUS,
  CLAN_BONUSES,
  LOOT_RATE,
  LOOT_MIN,
  LOOT_MAX,
  WEAK_TARGET_RATIO_THRESHOLD,
  WEAK_TARGET_MIN_LOOT_MULTIPLIER,
  DAILY_FACTORY_REWARDS,
  DAILY_CLAN_REWARDS,

  CASINO_SLOT_COUNT,
  CASINO_MIN_BET,
  CASINO_MAX_BET,
  CASINO_COLOR_MULTIPLIER,
  CASINO_GREEN_MULTIPLIER,
  CASINO_COOLDOWN_MS,

  // ---- Новые механики ----
  WORK_TOKENS_MIN,
  WORK_TOKENS_MAX,
  WORK_MAX_PER_DAY,
  WORK_COOLDOWN_MS,
  WORK_ROUNDS,
  WORK_BOX_COUNT,
  WORK_BOX_MIN_ICONS,
  WORK_BOX_MAX_ICONS,
  WORK_ROUND_TIMEOUT_MS,

  WAREHOUSE_COST_TOKENS,
  WAREHOUSE_BOX_COUNT,
  WAREHOUSE_REWARDS,
  EXCHANGE_FACTORY_MAX_PER_DAY,
  EXCHANGE_CASE_MAX_PER_DAY,
  EXCHANGE_SCIENCE_COST_TOKENS,
  EXCHANGE_SCIENCE_MAX_PER_DAY,
  EXCHANGE_FACTORY_COST_TOKENS,


  SCIENCE_BUILD_FACTORY_COST,
  SCIENCE_BUILD_VIRT_COST,
  SCIENCE_INCOME_PER_HOUR,
  SCIENCE_LIMIT_LEVELS,

  FACTORY_LIMIT_LEVELS,

  AUCTION_COMMISSION_RATE,
  AUCTION_EXTEND_WINDOW_MS,
  AUCTION_EXTEND_BY_MS,
  AUCTION_MAX_DURATION_HOURS,
};
