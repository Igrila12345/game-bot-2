'use strict';

const players = require('../db/players');
const clansDb = require('../db/clans');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');

function isAdmin(vkId) {
  return C.ADMIN_IDS.includes(vkId);
}

function findWeaponKey(name) {
  const lower = (name || '').toLowerCase();
  return Object.keys(C.WEAPONS).find((k) => k.toLowerCase() === lower);
}

function findAirDefenseKey(name) {
  const lower = (name || '').toLowerCase();
  return Object.keys(C.AIR_DEFENSE).find((k) => k.toLowerCase() === lower);
}

const ADMIN_HELP = `🛠️ АДМИН-КОМАНДЫ

!админ баланс @юзер [сумма] — прибавить/отнять вирты (можно с минусом)
!админ завод @юзер [кол-во] — выдать заводы
!админ снести @юзер [кол-во] — принудительно снести заводы (без защиты новичков)
!админ оружие @юзер [название] [кол-во] — выдать оружие
!админ пво @юзер [название] [кол-во] — выдать ПВО
!админ разблок @юзер — снять все блокировки заводов
!админ инфо @юзер — полная информация об игроке
!админ обнулить @юзер — сбросить весь игровой прогресс игрока (баланс/заводы/оружие/жетоны/лимиты/питомец)
!админ обнулить всех — сбросить прогресс АБСОЛЮТНО ВСЕМ игрокам (осторожно!)
!админ vip @юзер [дни] — выдать/продлить VIP-статус на N дней (после получения оплаты)
!админ vip @юзер снять — досрочно снять VIP-статус
!админ майнер @юзер [дни] — выдать/продлить майнер (донат) на N дней (после получения оплаты)
!админ майнер @юзер снять — досрочно снять майнер
!админ суперробот @юзер [уровень] — выдать/повысить уровень суперробота (макс. ${C.SUPER_ROBOT_MAX_LEVEL})
!админ суперробот @юзер снять — снести суперробота (уровень 0)
!админ игроки [страница] — список всех игроков: кликабельные ссылки + игровые данные (по 15 на странице)
!админ рассылка [текст] — сообщение всем активным игрокам
!админ помощь — этот список

🎟️ Промокоды:
промо создать [код] [тип] [название|-] [кол-во] [лимит] [часов_жизни|0] — создать промокод
  типы: weapon, air_defense, virts, tokens, science
промо список — активные промокоды
промо удалить [код] — удалить промокод`;

async function requireTarget(ctx, targetId) {
  if (!targetId) {
    await ctx.send('⛔ Укажите игрока: !админ [команда] @юзер ...');
    return null;
  }
  const target = await players.getPlayer(targetId);
  if (!target || target.registration_step !== 'done') {
    await ctx.send('⛔ Этот игрок не зарегистрирован.');
    return null;
  }
  return target;
}

async function handleAdmin(ctx, sub, targetId, rest) {
  const vkId = ctx.senderId;
  if (!isAdmin(vkId)) {
    await ctx.send('⛔ Команда недоступна.');
    return;
  }

  switch (sub) {
    case 'помощь': {
      await ctx.send(ADMIN_HELP);
      return;
    }

    case 'баланс': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const amount = parseInt(rest[0], 10);
      if (!Number.isInteger(amount)) {
        await ctx.send('⛔ Формат: !админ баланс @юзер [сумма]');
        return;
      }
      const newBalance = await players.updateBalance(targetId, amount);
      await ctx.send(
        `✅ Баланс «${target.state_name}» изменён на ${amount > 0 ? '+' : ''}${amount}. Текущий баланс: ${calc.formatNumber(
          newBalance
        )} вирт.`
      );
      return;
    }

    case 'завод': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const amount = parseInt(rest[0], 10);
      if (!Number.isInteger(amount) || amount <= 0) {
        await ctx.send('⛔ Формат: !админ завод @юзер [кол-во]');
        return;
      }
      await players.addFactories(targetId, amount, false);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано ${amount} ${msg.pluralFactories(amount)}.`);
      return;
    }

    case 'снести': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const amount = parseInt(rest[0], 10);
      if (!Number.isInteger(amount) || amount <= 0) {
        await ctx.send('⛔ Формат: !админ снести @юзер [кол-во]');
        return;
      }
      let destroyed = 0;
      for (let i = 0; i < amount; i++) {
        const current = await players.getPlayer(targetId);
        if (!current || current.factories <= 0) break;
        await players.destroyOneFactory(targetId);
        destroyed++;
      }
      await ctx.send(`✅ У игрока «${target.state_name}» снесено ${destroyed} ${msg.pluralFactories(destroyed)}.`);
      return;
    }

    case 'оружие': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const qty = parseInt(rest[rest.length - 1], 10);
      const weaponName = rest.slice(0, -1).join(' ');
      const weaponKey = findWeaponKey(weaponName);
      if (!weaponKey || !Number.isInteger(qty) || qty <= 0) {
        await ctx.send('⛔ Формат: !админ оружие @юзер [название] [кол-во]');
        return;
      }
      await players.addToArsenal(targetId, weaponKey, qty);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано ${weaponKey} x${qty}.`);
      return;
    }

    case 'пво': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      const qty = parseInt(rest[rest.length - 1], 10);
      const adName = rest.slice(0, -1).join(' ');
      const adKey = findAirDefenseKey(adName);
      if (!adKey || !Number.isInteger(qty) || qty <= 0) {
        await ctx.send('⛔ Формат: !админ пво @юзер [название] [кол-во]');
        return;
      }
      await players.addToAirDefense(targetId, adKey, qty);
      await ctx.send(`✅ Игроку «${target.state_name}» выдано ПВО ${adKey} x${qty}.`);
      return;
    }

    case 'vip': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      if ((rest[0] || '').toLowerCase() === 'снять') {
        await players.setVipUntil(targetId, null);
        await ctx.send(`✅ VIP-статус игрока «${target.state_name}» снят.`);
        return;
      }

      const days = parseInt(rest[0], 10);
      if (!Number.isInteger(days) || days <= 0) {
        await ctx.send('⛔ Формат: !админ vip @юзер [дни] или !админ vip @юзер снять');
        return;
      }

      const now = new Date();
      const currentUntil = target.vip_until && new Date(target.vip_until) > now ? new Date(target.vip_until) : now;
      const newUntil = new Date(currentUntil.getTime() + days * 24 * 60 * 60 * 1000);
      await players.setVipUntil(targetId, newUntil);

      await ctx.send(
        `✅ VIP-статус игрока «${target.state_name}» активен до ${newUntil.toLocaleString('ru-RU')} (+${days} дн.).`
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(
            targetId,
            `👑 Вам выдан VIP-статус до ${newUntil.toLocaleString('ru-RU')}!\n` +
              `Бонусы: +${Math.round(C.VIP_INCOME_BONUS * 100)}% к доходу, кулдауны робота короче на ${Math.round(
                (1 - C.VIP_ROBOT_COOLDOWN_MULT) * 100
              )}%, +${C.VIP_BUILD_LIMIT_BONUS} построек завода в час.\nПроверить статус: мой робот`
          )
          .catch(() => {});
      }
      return;
    }

    case 'майнер': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      if ((rest[0] || '').toLowerCase() === 'снять') {
        await players.setMinerUntil(targetId, null);
        await ctx.send(`✅ Майнер игрока «${target.state_name}» снят.`);
        return;
      }

      const days = parseInt(rest[0], 10);
      if (!Number.isInteger(days) || days <= 0) {
        await ctx.send('⛔ Формат: !админ майнер @юзер [дни] или !админ майнер @юзер снять');
        return;
      }

      const now = new Date();
      const currentUntil =
        target.miner_until && new Date(target.miner_until) > now ? new Date(target.miner_until) : now;
      const newUntil = new Date(currentUntil.getTime() + days * 24 * 60 * 60 * 1000);
      await players.setMinerUntil(targetId, newUntil);

      await ctx.send(
        `✅ Майнер игрока «${target.state_name}» активен до ${newUntil.toLocaleString('ru-RU')} (+${days} дн.).`
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(
            targetId,
            `⛏️ Вам выдан майнер до ${newUntil.toLocaleString('ru-RU')}!\n` +
              `Каждый час пассивно приносит ${calc.formatNumber(C.MINER_HOURLY_VIRTS_MIN)} вирт и ${
                C.MINER_HOURLY_TOKENS
              } жетонов. Проверить статус: майнер`
          )
          .catch(() => {});
      }
      return;
    }

    case 'суперробот': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;

      if ((rest[0] || '').toLowerCase() === 'снять') {
        await players.setSuperRobotLevel(targetId, 0);
        await ctx.send(`✅ Суперробот игрока «${target.state_name}» снесён (уровень 0).`);
        return;
      }

      const level = parseInt(rest[0], 10);
      if (!Number.isInteger(level) || level <= 0) {
        await ctx.send('⛔ Формат: !админ суперробот @юзер [уровень] или !админ суперробот @юзер снять');
        return;
      }
      const clampedLevel = Math.min(level, C.SUPER_ROBOT_MAX_LEVEL);
      await players.setSuperRobotLevel(targetId, clampedLevel);

      await ctx.send(
        `✅ Суперроботу игрока «${target.state_name}» выдан уровень ${clampedLevel}${
          clampedLevel < level ? ` (ограничено максимумом ${C.SUPER_ROBOT_MAX_LEVEL})` : ''
        }.`
      );
      if (ctx.bot) {
        await ctx.bot
          .notifyUser(targetId, `🤖 Вам выдан суперробот уровня ${clampedLevel}!\nПроверить статус: суперробот`)
          .catch(() => {});
      }
      return;
    }

    case 'разблок': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      await players.setBlockedFactories(targetId, []);
      await ctx.send(`✅ Все блокировки заводов «${target.state_name}» сняты.`);
      return;
    }

    case 'инфо': {
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      let clanName = null;
      if (target.clan_id) {
        const clan = await clansDb.getClanById(target.clan_id);
        clanName = clan ? clan.name : null;
      }
      await ctx.send(
        `🛠️ ИНФО: ${target.state_name} (id${target.vk_id})\n` +
          `Баланс: ${calc.formatNumber(target.balance)}\n` +
          `Заводов: ${target.factories} (золотых: ${target.gold_mine_count})\n` +
          `Уничтожено (получено): ${target.destroyed_factories}\n` +
          `Снесено врагу: ${target.enemy_factories_destroyed || 0}\n` +
          `Урон накоплен на заводах: ${target.factory_damage || 0}\n` +
          `Клан: ${clanName || 'нет'}\n` +
          `Робот: ур. ${target.robot_level || 1} | Суперробот: ур. ${target.super_robot_level || 0}\n` +
          `Майнер: ${target.miner_until && new Date(target.miner_until) > new Date() ? 'активен до ' + new Date(target.miner_until).toLocaleString('ru-RU') : 'нет'}\n` +
          `Координаты: (${target.x}, ${target.y})\n` +
          `Последний визит: ${new Date(target.last_seen).toLocaleString('ru-RU')}`
      );
      return;
    }

    case 'обнулить': {
      if (targetId === 'всех') {
        const count = await players.resetAllPlayersProgress();
        await ctx.send(`✅ Прогресс сброшен АБСОЛЮТНО ВСЕМ игрокам (${count} шт.).`);
        return;
      }
      const target = await requireTarget(ctx, targetId);
      if (!target) return;
      await players.resetPlayerProgress(targetId);
      await ctx.send(`✅ Игровой прогресс игрока «${target.state_name}» полностью сброшен.`);
      if (ctx.bot) {
        await ctx.bot.notifyUser(targetId, '⚠️ Ваш игровой прогресс был сброшен администратором.').catch(() => {});
      }
      return;
    }

    case 'рассылка': {
      const text = rest.join(' ');
      if (!text) {
        await ctx.send('⛔ Формат: !админ рассылка [текст]');
        return;
      }
      const all = await players.getAllActivePlayers();
      let sent = 0;
      for (const p of all) {
        if (ctx.bot) {
          await ctx.bot.notifyUser(p.vk_id, `📢 ОБЪЯВЛЕНИЕ:\n${text}`).catch(() => {});
          sent++;
        }
      }
      await ctx.send(`✅ Рассылка отправлена ${sent} игрокам.`);
      return;
    }

    case 'игроки': {
      const PAGE_SIZE = 15;
      const pageArg = parseInt(rest[0], 10);
      const page = Number.isInteger(pageArg) && pageArg > 0 ? pageArg : 1;

      const total = await players.getPlayersCount();
      if (!total) {
        await ctx.send('📋 Зарегистрированных игроков пока нет.');
        return;
      }

      const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
      const safePage = Math.min(page, totalPages);
      const offset = (safePage - 1) * PAGE_SIZE;
      const list = await players.getPlayersPage(offset, PAGE_SIZE);

      let text = `📋 ВСЕ ИГРОКИ (стр. ${safePage}/${totalPages}, всего: ${total})\n\n`;
      list.forEach((p, i) => {
        const num = offset + i + 1;
        let clanPart = '';
        if (p.clan_id) clanPart = ` | клан: есть`;
        text +=
          `${num}. ${msg.mentionLink(p.vk_id, p.state_name)} (id${p.vk_id})\n` +
          `   💰 ${calc.formatNumber(p.balance)} вирт | 🏭 ${p.factories} завод. | 🤖 ур.${p.robot_level || 1} | 🪙 ${
            p.tokens || 0
          } жетонов${clanPart}\n`;
      });

      if (safePage < totalPages) {
        text += `\n➡️ Следующая страница: !админ игроки ${safePage + 1}`;
      }

      await ctx.send(text.trim());
      return;
    }

    default: {
      await ctx.send('⛔ Неизвестная админ-команда. !админ помощь — список команд.');
    }
  }
}

module.exports = { handleAdmin, isAdmin };
