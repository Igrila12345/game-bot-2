'use strict';

const players = require('../db/players');
const casino = require('../game/casino');
const casinoRender = require('../game/casinoRender');
const calc = require('../game/calc');
const C = require('../game/constants');

const COLOR_LABEL = { red: '🔴 красное', black: '⚫ чёрное', green: '🟢 зелёное' };

// Кулдаун между спинами одного игрока (в памяти процесса).
const lastSpinAt = new Map();
// Игроки, у которых спин прямо сейчас в процессе (ставка списана, идёт рендер/отправка).
// Пока vk_id в этом сете — новую ставку от него принимать нельзя, иначе можно словить
// повторное списание/гонку раньше, чем предыдущий спин доиграл.
const spinningPlayers = new Set();

// Общий лимит одновременных рендеров+отправок картинок по всему боту. Рендер (даже
// оптимизированный) и загрузка фото в VK — это не бесплатно, и если 50 игроков одновременно
// крутят рулетку, нельзя просто запускать всё сразу — начнёт лагать бот целиком (включая
// другие команды). Поэтому лишние запросы встают в очередь и ждут своей очереди, а не
// исполняются параллельно все разом.
const MAX_CONCURRENT_RENDERS = 4;
let activeRenders = 0;
const renderQueue = [];

function runQueued() {
  if (activeRenders >= MAX_CONCURRENT_RENDERS || renderQueue.length === 0) return;
  activeRenders++;
  const { task, resolve, reject } = renderQueue.shift();
  task()
    .then(resolve, reject)
    .finally(() => {
      activeRenders--;
      runQueued();
    });
}

function withRenderSlot(task) {
  return new Promise((resolve, reject) => {
    renderQueue.push({ task, resolve, reject });
    runQueued();
  });
}

function renderResultText(amount, betColor, outcome) {
  const slotColorLine = `Выпало: ${outcome.slot} (${COLOR_LABEL[outcome.resultColor]})`;
  return outcome.win
    ? `${slotColorLine}\n✅ Выигрыш! +${calc.formatNumber(outcome.payout)} вирт (ставка x${casino.multiplierFor(
        betColor
      )})`
    : `${slotColorLine}\n❌ Мимо. Ставка ${calc.formatNumber(amount)} вирт сгорела.`;
}

async function handleRoulette(ctx, amountArg, colorArg) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  if (spinningPlayers.has(vkId)) {
    await ctx.send('🎰 Колесо ещё крутится — дождитесь результата предыдущей ставки.');
    return;
  }

  const now = Date.now();
  const last = lastSpinAt.get(vkId);
  if (last && now - last < C.CASINO_COOLDOWN_MS) {
    await ctx.send('⏳ Не так быстро, подождите пару секунд между спинами.');
    return;
  }

  const betColor = casino.parseColor(colorArg);
  if (!betColor) {
    await ctx.send(
      `⛔ Укажите цвет: красное, чёрное или зелёное.\nПример: рулетка 100 красное`
    );
    return;
  }

  const amount = parseInt(amountArg, 10);
  if (!amount || amount <= 0 || Number.isNaN(amount)) {
    await ctx.send(`⛔ Укажите сумму ставки числом.\nПример: рулетка 100 красное`);
    return;
  }
  if (amount < C.CASINO_MIN_BET) {
    await ctx.send(`⛔ Минимальная ставка: ${C.CASINO_MIN_BET} вирт.`);
    return;
  }
  if (amount > C.CASINO_MAX_BET) {
    await ctx.send(`⛔ Максимальная ставка: ${C.CASINO_MAX_BET} вирт.`);
    return;
  }
  if (Number(player.balance) < amount) {
    await ctx.send(
      `⛔ Недостаточно вирт. У вас ${calc.formatNumber(player.balance)}, нужна ставка ${calc.formatNumber(amount)}.`
    );
    return;
  }

  // С этого момента и до конца — игрок "занят": блокируем повторные ставки от него,
  // пока не досчитаем и не отправим результат текущего спина.
  spinningPlayers.add(vkId);
  lastSpinAt.set(vkId, now);

  try {
    // Списываем ставку сразу, чтобы не было гонки при параллельных запросах.
    await players.updateBalance(vkId, -amount);

    const outcome = casino.resolveBet(amount, betColor);
    if (outcome.win) {
      await players.updateBalance(vkId, outcome.payout);
    }

    const caption =
      `🎰 РУЛЕТКА\n` +
      `Ставка: ${calc.formatNumber(amount)} вирт на ${COLOR_LABEL[betColor]}\n\n` +
      `${renderResultText(amount, betColor, outcome)}\n\n` +
      `💰 Баланс: ${calc.formatNumber(Number(player.balance) - amount + outcome.payout)} вирт`;

    try {
      // Рендер и загрузка фото идут через общую очередь — так много одновременных
      // спинов от разных игроков не устраивают бота в лаг все разом.
      const buffer = await withRenderSlot(() => casinoRender.renderWheel(outcome.slot, true));
      const photo = await ctx.bot.vk.upload.messagePhoto({
        source: buffer,
        peer_id: ctx.peerId,
      });
      await ctx.send({ message: caption, attachment: photo });
    } catch (err) {
      console.error('[Casino] Не удалось отрисовать/загрузить колесо, отправляю текстом:', err);
      await ctx.send(caption);
    }
  } finally {
    spinningPlayers.delete(vkId);
  }
}

module.exports = { handleRoulette };
