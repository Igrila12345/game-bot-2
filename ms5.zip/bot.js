'use strict';

const { VK } = require('vk-io');
const shopDb = require('./db/shop');

class Bot {
  constructor(token) {
    this.vk = new VK({ token });
  }

  async notifyUser(vkId, text) {
    try {
      await this.vk.api.messages.send({
        user_id: vkId,
        message: text,
        random_id: Math.floor(Math.random() * 1e9),
      });
    } catch (err) {
      // Пользователь мог заблокировать сообщения сообщества — не критично
      console.error(`[Bot] Не удалось отправить сообщение ${vkId}:`, err.message);
    }
  }

  async sendToChat(peerId, text) {
    try {
      await this.vk.api.messages.send({
        peer_id: peerId,
        message: text,
        random_id: Math.floor(Math.random() * 1e9),
      });
    } catch (err) {
      console.error(`[Bot] Не удалось отправить сообщение в беседу ${peerId}:`, err.message);
    }
  }

  async registerChatIfNeeded(ctx) {
    // Если сообщение пришло из беседы (peer_id > 2e9), запоминаем её для глобальных логов
    if (ctx.peerId && ctx.peerId > 2000000000) {
      await shopDb.addBroadcastChat(ctx.peerId).catch(() => {});
    }
  }

  onMessage(handler) {
    this.vk.updates.on('message_new', async (context, next) => {
      try {
        context.bot = this;
        await this.registerChatIfNeeded(context);
        await handler(context);
      } catch (err) {
        console.error('[Bot] Ошибка обработки сообщения:', err);
        try {
          await context.send('⛔ Произошла внутренняя ошибка. Попробуйте ещё раз позже.');
        } catch (_) {
          /* ignore */
        }
      }
      return next();
    });
  }

  async start() {
    await this.startWithRetry();
    console.log('[Bot] VK Long Poll запущен.');
  }

  // Если Long Poll обрывается (сеть, VK отдал 5xx и т.п.), не даём процессу просто затихнуть —
  // пробуем поднять соединение заново с нарастающей паузой, вместо падения всего бота.
  async startWithRetry(attempt = 1) {
    try {
      await this.vk.updates.start();
    } catch (err) {
      const delayMs = Math.min(60000, 3000 * attempt);
      console.error(
        `[Bot] Long Poll упал (попытка ${attempt}). Переподключение через ${delayMs / 1000} с.`,
        err.message
      );
      await new Promise((resolve) => setTimeout(resolve, delayMs));
      await this.startWithRetry(attempt + 1);
    }
  }
}

module.exports = Bot;
