// Конфиг для pm2 (https://pm2.keymetrics.io/) — процесс-менеджер, который держит бота
// живым: перезапускает при падении, ограничивает частоту перезапусков, пишет логи в файлы.
//
// Установка (один раз на сервере):
//   npm install -g pm2
//
// Запуск бота через pm2:
//   pm2 start ecosystem.config.js
//
// Полезные команды:
//   pm2 status            — статус процесса
//   pm2 logs vnn-bot       — смотреть логи в реальном времени
//   pm2 restart vnn-bot    — перезапустить вручную
//   pm2 stop vnn-bot       — остановить
//   pm2 startup && pm2 save — чтобы pm2 поднимал бота автоматически после перезагрузки сервера
'use strict';

module.exports = {
  apps: [
    {
      name: 'vnn-bot',
      script: 'index.js',
      cwd: __dirname,
      exec_mode: 'fork',
      instances: 1,
      autorestart: true, // перезапуск при падении процесса
      watch: false,
      max_restarts: 50, // не более 50 рестартов подряд — защита от бесконечного крэш-цикла
      min_uptime: '15s', // рестарт не считается "successful", если процесс прожил меньше 15с
      restart_delay: 3000, // пауза перед перезапуском, мс
      max_memory_restart: '400M', // подстраховка от утечек памяти — перезапуск при превышении
      out_file: './logs/out.log',
      error_file: './logs/error.log',
      merge_logs: true,
      time: true,
    },
  ],
};
