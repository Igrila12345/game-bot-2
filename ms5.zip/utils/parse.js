'use strict';

// Разбирает упоминание вида [id123|Имя] или @id123 или просто числовой id
function extractMentionId(token) {
  if (!token) return null;
  const bracketMatch = token.match(/\[id(\d+)\|[^\]]*\]/);
  if (bracketMatch) return Number(bracketMatch[1]);
  const atMatch = token.match(/^@?id?(\d+)$/);
  if (atMatch) return Number(atMatch[1]);
  return null;
}

// Ищет первое упоминание/id в тексте сообщения (или в массиве fwd/reply, обрабатывается отдельно)
function findMentionInText(text) {
  const bracketMatch = text.match(/\[id(\d+)\|[^\]]*\]/);
  if (bracketMatch) return Number(bracketMatch[1]);
  return null;
}

function splitArgs(text) {
  return text.trim().split(/\s+/).filter(Boolean);
}

module.exports = { extractMentionId, findMentionInText, splitArgs };
