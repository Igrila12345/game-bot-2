-- ===================== СХЕМА БАЗЫ ДАННЫХ =====================

CREATE TABLE IF NOT EXISTS players (
    vk_id BIGINT PRIMARY KEY,
    state_name TEXT UNIQUE,               -- название государства
    x INTEGER,                            -- координата X
    y INTEGER,                            -- координата Y
    balance BIGINT NOT NULL DEFAULT 100,  -- вирты
    factories INTEGER NOT NULL DEFAULT 0, -- количество активных (не уничтоженных) заводов
    gold_mines INTEGER[] DEFAULT '{}',    -- индексы заводов "золотая жила" (условно, храним как счётчик ниже)
    gold_mine_count INTEGER NOT NULL DEFAULT 0, -- сколько из заводов — золотые жилы (x2 дохода)
    destroyed_factories INTEGER NOT NULL DEFAULT 0, -- статистика: сколько заводов у игрока снесли навсегда (восстановление отключено)
    arsenal JSONB NOT NULL DEFAULT '{}',        -- {"Герань-2": 3, "Калибр": 1}
    air_defense JSONB NOT NULL DEFAULT '{}',    -- {"Бук-М3": 1}
    blocked_factories JSONB NOT NULL DEFAULT '[]', -- [{"count": 3, "unblock_at": "ISO"}]
    radiation_until TIMESTAMPTZ,           -- радиация действует до
    clan_id INTEGER,
    clan_role TEXT,                        -- 'leader' | 'member'
    registration_step TEXT NOT NULL DEFAULT 'done', -- 'awaiting_name' | 'done'
    factory_damage INTEGER NOT NULL DEFAULT 0, -- накопленные "единицы урона" по заводам для системы ХП (см. HITS_TO_DESTROY)
    enemy_factories_destroyed INTEGER NOT NULL DEFAULT 0, -- статистика: сколько вражеских заводов снёс безвозвратно
    last_daily_bonus TIMESTAMPTZ,          -- когда последний раз забирали ежедневный бонус
    pet_level INTEGER NOT NULL DEFAULT 1,          -- уровень питомца-робота (1-50)
    pet_mining_started_at TIMESTAMPTZ,             -- когда запустили добычу (NULL = не добывает)
    pet_last_collected_at TIMESTAMPTZ,             -- когда последний раз забирали доход питомца
    last_seen TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_players_factories ON players (factories DESC);
CREATE INDEX IF NOT EXISTS idx_players_balance ON players (balance DESC);

-- Восстановление заводов отключено, таблица больше не используется в новой логике,
-- но оставлена для обратной совместимости со старыми БД (данные не удаляются).
CREATE TABLE IF NOT EXISTS destroyed_factories (
    id SERIAL PRIMARY KEY,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    destroyed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    restore_at TIMESTAMPTZ NOT NULL
);

-- Клановые данные
CREATE TABLE IF NOT EXISTS clans (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    leader_id BIGINT NOT NULL REFERENCES players(vk_id),
    vault BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    bonus_forsazh_until TIMESTAMPTZ,
    bonus_eshelon_until TIMESTAMPTZ,
    bonus_industry_until TIMESTAMPTZ,
    bonus_forsazh_cooldown TIMESTAMPTZ,
    bonus_eshelon_cooldown TIMESTAMPTZ,
    bonus_industry_cooldown TIMESTAMPTZ
);

-- Приглашения в клан
CREATE TABLE IF NOT EXISTS clan_invites (
    id SERIAL PRIMARY KEY,
    clan_id INTEGER NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(clan_id, player_id)
);

-- Очереди производства
CREATE TABLE IF NOT EXISTS production_queue (
    id SERIAL PRIMARY KEY,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    weapon TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    factories_used INTEGER NOT NULL,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ready_at TIMESTAMPTZ NOT NULL,
    collected BOOLEAN NOT NULL DEFAULT FALSE
);

-- Атаки в полёте
CREATE TABLE IF NOT EXISTS attacks_in_flight (
    id SERIAL PRIMARY KEY,
    attacker_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    defender_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    weapon TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    distance_km NUMERIC NOT NULL,
    launched_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    arrival_at TIMESTAMPTZ NOT NULL,
    resolved BOOLEAN NOT NULL DEFAULT FALSE,
    peer_id BIGINT -- id беседы для глобального лога, если атака была инициирована из беседы (иначе NULL)
);

-- Кулдауны атак на конкретную цель
CREATE TABLE IF NOT EXISTS attack_cooldowns (
    attacker_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    defender_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    last_attack_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (attacker_id, defender_id)
);

-- Кулдауны переводов вирт одному и тому же игроку (1 раз в 2 часа на получателя)
CREATE TABLE IF NOT EXISTS transfer_cooldowns (
    sender_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    receiver_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    last_transfer_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (sender_id, receiver_id)
);

-- Лог построек заводов, для лимита "не более 10 заводов в час"
CREATE TABLE IF NOT EXISTS factory_build_log (
    id SERIAL PRIMARY KEY,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    built_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_factory_build_log_player_time ON factory_build_log (player_id, built_at);

-- На случай если таблица players уже существовала до добавления новых колонок (миграция)
ALTER TABLE players ADD COLUMN IF NOT EXISTS factory_damage INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_daily_bonus TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS enemy_factories_destroyed INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS pet_level INTEGER NOT NULL DEFAULT 1;
ALTER TABLE players ADD COLUMN IF NOT EXISTS pet_mining_started_at TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS pet_last_collected_at TIMESTAMPTZ;

-- Магазин (текущий ассортимент)
CREATE TABLE IF NOT EXISTS shop_state (
    id INTEGER PRIMARY KEY DEFAULT 1,
    items JSONB NOT NULL DEFAULT '[]', -- [{"key": "Герань-2", "type": "weapon", "qty": 3}]
    refreshed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    locked_until TIMESTAMPTZ -- блокировка магазина после покупки ядерки
);

INSERT INTO shop_state (id, items) VALUES (1, '[]') ON CONFLICT (id) DO NOTHING;

-- Глобальный peer_id беседы для трансляции логов (если бот добавлен в беседу)
CREATE TABLE IF NOT EXISTS broadcast_chats (
    peer_id BIGINT PRIMARY KEY
);

-- Метаданные (последний раз выданы ежедневные награды и т.п.)
CREATE TABLE IF NOT EXISTS game_meta (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- ===================== НОВЫЕ МЕХАНИКИ =====================

-- Работа и жетоны (мгновенная награда через мини-игру)
ALTER TABLE players ADD COLUMN IF NOT EXISTS tokens INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players DROP COLUMN IF EXISTS work_started_at; -- механика ожидания смены удалена
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_work_time TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS work_count_today INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS work_day DATE;
-- Текущая сессия мини-игры "работа": {round, boxes, correctIndex, expiresAt}, NULL если игра не идёт
ALTER TABLE players ADD COLUMN IF NOT EXISTS work_session JSONB;

-- Реферальная программа: кто пригласил + начислена ли уже награда
ALTER TABLE players ADD COLUMN IF NOT EXISTS referred_by BIGINT;
ALTER TABLE players ADD COLUMN IF NOT EXISTS referral_rewarded BOOLEAN NOT NULL DEFAULT FALSE;

-- Научные центры
ALTER TABLE players ADD COLUMN IF NOT EXISTS science_centers INTEGER NOT NULL DEFAULT 0;
ALTER TABLE players ADD COLUMN IF NOT EXISTS science_limit_level INTEGER NOT NULL DEFAULT 1;

-- Торговые посты — механика удалена, колонка вычищается из старых БД
ALTER TABLE players DROP COLUMN IF EXISTS trade_post_level;

-- Расширение лимита заводов
ALTER TABLE players ADD COLUMN IF NOT EXISTS factory_limit_level INTEGER NOT NULL DEFAULT 0;

-- Аукцион между игроками
CREATE TABLE IF NOT EXISTS auctions (
    id SERIAL PRIMARY KEY,
    seller_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    item_type TEXT NOT NULL,        -- 'weapon' | 'air_defense'
    item_name TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    start_price BIGINT NOT NULL,
    min_step BIGINT NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    current_bid BIGINT,
    current_bidder_id BIGINT REFERENCES players(vk_id),
    status TEXT NOT NULL DEFAULT 'active', -- 'active' | 'completed' | 'cancelled'
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_auctions_status ON auctions (status, end_time);

-- Промокоды
CREATE TABLE IF NOT EXISTS promocodes (
    code TEXT PRIMARY KEY,
    reward_type TEXT NOT NULL,      -- 'weapon' | 'air_defense' | 'virts' | 'tokens' | 'science'
    reward_name TEXT,               -- название оружия/ПВО (для остальных типов не нужно)
    reward_quantity INTEGER NOT NULL DEFAULT 1,
    max_uses INTEGER NOT NULL DEFAULT 1,
    used_count INTEGER NOT NULL DEFAULT 0,
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Кто уже активировал какой промокод (1 раз на игрока)
CREATE TABLE IF NOT EXISTS promocode_redemptions (
    code TEXT NOT NULL REFERENCES promocodes(code) ON DELETE CASCADE,
    player_id BIGINT NOT NULL REFERENCES players(vk_id) ON DELETE CASCADE,
    redeemed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (code, player_id)
);

-- Кулдауны запуска оружия по категориям (не привязаны к цели — см. game/combat.js)
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_drone_attack_at TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_missile_attack_at TIMESTAMPTZ;
ALTER TABLE players ADD COLUMN IF NOT EXISTS last_nuke_attack_at TIMESTAMPTZ;

-- Возможность отключить общую рассылку "кто-кого атаковал", которая приходит всем игрокам
ALTER TABLE players ADD COLUMN IF NOT EXISTS attack_log_notifications BOOLEAN NOT NULL DEFAULT TRUE;

-- Уровень сейфа клана: копится от ВСЕХ поступлений в сейф (налог с дохода + ручные пополнения)
-- и никогда не уменьшается тратами/снятием — это "прогресс" клана, а не баланс.
-- vault_total_collected — сколько всего когда-либо поступило в сейф (нарастающим итогом).
-- vault_level — текущий уровень (0-100), кэш от vault_total_collected / 10000, обновляется при пополнении.
ALTER TABLE clans ADD COLUMN IF NOT EXISTS vault_total_collected BIGINT NOT NULL DEFAULT 0;
ALTER TABLE clans ADD COLUMN IF NOT EXISTS vault_level INTEGER NOT NULL DEFAULT 0;
