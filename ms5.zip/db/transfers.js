'use strict';

const { query } = require('./pool');

async function setCooldown(senderId, receiverId) {
  await query(
    `INSERT INTO transfer_cooldowns (sender_id, receiver_id, last_transfer_at)
     VALUES ($1, $2, NOW())
     ON CONFLICT (sender_id, receiver_id) DO UPDATE SET last_transfer_at = NOW()`,
    [senderId, receiverId]
  );
}

async function getCooldown(senderId, receiverId) {
  const res = await query(
    'SELECT last_transfer_at FROM transfer_cooldowns WHERE sender_id = $1 AND receiver_id = $2',
    [senderId, receiverId]
  );
  return res.rows[0] ? res.rows[0].last_transfer_at : null;
}

module.exports = { setCooldown, getCooldown };
