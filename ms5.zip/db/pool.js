'use strict';

const { Pool, types } = require('pg');
const fs = require('fs');
const path = require('path');

// ВАЖНО (исправление бага со счётчиком "работы"): по умолчанию node-postgres парсит
// колонки типа DATE в JS Date на полночь ПО ЛОКАЛЬНОМУ ВРЕМЕНИ СЕРВЕРА, а не по UTC.
// Если сервер бота работает в часовом поясе восточнее UTC (например, МСК, UTC+3),
// то `new Date(work_day).toISOString().slice(0, 10)` может вернуть ВЧЕРАШНЮЮ дату —
// из-за этого game/work.js каждый раз думал, что наступил новый день, обнулял
// work_count_today и счётчик попыток работы никогда не накапливался (игрок делал
// 10 "смен", а бот всё равно показывал 39/40, а не 30/40). Отключаем парсинг DATE
// в объект Date и возвращаем его как обычную строку 'YYYY-MM-DD' — так сравнение
// с todayStr() (тоже строка) больше не зависит от часового пояса процесса.
types.setTypeParser(1082, (value) => value);

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

pool.on('error', (err) => {
  console.error('[DB] Неожиданная ошибка пула соединений:', err);
});

async function initSchema() {
  const schemaPath = path.join(__dirname, 'schema.sql');
  const sql = fs.readFileSync(schemaPath, 'utf8');
  await pool.query(sql);
  console.log('[DB] Схема базы данных инициализирована.');
}

async function query(text, params) {
  return pool.query(text, params);
}

module.exports = { pool, query, initSchema };
