'use strict';

const { query } = require('./pool');

async function getShopState() {
  const res = await query('SELECT * FROM shop_state WHERE id = 1');
  return res.rows[0];
}

async function setShopState(items, lockedUntil) {
  await query(
    `UPDATE shop_state SET items = $1::jsonb, refreshed_at = NOW(), locked_until = $2 WHERE id = 1`,
    [JSON.stringify(items), lockedUntil || null]
  );
}

async function addBroadcastChat(peerId) {
  await query(
    'INSERT INTO broadcast_chats (peer_id) VALUES ($1) ON CONFLICT DO NOTHING',
    [peerId]
  );
}

async function getBroadcastChats() {
  const res = await query('SELECT peer_id FROM broadcast_chats');
  return res.rows.map((r) => Number(r.peer_id));
}

async function getMeta(key) {
  const res = await query('SELECT value FROM game_meta WHERE key = $1', [key]);
  return res.rows[0] ? res.rows[0].value : null;
}

async function setMeta(key, value) {
  await query(
    `INSERT INTO game_meta (key, value) VALUES ($1, $2)
     ON CONFLICT (key) DO UPDATE SET value = $2`,
    [key, value]
  );
}

module.exports = {
  getShopState,
  setShopState,
  addBroadcastChat,
  getBroadcastChats,
  getMeta,
  setMeta,
};
