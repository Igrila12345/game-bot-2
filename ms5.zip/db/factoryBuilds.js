'use strict';

const { query } = require('./pool');

async function countRecentBuilds(vkId, sinceMs) {
  const res = await query(
    `SELECT COUNT(*)::int AS cnt FROM factory_build_log
     WHERE player_id = $1 AND built_at > NOW() - ($2 || ' milliseconds')::interval`,
    [vkId, sinceMs]
  );
  return res.rows[0] ? res.rows[0].cnt : 0;
}

async function logBuild(vkId) {
  await query('INSERT INTO factory_build_log (player_id) VALUES ($1)', [vkId]);
}

module.exports = { countRecentBuilds, logBuild };
