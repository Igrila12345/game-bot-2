'use strict';

const { query } = require('./pool');
const C = require('../game/constants');

function levelFromTotal(total) {
  return Math.min(C.CLAN_VAULT_MAX_LEVEL, Math.floor(Number(total) / C.CLAN_VAULT_LEVEL_STEP));
}

async function getClanById(id) {
  const res = await query('SELECT * FROM clans WHERE id = $1', [id]);
  return res.rows[0] || null;
}

async function getClanByName(name) {
  const res = await query('SELECT * FROM clans WHERE LOWER(name) = LOWER($1)', [name]);
  return res.rows[0] || null;
}

async function createClan(name, leaderId) {
  const res = await query(
    `INSERT INTO clans (name, leader_id) VALUES ($1, $2) RETURNING *`,
    [name, leaderId]
  );
  return res.rows[0];
}

async function getClanMembers(clanId) {
  const res = await query('SELECT * FROM players WHERE clan_id = $1', [clanId]);
  return res.rows;
}

// Пополнение сейфа (налог с дохода или ручной взнос игрока). Сам сейф капается по maxVault,
// но vault_total_collected растёт на всю сумму без ограничения — именно он определяет уровень сейфа.
async function addVault(clanId, amount, maxVault) {
  const res = await query(
    `UPDATE clans
     SET vault = LEAST(vault + $2, $3),
         vault_total_collected = vault_total_collected + $2
     WHERE id = $1
     RETURNING vault, vault_total_collected`,
    [clanId, amount, maxVault]
  );
  if (!res.rows[0]) return null;
  return {
    vault: Number(res.rows[0].vault),
    totalCollected: Number(res.rows[0].vault_total_collected),
  };
}

// Пересчитывает и сохраняет уровень сейфа исходя из общей суммы, когда-либо собранной.
// Уровень — это прогресс клана, поэтому он никогда не пересчитывается в меньшую сторону.
async function syncVaultLevel(clanId, totalCollected) {
  const level = levelFromTotal(Number(totalCollected));
  const res = await query(
    `UPDATE clans SET vault_level = $2 WHERE id = $1 AND vault_level < $2 RETURNING vault_level`,
    [clanId, level]
  );
  return { level, leveledUp: res.rows.length > 0 };
}

// Трата сейфа на клановые бонусы — не влияет на vault_total_collected/уровень.
async function spendVault(clanId, amount) {
  const res = await query(
    `UPDATE clans SET vault = vault - $2 WHERE id = $1 AND vault >= $2 RETURNING vault`,
    [clanId, amount]
  );
  return res.rows[0] ? Number(res.rows[0].vault) : null;
}

// Снятие сейфа главой клана себе на баланс — тоже не влияет на уровень (он только растёт).
async function withdrawVault(clanId, amount) {
  const res = await query(
    `UPDATE clans SET vault = vault - $2 WHERE id = $1 AND vault >= $2 RETURNING vault`,
    [clanId, amount]
  );
  return res.rows[0] ? Number(res.rows[0].vault) : null;
}

async function setBonusActive(clanId, bonusKey, until, cooldownUntil) {
  const colUntil = `bonus_${bonusKey}_until`;
  const colCd = `bonus_${bonusKey}_cooldown`;
  await query(
    `UPDATE clans SET ${colUntil} = $2, ${colCd} = $3 WHERE id = $1`,
    [clanId, until, cooldownUntil]
  );
}

async function createInvite(clanId, playerId) {
  await query(
    `INSERT INTO clan_invites (clan_id, player_id) VALUES ($1, $2)
     ON CONFLICT (clan_id, player_id) DO NOTHING`,
    [clanId, playerId]
  );
}

async function hasInvite(clanId, playerId) {
  const res = await query(
    'SELECT 1 FROM clan_invites WHERE clan_id = $1 AND player_id = $2',
    [clanId, playerId]
  );
  return res.rows.length > 0;
}

async function removeInvite(clanId, playerId) {
  await query('DELETE FROM clan_invites WHERE clan_id = $1 AND player_id = $2', [
    clanId,
    playerId,
  ]);
}

async function getClanFactoriesSum(clanId) {
  const res = await query(
    'SELECT COALESCE(SUM(factories), 0) AS total FROM players WHERE clan_id = $1',
    [clanId]
  );
  return Number(res.rows[0].total);
}

async function getTopClansByFactories(limit = 10) {
  const res = await query(
    `SELECT c.id, c.name, c.vault, c.leader_id, COALESCE(SUM(p.factories), 0) AS total_factories
     FROM clans c
     LEFT JOIN players p ON p.clan_id = c.id
     GROUP BY c.id
     ORDER BY total_factories DESC
     LIMIT $1`,
    [limit]
  );
  return res.rows;
}

async function getAllClans() {
  const res = await query('SELECT * FROM clans');
  return res.rows;
}

module.exports = {
  getClanById,
  getClanByName,
  createClan,
  getClanMembers,
  addVault,
  syncVaultLevel,
  levelFromTotal,
  spendVault,
  withdrawVault,
  setBonusActive,
  createInvite,
  hasInvite,
  removeInvite,
  getClanFactoriesSum,
  getTopClansByFactories,
  getAllClans,
};
