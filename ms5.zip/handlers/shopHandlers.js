'use strict';

const shop = require('../game/shop');
const shopDb = require('../db/shop');
const players = require('../db/players');
const calc = require('../game/calc');
const msg = require('../utils/messages');
const C = require('../game/constants');

async function handleShop(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const state = await shopDb.getShopState();
  const refreshMs = C.SHOP_REFRESH_MINUTES * 60 * 1000;
  const refreshedAt = new Date(state.refreshed_at).getTime();
  const msUntilRefresh = refreshMs - ((Date.now() - refreshedAt) % refreshMs);

  await ctx.send(msg.shopMessage(state.items || [], player, msUntilRefresh));
}

async function handleBuy(ctx, itemNameRaw, qtyArg) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!itemNameRaw) {
    await ctx.send('⛔ Укажите название товара: !купить [название] [количество]');
    return;
  }

  const quantity = qtyArg ? parseInt(qtyArg, 10) : 1;
  if (!Number.isInteger(quantity) || quantity <= 0) {
    await ctx.send('⛔ Некорректное количество.');
    return;
  }

  const result = await shop.buyItem(vkId, itemNameRaw, quantity);

  if (!result.ok) {
    if (result.reason === 'not_in_shop') {
      await ctx.send('⛔ Такого товара сейчас нет в магазине.');
    } else if (result.reason === 'not_enough_stock') {
      await ctx.send(`⛔ В наличии только ${result.available} шт.`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(`⛔ Недостаточно вирт. Не хватает ${calc.formatNumber(result.missing)}.`);
    } else if (result.reason === 'shop_locked') {
      await ctx.send('⛔ Магазин временно закрыт после продажи ядерного оружия. Попробуйте позже.');
    } else {
      await ctx.send('⛔ Не удалось совершить покупку.');
    }
    return;
  }

  let text = `✅ Куплено: ${result.item.key} x${quantity} за ${calc.formatNumber(result.totalCost)} вирт.`;
  if (result.isNuke) {
    text += `\n☢️ Магазин закрыт на ${C.SHOP_LOCKOUT_AFTER_NUKE_MIN} минут после продажи ядерного оружия.`;
  }
  await ctx.send(text);
}

async function handleArsenal(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  await ctx.send(
    `⚔️ АРСЕНАЛ:\n${msg.arsenalToText(player.arsenal)}\n\n🛅 ПВО:\n${msg.arsenalToText(player.air_defense)}`
  );
}

// Справочная команда: характеристики и цены всего оружия/ПВО в игре (не требует регистрации)
async function handleWeaponsInfo(ctx) {
  await ctx.send(msg.weaponsInfoMessage());
}

module.exports = { handleShop, handleBuy, handleArsenal, handleWeaponsInfo };
