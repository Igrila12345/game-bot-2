'use strict';

const players = require('../db/players');
const science = require('../game/science');
const calc = require('../game/calc');
const C = require('../game/constants');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

async function handleStatus(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const limit = calc.currentScienceLimit(player.science_limit_level);
  const nextRow = C.SCIENCE_LIMIT_LEVELS.find((l) => l.level === (player.science_limit_level || 1) + 1);

  let text =
    `🔬 НАУЧНЫЕ ЦЕНТРЫ\n` +
    `Построено: ${player.science_centers || 0}/${limit}\n` +
    `Доход с центра: ${C.SCIENCE_INCOME_PER_HOUR} вирт/час\n` +
    `Постройка: ${C.SCIENCE_BUILD_FACTORY_COST} заводов + ${C.SCIENCE_BUILD_VIRT_COST} вирт — наука построить`;

  if (nextRow) {
    text += `\n\n📈 Расширить лимит до ${nextRow.limit}: ${calc.formatNumber(nextRow.cost)} вирт — наука расширить`;
  } else {
    text += `\n\n🏆 Максимальный уровень лимита достигнут!`;
  }

  await ctx.send(text);
}

async function handleBuild(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await science.buildCenter(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'limit_reached') {
      await ctx.send(`⛔ Достигнут лимит научных центров (${result.limit}). Расширьте: наука расширить`);
    } else if (result.reason === 'not_enough_factories') {
      await ctx.send(`⛔ Нужно ${result.need} обычных заводов (есть: ${result.have}).`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(`⛔ Недостаточно вирт. Не хватает ${calc.formatNumber(result.missing)}.`);
    } else {
      await ctx.send('⛔ Не удалось построить научный центр.');
    }
    return;
  }

  await ctx.send(
    `🔬 НАУЧНЫЙ ЦЕНТР ПОСТРОЕН!\n${C.SCIENCE_BUILD_FACTORY_COST} заводов было списано.\nНовый доход: +${C.SCIENCE_INCOME_PER_HOUR} вирт/час.`
  );
}

async function handleExpand(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await science.expandLimit(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send('⛔ Уже максимальный уровень лимита научных центров.');
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось расширить лимит.');
    }
    return;
  }

  await ctx.send(`✅ Лимит научных центров расширен до ${result.newLimit}! Потрачено: ${calc.formatNumber(result.cost)} вирт.`);
}

module.exports = { handleStatus, handleBuild, handleExpand };
