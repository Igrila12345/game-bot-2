'use strict';

const players = require('../db/players');
const production = require('../db/production');
const clansDb = require('../db/clans');
const calc = require('../game/calc');
const msg = require('../utils/messages');
const C = require('../game/constants');

const NAME_REGEX = /^[a-zA-Zа-яА-ЯёЁ0-9 ]{2,30}$/;

async function handleStart(ctx, referrerArg) {
  const vkId = ctx.senderId;
  let player = await players.getPlayer(vkId);

  if (!player) {
    let referredBy = null;
    if (referrerArg && /^\d+$/.test(referrerArg)) {
      const refId = Number(referrerArg);
      if (refId !== vkId) {
        const referrer = await players.getPlayer(refId);
        if (referrer) referredBy = refId;
      }
    }

    player = await players.createPlayerStub(vkId, referredBy);
    await ctx.send(
      `🏛️ Добро пожаловать, Командир!\n` +
        `Ваш народ ждёт великих свершений. Дайте название вашему государству (городу/империи):\n` +
        `- От 2 до 30 символов\n` +
        `- Только буквы, цифры и пробелы`
    );
    return;
  }

  if (player.registration_step === 'awaiting_name') {
    await ctx.send('✅ Вы уже начали регистрацию. Напишите название вашего государства сообщением.');
    return;
  }

  await ctx.send(`👋 С возвращением, «${player.state_name}»! Введите !помощь для списка команд.`);
}

async function handleNameInput(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'awaiting_name') return false;

  const name = ctx.text.trim();

  if (!NAME_REGEX.test(name)) {
    await ctx.send(
      '⛔ Название должно быть от 2 до 30 символов и содержать только буквы, цифры и пробелы. Попробуйте снова.'
    );
    return true;
  }

  const existing = await players.getPlayerByName(name);
  if (existing) {
    await ctx.send('⛔ Это название уже занято. Придумайте другое.');
    return true;
  }

  const updated = await players.finalizeRegistration(vkId, name);

  let referralLine = '';
  if (updated.referred_by && !updated.referral_rewarded) {
    const referrer = await players.getPlayer(updated.referred_by);
    if (referrer) {
      await players.updateBalance(updated.referred_by, C.REFERRAL_INVITER_REWARD);
      await players.updateBalance(vkId, C.REFERRAL_INVITED_REWARD);
      await players.setReferralRewarded(vkId);
      referralLine = `🎁 Реферальный бонус: +${C.REFERRAL_INVITED_REWARD} вирт (вас пригласили)\n`;
      if (ctx.bot) {
        await ctx.bot.notifyUser(
          updated.referred_by,
          `🎉 По вашей реферальной ссылке зарегистрировался новый Командир: «${updated.state_name}»!\nНачислено: +${C.REFERRAL_INVITER_REWARD} вирт.`
        );
      }
    }
  }

  await ctx.send(
    `✅ Отлично! Государство «${updated.state_name}» основано!\n` +
      `📍 Ваши координаты на карте: (${updated.x}, ${updated.y})\n` +
      `🎁 Вам выдано ${C.START_BALANCE} вирт.\n` +
      referralLine +
      `\n📚 КРАТКАЯ ИНСТРУКЦИЯ:\n` +
      `🏭 !построить — построить завод (стоимость зависит от количества)\n` +
      `🏪 !магазин — купить оружие и ПВО\n` +
      `⚔️ !атака @юзер [оружие] [количество] — атаковать игрока\n` +
      `🏭 !произвести [оружие] [количество] [заводов] — производить оружие\n` +
      `👷 !работа — мини-игра на жетоны (можно 40 раз в день)\n` +
      `💰 !профиль — посмотреть свою статистику\n` +
      `👥 !клан создать [название] — создать клан\n` +
      `🔗 !рефералы — ваша реферальная ссылка\n\n` +
      `Удачи в бою, Командир!`
  );
  return true;
}

async function handleProfile(ctx, targetId) {
  const vkId = targetId || ctx.senderId;
  const player = await players.getPlayer(vkId);

  if (!player || player.registration_step !== 'done') {
    await ctx.send(targetId ? '⛔ Этот игрок ещё не зарегистрирован.' : '⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const allByFactories = await players.getTopByFactories(1000);
  const rank = allByFactories.findIndex((p) => p.vk_id === player.vk_id) + 1;

  const factoriesInProd = await production.getFactoriesInUse(vkId);
  const income = calc.incomePerHour(player, factoriesInProd);

  let clanName = null;
  if (player.clan_id) {
    const clan = await clansDb.getClanById(player.clan_id);
    clanName = clan ? clan.name : null;
  }

  await ctx.send(msg.profileMessage(player, rank, income, clanName));
}

async function handleRename(ctx, newName) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!newName || !NAME_REGEX.test(newName)) {
    await ctx.send('⛔ Название должно быть от 2 до 30 символов (буквы, цифры, пробелы).');
    return;
  }

  if (Number(player.balance) < C.RENAME_COST) {
    await ctx.send(`⛔ Недостаточно вирт. Нужно ${C.RENAME_COST}, у вас ${calc.formatNumber(player.balance)}.`);
    return;
  }

  const existing = await players.getPlayerByName(newName);
  if (existing) {
    await ctx.send('⛔ Это название уже занято.');
    return;
  }

  await players.updateBalance(vkId, -C.RENAME_COST);
  await players.renamePlayer(vkId, newName);
  await ctx.send(`✅ Государство переименовано в «${newName}»!`);
}

async function handleReferrals(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const count = await players.countReferrals(vkId);
  const groupId = process.env.VK_GROUP_ID;
  // vk.me/write-<id> открывает диалог с сообществом и подставляет готовый текст,
  // так что другу достаточно один раз нажать "Отправить" — вводить "старт <id>" вручную не нужно.
  const link = groupId
    ? `https://vk.me/write-${groupId}?text=${encodeURIComponent('!старт ' + vkId)}`
    : `!старт ${vkId} (отправьте другу как текст первого сообщения боту)`;

  await ctx.send(
    `🔗 РЕФЕРАЛЬНАЯ ПРОГРАММА\n` +
      `Приглашайте друзей — за каждого, кто закончит регистрацию, вы получаете ${C.REFERRAL_INVITER_REWARD} вирт, а он — ${C.REFERRAL_INVITED_REWARD} вирт.\n\n` +
      `Ваша ссылка:\n${link}\n\n` +
      `👥 Приглашено (завершили регистрацию): ${count}`
  );
}

module.exports = { handleStart, handleNameInput, handleProfile, handleRename, handleReferrals, NAME_REGEX };
