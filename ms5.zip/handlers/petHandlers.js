'use strict';

const players = require('../db/players');
const pet = require('../game/pet');
const calc = require('../game/calc');
const C = require('../game/constants');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

async function handleStatus(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const level = player.pet_level || 1;
  const incomeHour = pet.incomePerHour(level);
  const mining = !!player.pet_mining_started_at;

  let text = `🤖 РОБОТ\nУровень: ${level}/${C.PET_MAX_LEVEL}\nДоход: ${incomeHour} вирт/час\n`;

  if (mining) {
    const earned = pet.calcEarned(player);
    text += `⛏️ Статус: добывает\nНакоплено: ${calc.formatNumber(earned)} вирт (максимум за ${C.PET_MAX_ACCUMULATION_HOURS} ч)\n\nЗабрать: робот забрать`;
  } else {
    text += `😴 Статус: отдыхает\n\nЗапустить добычу: робот старт`;
  }

  if (level < C.PET_MAX_LEVEL) {
    text += `\n\n📈 Прокачка до ур. ${level + 1}: ${calc.formatNumber(pet.upgradeCost(level))} вирт — робот прокачать`;
  } else {
    text += `\n\n🏆 Максимальный уровень достигнут!`;
  }

  await ctx.send(text);
}

async function handleUpgrade(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await pet.upgradePet(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send(`⛔ У робота уже максимальный уровень (${C.PET_MAX_LEVEL}).`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось прокачать робота.');
    }
    return;
  }

  await ctx.send(
    `✅ Робот прокачан до уровня ${result.newLevel} за ${calc.formatNumber(result.cost)} вирт! Доход теперь: ${pet.incomePerHour(
      result.newLevel
    )} вирт/час.`
  );
}

async function handleStart(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await pet.startMining(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'already_mining') {
      await ctx.send('⛔ Робот уже добывает. Заберите доход командой: робот забрать');
    } else {
      await ctx.send('⛔ Не удалось запустить робота.');
    }
    return;
  }

  await ctx.send(
    `⛏️ Робот отправлен на добычу! Доход: ${result.incomePerHour} вирт/час (копится максимум ${C.PET_MAX_ACCUMULATION_HOURS} ч). Не забудьте забрать: робот забрать`
  );
}

async function handleCollect(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await pet.collectMining(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'not_mining') {
      await ctx.send('⛔ Робот сейчас не добывает. Запустите: робот старт');
    } else {
      await ctx.send('⛔ Не удалось забрать доход.');
    }
    return;
  }

  await ctx.send(`✅ Робот принёс ${calc.formatNumber(result.earned)} вирт! Запустите его снова: робот старт`);
}

module.exports = { handleStatus, handleUpgrade, handleStart, handleCollect };
