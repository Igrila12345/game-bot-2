'use strict';

const production = require('../game/production');
const productionDb = require('../db/production');
const players = require('../db/players');
const calc = require('../game/calc');
const C = require('../game/constants');

function findWeaponKey(name) {
  const lower = name.toLowerCase();
  return Object.keys(C.WEAPONS).find((k) => k.toLowerCase() === lower);
}

async function handleProduce(ctx, weaponArg, qtyArg, factoriesArg) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const weaponKey = findWeaponKey(weaponArg || '');
  if (!weaponKey) {
    await ctx.send('⛔ Неизвестное оружие. Проверьте название, например: !произвести Калибр 5 10');
    return;
  }

  const quantity = parseInt(qtyArg, 10);
  const factoriesToUse = parseInt(factoriesArg, 10);

  if (!Number.isInteger(quantity) || quantity <= 0 || !Number.isInteger(factoriesToUse) || factoriesToUse <= 0) {
    await ctx.send('⛔ Укажите корректное количество и число заводов: !произвести [оружие] [количество] [заводов]');
    return;
  }

  const result = await production.startProduction(vkId, weaponKey, quantity, factoriesToUse);

  if (!result.ok) {
    if (result.reason === 'not_enough_free_factories') {
      await ctx.send(`⛔ У вас нет столько свободных заводов. Свободно: ${result.freeFactories}.`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.totalCost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось запустить производство.');
    }
    return;
  }

  await ctx.send(
    `🏭 ЗАПУЩЕНО ПРОИЗВОДСТВО:\n` +
      `Оружие: ${weaponKey} (x${quantity})\n` +
      `Заводов выделено: ${factoriesToUse}${result.massBonusApplied ? ' (бонус «Военный завод» применён)' : ''}\n` +
      `Время производства: ${calc.formatDuration(result.totalMinutes * 60 * 1000)}\n` +
      `Стоимость: ${calc.formatNumber(result.totalCost)} вирт\n` +
      `Доход снижен на ${result.incomeLostPerHour} вирт/час.\n\n` +
      `⏳ Готово через ${calc.formatDuration(result.totalMinutes * 60 * 1000)}.`
  );
}

async function handleProductionStatus(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const active = await productionDb.getActiveProductionsByPlayer(vkId);
  if (!active.length) {
    await ctx.send('🏭 У вас нет активных производств.');
    return;
  }

  const now = Date.now();
  let text = '🏭 СТАТУС ПРОИЗВОДСТВА:\n\n';
  active.forEach((p, i) => {
    const readyAt = new Date(p.ready_at).getTime();
    const status = readyAt <= now ? '✅ готово (заберите: !забрать)' : `⏳ ${calc.formatDuration(readyAt - now)}`;
    text += `${i + 1}. ${p.weapon} x${p.quantity} (заводов: ${p.factories_used}) — ${status}\n`;
  });

  await ctx.send(text.trim());
}

async function handleCollect(ctx, weaponArg, qtyArg) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const weaponKey = findWeaponKey(weaponArg || '');
  if (!weaponKey) {
    await ctx.send('⛔ Неизвестное оружие.');
    return;
  }

  const quantity = parseInt(qtyArg, 10);
  if (!Number.isInteger(quantity) || quantity <= 0) {
    await ctx.send('⛔ Укажите корректное количество: !забрать [оружие] [количество]');
    return;
  }

  const result = await production.collectWeapon(vkId, weaponKey, quantity);
  if (!result.ok) {
    await ctx.send('⛔ Готового оружия этого типа пока нет.');
    return;
  }

  await ctx.send(`✅ Забрано из производства: ${weaponKey} x${result.collected}. Оружие в арсенале!`);
}

module.exports = { handleProduce, handleProductionStatus, handleCollect };
