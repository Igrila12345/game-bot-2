'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');

function rollReward() {
  const roll = Math.random() * 100;
  let cumulative = 0;
  for (const reward of C.WAREHOUSE_REWARDS) {
    cumulative += reward.chance;
    if (roll < cumulative) return reward;
  }
  return C.WAREHOUSE_REWARDS[0];
}

async function openBox(vkId, boxNumber) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  if (!Number.isInteger(boxNumber) || boxNumber < 1 || boxNumber > C.WAREHOUSE_BOX_COUNT) {
    return { ok: false, reason: 'invalid_box' };
  }

  if ((player.tokens || 0) < C.WAREHOUSE_COST_TOKENS) {
    return { ok: false, reason: 'not_enough_tokens', missing: C.WAREHOUSE_COST_TOKENS - (player.tokens || 0) };
  }

  await players.addTokens(vkId, -C.WAREHOUSE_COST_TOKENS);

  const reward = rollReward();
  const qty = reward.min === reward.max ? reward.min : calc.randomInt(reward.min, reward.max);

  switch (reward.type) {
    case 'virts':
      await players.updateBalance(vkId, qty);
      break;
    case 'tokens':
      await players.addTokens(vkId, qty);
      break;
    case 'weapon':
      await players.addToArsenal(vkId, reward.key, qty);
      break;
    case 'air_defense':
      await players.addToAirDefense(vkId, reward.key, qty);
      break;
    case 'factory':
      await players.addFactories(vkId, qty, false);
      break;
    case 'gold_mine':
      // Превращаем 1 обычный завод в "золотую жилу" (если заводов нет — просто добавляем новый золотой)
      if (player.factories > 0) {
        await players.addFactories(vkId, 0, true); // 0 новых заводов, +1 к gold_mine_count
      } else {
        await players.addFactories(vkId, 1, true);
      }
      break;
    default:
      break;
  }

  return { ok: true, reward, qty };
}

// Прямой гарантированный обмен: EXCHANGE_FACTORY_COST_TOKENS жетонов -> 1 завод
async function exchangeForFactory(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  if ((player.tokens || 0) < C.EXCHANGE_FACTORY_COST_TOKENS) {
    return {
      ok: false,
      reason: 'not_enough_tokens',
      missing: C.EXCHANGE_FACTORY_COST_TOKENS - (player.tokens || 0),
    };
  }

  const remainingTokens = await players.addTokens(vkId, -C.EXCHANGE_FACTORY_COST_TOKENS);
  await players.addFactories(vkId, 1, false);

  return { ok: true, remainingTokens };
}

module.exports = { openBox, rollReward, exchangeForFactory };
