'use strict';

const C = require('./constants');
const players = require('../db/players');
const auctionsDb = require('../db/auctions');

function findItem(itemName) {
  const lower = itemName.toLowerCase();
  const weaponKey = Object.keys(C.WEAPONS).find((k) => k.toLowerCase() === lower);
  if (weaponKey) return { type: 'weapon', key: weaponKey };
  const adKey = Object.keys(C.AIR_DEFENSE).find((k) => k.toLowerCase() === lower);
  if (adKey) return { type: 'air_defense', key: adKey };
  return null;
}

async function createLot(vkId, itemName, quantity, startPrice, minStep, durationHours) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const item = findItem(itemName);
  if (!item) return { ok: false, reason: 'unknown_item' };

  if (!Number.isInteger(quantity) || quantity <= 0) return { ok: false, reason: 'invalid_quantity' };
  if (!Number.isInteger(startPrice) || startPrice <= 0) return { ok: false, reason: 'invalid_price' };
  if (!Number.isInteger(minStep) || minStep <= 0) return { ok: false, reason: 'invalid_step' };
  if (!Number.isFinite(durationHours) || durationHours <= 0 || durationHours > C.AUCTION_MAX_DURATION_HOURS) {
    return { ok: false, reason: 'invalid_duration', max: C.AUCTION_MAX_DURATION_HOURS };
  }

  const owned = item.type === 'weapon' ? player.arsenal[item.key] || 0 : player.air_defense[item.key] || 0;
  if (owned < quantity) {
    return { ok: false, reason: 'not_enough_items', have: owned };
  }

  // Забираем предмет на эскроу аукциона
  if (item.type === 'weapon') {
    await players.addToArsenal(vkId, item.key, -quantity);
  } else {
    await players.addToAirDefense(vkId, item.key, -quantity);
  }

  const endTime = new Date(Date.now() + durationHours * 60 * 60 * 1000);
  const auction = await auctionsDb.createAuction(
    vkId,
    item.type,
    item.key,
    quantity,
    startPrice,
    minStep,
    endTime
  );

  return { ok: true, auction };
}

async function placeBid(vkId, auctionId, amount, bot) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const auction = await auctionsDb.getAuctionById(auctionId);
  if (!auction || auction.status !== 'active') return { ok: false, reason: 'not_found' };
  if (new Date(auction.end_time) <= new Date()) return { ok: false, reason: 'ended' };
  if (auction.seller_id === vkId) return { ok: false, reason: 'own_lot' };

  const minRequired = auction.current_bid
    ? Number(auction.current_bid) + Number(auction.min_step)
    : Number(auction.start_price);

  if (!Number.isInteger(amount) || amount < minRequired) {
    return { ok: false, reason: 'bid_too_low', minRequired };
  }

  if (Number(player.balance) < amount) {
    return { ok: false, reason: 'not_enough_money', missing: amount - Number(player.balance) };
  }

  // Списываем ставку сразу (эскроу), возвращаем предыдущему ставившему
  await players.updateBalance(vkId, -amount);
  if (auction.current_bidder_id) {
    await players.updateBalance(auction.current_bidder_id, Number(auction.current_bid));
    if (bot) {
      await bot
        .notifyUser(auction.current_bidder_id, `🔔 Вашу ставку на лот №${auction.id} перебили. Вирты возвращены.`)
        .catch(() => {});
    }
  }

  let newEndTime = auction.end_time;
  const msLeft = new Date(auction.end_time).getTime() - Date.now();
  if (msLeft < C.AUCTION_EXTEND_WINDOW_MS) {
    newEndTime = new Date(Date.now() + C.AUCTION_EXTEND_BY_MS);
  }

  const updated = await auctionsDb.placeBid(auctionId, vkId, amount, newEndTime);
  return { ok: true, auction: updated, extended: newEndTime !== auction.end_time };
}

async function cancelLot(vkId, auctionId) {
  const auction = await auctionsDb.getAuctionById(auctionId);
  if (!auction || auction.status !== 'active') return { ok: false, reason: 'not_found' };
  if (auction.seller_id !== vkId) return { ok: false, reason: 'not_owner' };
  if (auction.current_bidder_id) return { ok: false, reason: 'has_bids' };

  await auctionsDb.setStatus(auctionId, 'cancelled');

  if (auction.item_type === 'weapon') {
    await players.addToArsenal(vkId, auction.item_name, auction.quantity);
  } else {
    await players.addToAirDefense(vkId, auction.item_name, auction.quantity);
  }

  return { ok: true, auction };
}

// Обработка истёкших лотов: вызывается по расписанию
async function resolveExpiredAuctions(bot) {
  const due = await auctionsDb.getDueAuctions();
  for (const auction of due) {
    if (auction.current_bidder_id) {
      const commission = Math.round(Number(auction.current_bid) * C.AUCTION_COMMISSION_RATE);
      const payout = Number(auction.current_bid) - commission;
      await players.updateBalance(auction.seller_id, payout);

      if (auction.item_type === 'weapon') {
        await players.addToArsenal(auction.current_bidder_id, auction.item_name, auction.quantity);
      } else {
        await players.addToAirDefense(auction.current_bidder_id, auction.item_name, auction.quantity);
      }

      if (bot) {
        await bot
          .notifyUser(
            auction.seller_id,
            `🛎️ Ваш лот «${auction.item_name} x${auction.quantity}» продан за ${auction.current_bid} вирт (комиссия ${commission}). Зачислено: ${payout} вирт.`
          )
          .catch(() => {});
        await bot
          .notifyUser(
            auction.current_bidder_id,
            `🎉 Вы выиграли аукцион! «${auction.item_name} x${auction.quantity}» зачислено в арсенал.`
          )
          .catch(() => {});
      }
    } else {
      // Никто не поставил ставку — лот возвращается продавцу
      if (auction.item_type === 'weapon') {
        await players.addToArsenal(auction.seller_id, auction.item_name, auction.quantity);
      } else {
        await players.addToAirDefense(auction.seller_id, auction.item_name, auction.quantity);
      }

      if (bot) {
        await bot
          .notifyUser(
            auction.seller_id,
            `📦 Аукцион «${auction.item_name} x${auction.quantity}» завершился без ставок. Товар возвращён вам.`
          )
          .catch(() => {});
      }
    }
    await auctionsDb.setStatus(auction.id, 'completed');
  }
  return due;
}

module.exports = { createLot, placeBid, cancelLot, resolveExpiredAuctions, findItem };
