'use strict';

const Jimp = require('jimp');
const C = require('./constants');

const BOX_W = 220;
const BOX_H = 160;
const GAP = 30;
const MARGIN_SIDE = 30;
const MARGIN_TOP = 90;
const MARGIN_BOTTOM = 30;
const BORDER = 4;
const ICON_SIZE = 16;
const ICON_PADDING = 14; // отступ от края коробки, чтобы иконки не вылезали за рамку

const BG_COLOR = 0x14181fff;
const BOX_COLOR = 0x232a36ff;
const BORDER_COLOR = 0x4fc3f7ff;
const ICON_COLOR = 0xffa726ff;
const ICON_BORDER_COLOR = 0x7a4a00ff;

let fontTitleCache = null;
let fontLabelCache = null;

async function getFonts() {
  if (!fontTitleCache) fontTitleCache = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
  if (!fontLabelCache) fontLabelCache = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
  return { fontTitle: fontTitleCache, fontLabel: fontLabelCache };
}

async function buildFactoryIcon() {
  const icon = await new Jimp(ICON_SIZE, ICON_SIZE, ICON_COLOR);
  for (let x = 0; x < ICON_SIZE; x++) {
    for (let y = 0; y < ICON_SIZE; y++) {
      if (x === 0 || y === 0 || x === ICON_SIZE - 1 || y === ICON_SIZE - 1) {
        icon.setPixelColor(ICON_BORDER_COLOR, x, y);
      }
    }
  }
  return icon;
}

// Рисует незалитый прямоугольник (рамку) заданной толщины поверх image в позиции x,y
async function drawBoxFrame(image, x, y, w, h) {
  const top = await new Jimp(w, BORDER, BORDER_COLOR);
  const bottom = await new Jimp(w, BORDER, BORDER_COLOR);
  const left = await new Jimp(BORDER, h, BORDER_COLOR);
  const right = await new Jimp(BORDER, h, BORDER_COLOR);
  image.composite(top, x, y);
  image.composite(bottom, x, y + h - BORDER);
  image.composite(left, x, y);
  image.composite(right, x + w - BORDER, y);
}

// session: { round, boxes: [{count, icons:[{x,y}]}], correctIndex }
async function renderRound(session) {
  const boxCount = session.boxes.length;
  const width = MARGIN_SIDE * 2 + boxCount * BOX_W + (boxCount - 1) * GAP;
  const height = MARGIN_TOP + BOX_H + MARGIN_BOTTOM;

  const image = await new Jimp(width, height, BG_COLOR);
  const { fontTitle, fontLabel } = await getFonts();
  const factoryIcon = await buildFactoryIcon();

  image.print(
    fontTitle,
    0,
    15,
    {
      text: `РАБОТА \u2014 раунд ${session.round}/${C.WORK_ROUNDS}`,
      alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER,
      alignmentY: Jimp.VERTICAL_ALIGN_MIDDLE,
    },
    width,
    40
  );

  for (let i = 0; i < boxCount; i++) {
    const box = session.boxes[i];
    const boxX = MARGIN_SIDE + i * (BOX_W + GAP);
    const boxY = MARGIN_TOP;

    const fill = await new Jimp(BOX_W, BOX_H, BOX_COLOR);
    image.composite(fill, boxX, boxY);
    await drawBoxFrame(image, boxX, boxY, BOX_W, BOX_H);

    image.print(
      fontLabel,
      boxX,
      boxY - 55,
      {
        text: `${i + 1}`,
        alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER,
        alignmentY: Jimp.VERTICAL_ALIGN_MIDDLE,
      },
      BOX_W,
      40
    );

    const usableW = BOX_W - ICON_PADDING * 2 - ICON_SIZE;
    const usableH = BOX_H - ICON_PADDING * 2 - ICON_SIZE;

    for (const icon of box.icons) {
      const ix = boxX + ICON_PADDING + Math.round(icon.x * usableW);
      const iy = boxY + ICON_PADDING + Math.round(icon.y * usableH);
      image.composite(factoryIcon, ix, iy);
    }
  }

  return image.getBufferAsync(Jimp.MIME_PNG);
}

module.exports = { renderRound };
