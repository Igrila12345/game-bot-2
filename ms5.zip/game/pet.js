'use strict';

const C = require('./constants');
const players = require('../db/players');

function upgradeCost(currentLevel) {
  // Цена прокачки С currentLevel НА currentLevel+1
  return Math.round(C.PET_UPGRADE_BASE_COST * Math.pow(C.PET_UPGRADE_GROWTH, currentLevel - 1));
}

function incomePerHour(level) {
  return level * C.PET_INCOME_PER_LEVEL_PER_HOUR;
}

async function upgradePet(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const level = player.pet_level || 1;
  if (level >= C.PET_MAX_LEVEL) {
    return { ok: false, reason: 'max_level' };
  }

  const cost = upgradeCost(level);
  if (Number(player.balance) < cost) {
    return { ok: false, reason: 'not_enough_money', cost, missing: cost - Number(player.balance) };
  }

  await players.updateBalance(vkId, -cost);
  await players.setPetLevel(vkId, level + 1);

  return { ok: true, cost, newLevel: level + 1 };
}

async function startMining(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  if (player.pet_mining_started_at) {
    return { ok: false, reason: 'already_mining' };
  }

  await players.setPetMiningStarted(vkId, new Date());
  return { ok: true, incomePerHour: incomePerHour(player.pet_level || 1) };
}

function calcEarned(player) {
  if (!player.pet_mining_started_at) return 0;
  const startedMs = new Date(player.pet_mining_started_at).getTime();
  const elapsedHours = Math.min(
    (Date.now() - startedMs) / (60 * 60 * 1000),
    C.PET_MAX_ACCUMULATION_HOURS
  );
  return Math.floor(elapsedHours * incomePerHour(player.pet_level || 1));
}

async function collectMining(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  if (!player.pet_mining_started_at) {
    return { ok: false, reason: 'not_mining' };
  }

  const earned = calcEarned(player);
  if (earned > 0) {
    await players.updateBalance(vkId, earned);
  }
  await players.setPetMiningStarted(vkId, null);
  await players.setPetLastCollected(vkId, new Date());

  return { ok: true, earned };
}

module.exports = { upgradeCost, incomePerHour, upgradePet, startMining, collectMining, calcEarned };
