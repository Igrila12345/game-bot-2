'use strict';

const C = require('../game/constants');
const msg = require('../utils/messages');

async function handleDonate(ctx) {
  const adminLinks = C.ADMIN_IDS.map((id) => msg.mentionLink(id, 'администратору')).join(', ');

  const text =
    `💎 ДОНАТ — ПРАЙС-ЛИСТ\n\n` +
    `👑 VIP — ${C.DONATE_VIP_PRICE_RUB_MONTH} ₽ / месяц\n` +
    `   +${Math.round(C.VIP_INCOME_BONUS * 100)}% к доходу, кулдауны робота короче на ${Math.round(
      (1 - C.VIP_ROBOT_COOLDOWN_MULT) * 100
    )}%, +${C.VIP_BUILD_LIMIT_BONUS} построек завода в час.\n\n` +
    `⛏️ Майнер — ${C.DONATE_MINER_PRICE_RUB_MONTH} ₽ / месяц\n` +
    `   Пассивно приносит ${C.MINER_HOURLY_VIRTS_MIN}-${C.MINER_HOURLY_VIRTS_MAX} вирт каждый час + шанс ${Math.round(
      C.MINER_TOKEN_CHANCE_PER_HOUR * 100
    )}% получить жетон, без действий с вашей стороны.\n\n` +
    `🤖 Суперробот — ${C.DONATE_SUPER_ROBOT_PRICE_RUB} ₽, НАВСЕГДА (разовая покупка, не подписка)\n` +
    `   Открывает суперробота (сразу 1 уровень). Дальше уровни качаются как обычно — ВИРТАМИ ` +
    `(команда «суперробот прокачать»), цена растёт очень быстро — качать тяжело.\n\n` +
    `💳 Как оплатить: напишите ${adminLinks}, укажите, что хотите приобрести — статус будет выдан сразу после получения оплаты.`;

  await ctx.send(text);
}

module.exports = { handleDonate };
