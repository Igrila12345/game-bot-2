'use strict';

// ===================== ОБЩИЕ ПАРАМЕТРЫ =====================

const FACTORY_BASE_PRICE = 100;
const FACTORY_PRICE_GROWTH = 1.03; // +3% за каждый следующий завод
const FACTORY_MAX_COUNT = 100;
const FACTORY_INCOME_PER_HOUR = 8;
const GOLD_MINE_CHANCE = 0.05; // 5% шанс золотой жилы при постройке
const GOLD_MINE_MULTIPLIER = 2;

const START_BALANCE = 100;
const RENAME_COST = 200;
const RECON_COST = 50; // разведка
const EARLY_UNBLOCK_COST_PER_HOUR = 50;

const MAP_MIN = 0;
const MAP_MAX = 1000;

const RADIATION_INCOME_PENALTY = 0.2; // -20%
const RADIATION_DURATION_MS = 2 * 60 * 60 * 1000;

// Защита новичков: нельзя атаковать (и, соответственно, сносить заводы) игрока,
// у которого заводов меньше этого значения.
const MIN_FACTORIES_TO_BE_ATTACKED = 3;
const NEWBIE_PROTECTION_FACTORIES = MIN_FACTORIES_TO_BE_ATTACKED;
const ATTACK_COOLDOWN_MS = 60 * 60 * 1000; // 1 час на цель
const INACTIVITY_ATTACK_BAN_DAYS = 7;

// Кулдаун между любыми командами одного игрока боту
const COMMAND_COOLDOWN_MS = 2 * 1000;

// Лимит на постройку заводов
const FACTORY_BUILD_LIMIT_PER_HOUR = 10;

// Ежедневный бонус для каждого игрока (не путать с наградами топ-3)
const DAILY_BONUS_AMOUNT = 50;
const DAILY_BONUS_COOLDOWN_MS = 24 * 60 * 60 * 1000;

// Перевод вирт другому игроку
const TRANSFER_COOLDOWN_MS = 2 * 60 * 60 * 1000; // 1 раз в 2 часа одному и тому же игроку
const TRANSFER_MIN_AMOUNT = 10;

// ===================== НАЛОГИ =====================

const WEALTH_TAX_THRESHOLD = 10000;
const WEALTH_TAX_RATE = 0.05; // 5% от суммы сверх 10000, раз в час

const TOP_TAX = [
  { place: 1, rate: 0.10, threshold: 5000 },
  { place: 2, rate: 0.07, threshold: 5000 },
  { place: 3, rate: 0.05, threshold: 5000 },
];

// ===================== ОРУЖИЕ =====================
// category: 'drone' | 'missile' | 'nuke' | 'saboteur'
// effect: 'block_random' | 'block_all' | 'destroy_factory' | 'wipe_air_defense'
// ПРИМЕЧАНИЕ: поле counterChance больше не используется при расчёте перехвата
// (раньше был баг: реальный шанс сбития всегда брался из этого поля, а не из ПВО).
// Итоговый шанс перехвата теперь считается только из ПВО защитника (см. game/combat.js).
// Поле оставлено для обратной совместимости/справки, на бой не влияет.

const WEAPONS = {
  'Герань-2': {
    key: 'Герань-2',
    category: 'drone',
    blockHours: 1,
    speedKmh: 250,
    price: 120,
    counterChance: 0.60, // шанс что ПВО собьёт
    maxPerAttack: 10,
    effect: 'block_random',
    blockCount: 1,
    hitsToDestroy: 3, // попаданий, чтобы снести 1 завод
    productionCost: 60,
    productionMinutes: 30,
  },
  'Орион': {
    key: 'Орион',
    category: 'drone',
    blockHours: 1.5,
    speedKmh: 350,
    price: 250,
    counterChance: 0.50,
    maxPerAttack: 5,
    effect: 'block_random',
    blockCount: 1,
    hitsToDestroy: 2,
    productionCost: 130,
    productionMinutes: 60,
  },
  'Молния': {
    key: 'Молния',
    category: 'drone',
    blockHours: 2,
    speedKmh: 700,
    price: 450,
    counterChance: 0.30,
    maxPerAttack: 3,
    effect: 'block_random',
    blockCount: 1,
    hitsToDestroy: 1,
    productionCost: 250,
    productionMinutes: 120,
  },
  'Точка-У': {
    key: 'Точка-У',
    category: 'missile',
    blockHours: 1,
    speedKmh: 400,
    price: 150,
    counterChance: 0.55,
    maxPerAttack: 8,
    effect: 'block_random',
    blockCount: 1,
    hitsToDestroy: 3,
    productionCost: 80,
    productionMinutes: 45,
  },
  'Калибр': {
    key: 'Калибр',
    category: 'missile',
    blockHours: 2,
    speedKmh: 600,
    price: 400,
    counterChance: 0.35,
    maxPerAttack: 3,
    effect: 'block_random',
    blockCount: 1,
    hitsToDestroy: 2,
    productionCost: 220,
    productionMinutes: 120,
  },
  'Искандер-М': {
    key: 'Искандер-М',
    category: 'missile',
    blockHours: 3,
    speedKmh: 800,
    price: 700,
    counterChance: 0.10,
    maxPerAttack: 2,
    effect: 'block_random',
    blockCount: 1,
    hitsToDestroy: 1,
    productionCost: 400,
    productionMinutes: 240,
  },
  'Тополь-М': {
    key: 'Тополь-М',
    category: 'nuke',
    blockHours: 1,
    speedKmh: 1200,
    price: 2500,
    counterChance: 0.15,
    maxPerAttack: 1,
    effect: 'block_all_radiation',
    productionCost: 1500,
    productionMinutes: 720,
  },
  'Сармат': {
    key: 'Сармат',
    category: 'nuke',
    blockHours: 2, // блокировка доп. завода
    speedKmh: 1200,
    price: 3500,
    counterChance: 0.05,
    maxPerAttack: 1,
    effect: 'destroy_and_block',
    productionCost: 2200,
    productionMinutes: 1080,
  },
  'Посейдон': {
    key: 'Посейдон',
    category: 'nuke',
    blockHours: 2,
    speedKmh: 1200,
    price: 2800,
    counterChance: 0.20,
    maxPerAttack: 1,
    effect: 'wipe_air_defense',
    blockCount: 2,
    productionCost: 1800,
    productionMinutes: 840,
  },
  'Группа захвата': {
    key: 'Группа захвата',
    category: 'saboteur',
    blockHours: 2,
    speedKmh: null, // диверсанты — используем условную скорость наравне с ракетами среднего типа
    price: 60,
    counterChance: 0.40,
    maxPerAttack: 3,
    effect: 'block_random',
    blockCount: 1,
    hitsToDestroy: 3,
    productionCost: 30,
    productionMinutes: 60,
  },
};

// Общий "знаменатель" системы ХП заводов: наименьшее общее кратное всех hitsToDestroy (1,2,3 -> 6).
// Один удар оружием даёт floor(FACTORY_HP_UNIT / hitsToDestroy) единиц урона; когда накоплено
// FACTORY_HP_UNIT единиц — сносится 1 завод противника (сверх защиты новичков).
const FACTORY_HP_UNIT = 6;

// ===================== СКИЛЛЫ (пассивные бонусы за количество заводов) =====================
// Бонусы не суммируются — применяется бонус самого высокого достигнутого порога.
// damageBonus: множитель урона по вражеским заводам (система ХП/снос заводов).
// airDefenseBonus: прибавка к шансу перехвата ПВО (в долях, например 0.05 = +5 п.п.).

const SKILL_TIERS = [
  { factories: 50, damageBonus: 0.15, airDefenseBonus: 0.05, name: 'Опытный полководец' },
  { factories: 150, damageBonus: 0.35, airDefenseBonus: 0.10, name: 'Генералиссимус' },
];

// ===================== АДМИНИСТРАТОРЫ =====================

const ADMIN_IDS = [660964860];

// ===================== ПИТОМЕЦ-РОБОТ =====================

const PET_MAX_LEVEL = 50;
const PET_INCOME_PER_LEVEL_PER_HOUR = 4; // вирт/час за каждый уровень питомца
const PET_UPGRADE_BASE_COST = 100; // цена прокачки с 1 на 2 уровень
const PET_UPGRADE_GROWTH = 1.15; // рост цены прокачки за уровень
const PET_MAX_ACCUMULATION_HOURS = 24; // доход не копится дольше этого времени — нужно вовремя забирать

// Диверсантам нужна скорость для расчёта времени полёта - примем среднюю по земле
WEAPONS['Группа захвата'].speedKmh = 300;

const NUKE_KEYS = Object.keys(WEAPONS).filter((k) => WEAPONS[k].category === 'nuke');

// ===================== ПВО =====================
// covers: 'drone' | 'missile' | 'all' (диверсанты также перехватываются, если covers === 'all' или 'saboteur' входит)

const AIR_DEFENSE = {
  'Панцирь-С1': {
    key: 'Панцирь-С1',
    covers: ['drone'],
    chance: 0.60,
    price: 100,
  },
  'Бук-М3': {
    key: 'Бук-М3',
    covers: ['drone', 'missile'],
    chance: 0.70,
    price: 220,
  },
  'С-400 Триумф': {
    key: 'С-400 Триумф',
    covers: ['drone', 'missile', 'nuke', 'saboteur'],
    chance: 0.90,
    price: 500,
  },
};

// ===================== МАГАЗИН =====================

const SHOP_REFRESH_MINUTES = 5;
const SHOP_WEAPON_TYPES_MIN = 2;
const SHOP_WEAPON_TYPES_MAX = 3;
const SHOP_AD_TYPES_MIN = 1;
const SHOP_AD_TYPES_MAX = 2;
const SHOP_NUKE_CHANCE = 0.05;
const SHOP_ITEM_QTY_MIN = 1;
const SHOP_ITEM_QTY_MAX = 3;
const SHOP_LOCKOUT_AFTER_NUKE_MIN = 30;

const NON_NUKE_WEAPON_KEYS = Object.keys(WEAPONS).filter((k) => WEAPONS[k].category !== 'nuke');

// ===================== ПРОИЗВОДСТВО =====================

const MASS_PRODUCTION_FACTORY_THRESHOLD = 10;
const MASS_PRODUCTION_TIME_BONUS = 0.20; // -20% доп. времени

// ===================== КЛАНЫ =====================

// Создание клана бесплатно
const CLAN_CREATE_COST = 0;
const CLAN_NAME_MIN = 2;
const CLAN_NAME_MAX = 20;
const CLAN_TAX_RATE = 0.10; // 10% от дохода каждого участника в сейф
const CLAN_VAULT_PER_FACTORY = 100;

// Уровень сейфа: копится от ВСЕХ поступлений в сейф за всё время (налог + ручные пополнения),
// не уменьшается при трате/снятии. Level = floor(всего_собрано / CLAN_VAULT_LEVEL_STEP), максимум 100.
// Например: собрали 10 000 вирт всего — уровень 1, собрали 20 000 — уровень 2, и т.д. до 1 000 000 (ур. 100).
const CLAN_VAULT_LEVEL_STEP = 10000;
const CLAN_VAULT_MAX_LEVEL = 100;
// Каждый уровень сейфа увеличивает его максимальную вместимость на 1% (до +100% на 100 уровне)
const CLAN_VAULT_LEVEL_CAPACITY_BONUS = 0.01;

const CLAN_BONUSES = {
  'форсаж': {
    key: 'форсаж',
    name: 'Форсаж',
    description: 'Скорость полёта оружия x2 на 1 час',
    costRateOfMaxVault: 0.5,
    cooldownHours: 6,
    durationHours: 1,
  },
  'эшелон': {
    key: 'эшелон',
    name: 'Эшелон',
    description: 'ПВО работает на 20% точнее на 1 час',
    costRateOfMaxVault: 0.4,
    cooldownHours: 4,
    durationHours: 1,
  },
  'индустриализация': {
    key: 'индустриализация',
    name: 'Индустриализация',
    description: '+20% дохода всем на 1 час',
    costRateOfMaxVault: 0.3,
    cooldownHours: 3,
    durationHours: 1,
  },
};

// ===================== АТАКА / ТРОФЕИ =====================

const LOOT_RATE = 0.15; // 15% от дохода жертвы за 1 час
const LOOT_MIN = 30;
const LOOT_MAX = 250;

// ===================== РЕЙТИНГИ / НАГРАДЫ =====================

const DAILY_FACTORY_REWARDS = [
  { place: 1, virts: 300, weapon: 'Калибр', qty: 1 },
  { place: 2, virts: 200, weapon: 'Герань-2', qty: 1 },
  { place: 3, virts: 100, weapon: 'Герань-2', qty: 1 },
];

const DAILY_CLAN_REWARDS = [
  { place: 1, virts: 500 },
  { place: 2, virts: 300 },
  { place: 3, virts: 100 },
];

// ===================== РАБОТА И ЖЕТОНЫ =====================

// Работа теперь мгновенная: игрок проходит мини-игру (10 раундов "найди коробку
// с заводами повыше плотностью") и сразу получает жетоны, без часового ожидания.
const WORK_TOKENS_MIN = 5;
const WORK_TOKENS_MAX = 10;
const WORK_MAX_PER_DAY = 40;
const WORK_COOLDOWN_MS = 60 * 1000; // 1 минута между попытками работы

// ---- Мини-игра "работа": N раундов, в каждом нужно выбрать коробку с самой
// высокой плотностью заводов (коробки одинакового размера, но разного заполнения,
// и каждый раунд перемешиваются заново, так что нельзя жать одну и ту же кнопку).
const WORK_ROUNDS = 10;
const WORK_BOX_COUNT = 3; // сколько коробок показывается за раунд
const WORK_BOX_MIN_ICONS = 4;
const WORK_BOX_MAX_ICONS = 16;
const WORK_ROUND_TIMEOUT_MS = 25 * 1000; // если раунд не отвечен вовремя — попытка сгорает

// ===================== СКЛАД (КЕЙСЫ ЗА ЖЕТОНЫ) =====================

const WAREHOUSE_COST_TOKENS = 100;
const WAREHOUSE_BOX_COUNT = 5; // чисто визуально — какую бы коробку ни выбрал, шансы одинаковые

// Прямой обмен жетонов на завод (без рандома)
const EXCHANGE_FACTORY_COST_TOKENS = 50;

// Сумма шансов = 100. Пустых коробок нет. Кейс даёт только заводы, вооружение и вирты.
const WAREHOUSE_REWARDS = [
  { type: 'virts', chance: 30, min: 150, max: 300 },
  { type: 'weapon', key: 'Герань-2', chance: 18, min: 2, max: 3 },
  { type: 'weapon', key: 'Калибр', chance: 14, min: 1, max: 1 },
  { type: 'weapon', key: 'Орион', chance: 12, min: 1, max: 2 },
  { type: 'weapon', key: 'Искандер-М', chance: 9, min: 1, max: 1 },
  { type: 'air_defense', key: 'С-400 Триумф', chance: 8, min: 1, max: 1 },
  { type: 'factory', chance: 6, min: 1, max: 1 },
  { type: 'weapon', key: 'Сармат', chance: 3, min: 1, max: 1 },
];

// ===================== РЕФЕРАЛЬНАЯ ПРОГРАММА =====================

const REFERRAL_INVITER_REWARD = 100; // получает тот, кто пригласил
const REFERRAL_INVITED_REWARD = 50; // получает тот, кто перешёл по ссылке

// ===================== НАУЧНЫЕ ЦЕНТРЫ =====================

const SCIENCE_BUILD_FACTORY_COST = 10; // обычных заводов списывается за 1 центр
const SCIENCE_BUILD_VIRT_COST = 500;
const SCIENCE_INCOME_PER_HOUR = 24; // вирт/час за центр (в 3 раза больше обычного завода)

// level: текущий уровень, limit: сколько центров разрешено, cost: цена перехода НА этот уровень (0 для базового)
const SCIENCE_LIMIT_LEVELS = [
  { level: 1, limit: 5, cost: 0 },
  { level: 2, limit: 10, cost: 2000 },
  { level: 3, limit: 20, cost: 5000 },
  { level: 4, limit: 35, cost: 10000 },
  { level: 5, limit: 55, cost: 20000 },
  { level: 6, limit: 80, cost: 35000 },
  { level: 7, limit: 110, cost: 55000 },
  { level: 8, limit: 150, cost: 80000 },
  { level: 9, limit: 200, cost: 110000 },
  { level: 10, limit: 300, cost: 150000 },
];

// ===================== РАСШИРЕНИЕ ЛИМИТА ЗАВОДОВ =====================

const FACTORY_LIMIT_LEVELS = [
  { level: 0, limit: 100, cost: 0 },
  { level: 1, limit: 150, cost: 1000 },
  { level: 2, limit: 200, cost: 2000 },
  { level: 3, limit: 300, cost: 4000 },
  { level: 4, limit: 400, cost: 8000 },
  { level: 5, limit: 500, cost: 15000 },
  { level: 6, limit: 600, cost: 30000 },
  { level: 7, limit: 700, cost: 50000 },
  { level: 8, limit: 800, cost: 80000 },
  { level: 9, limit: 900, cost: 120000 },
  { level: 10, limit: 1000, cost: 200000 },
];

// ===================== АУКЦИОН =====================

const AUCTION_COMMISSION_RATE = 0.05; // 5% с продавца от финальной цены
const AUCTION_EXTEND_WINDOW_MS = 60 * 1000; // если ставка за 1 минуту до конца — продлеваем
const AUCTION_EXTEND_BY_MS = 5 * 60 * 1000; // продление на 5 минут
const AUCTION_MAX_DURATION_HOURS = 48;

module.exports = {
  FACTORY_BASE_PRICE,
  FACTORY_PRICE_GROWTH,
  FACTORY_MAX_COUNT,
  FACTORY_INCOME_PER_HOUR,
  GOLD_MINE_CHANCE,
  GOLD_MINE_MULTIPLIER,
  START_BALANCE,
  RENAME_COST,
  RECON_COST,


  EARLY_UNBLOCK_COST_PER_HOUR,
  MAP_MIN,
  MAP_MAX,
  RADIATION_INCOME_PENALTY,
  RADIATION_DURATION_MS,
  MIN_FACTORIES_TO_BE_ATTACKED,
  NEWBIE_PROTECTION_FACTORIES,
  ATTACK_COOLDOWN_MS,
  INACTIVITY_ATTACK_BAN_DAYS,
  COMMAND_COOLDOWN_MS,
  FACTORY_BUILD_LIMIT_PER_HOUR,
  DAILY_BONUS_AMOUNT,
  DAILY_BONUS_COOLDOWN_MS,
  TRANSFER_COOLDOWN_MS,
  TRANSFER_MIN_AMOUNT,
  FACTORY_HP_UNIT,
  SKILL_TIERS,
  ADMIN_IDS,
  PET_MAX_LEVEL,
  PET_INCOME_PER_LEVEL_PER_HOUR,
  PET_UPGRADE_BASE_COST,
  PET_UPGRADE_GROWTH,
  PET_MAX_ACCUMULATION_HOURS,
  WEALTH_TAX_THRESHOLD,
  WEALTH_TAX_RATE,
  TOP_TAX,
  WEAPONS,
  NUKE_KEYS,
  AIR_DEFENSE,
  SHOP_REFRESH_MINUTES,
  SHOP_WEAPON_TYPES_MIN,
  SHOP_WEAPON_TYPES_MAX,
  SHOP_AD_TYPES_MIN,
  SHOP_AD_TYPES_MAX,
  SHOP_NUKE_CHANCE,
  SHOP_ITEM_QTY_MIN,
  SHOP_ITEM_QTY_MAX,
  SHOP_LOCKOUT_AFTER_NUKE_MIN,
  NON_NUKE_WEAPON_KEYS,
  MASS_PRODUCTION_FACTORY_THRESHOLD,
  MASS_PRODUCTION_TIME_BONUS,
  CLAN_CREATE_COST,
  CLAN_NAME_MIN,
  CLAN_NAME_MAX,
  CLAN_TAX_RATE,
  CLAN_VAULT_PER_FACTORY,
  CLAN_VAULT_LEVEL_STEP,
  CLAN_VAULT_MAX_LEVEL,
  CLAN_VAULT_LEVEL_CAPACITY_BONUS,
  CLAN_BONUSES,
  LOOT_RATE,
  LOOT_MIN,
  LOOT_MAX,
  DAILY_FACTORY_REWARDS,
  DAILY_CLAN_REWARDS,

  // ---- Новые механики ----
  WORK_TOKENS_MIN,
  WORK_TOKENS_MAX,
  WORK_MAX_PER_DAY,
  WORK_COOLDOWN_MS,
  WORK_ROUNDS,
  WORK_BOX_COUNT,
  WORK_BOX_MIN_ICONS,
  WORK_BOX_MAX_ICONS,
  WORK_ROUND_TIMEOUT_MS,

  WAREHOUSE_COST_TOKENS,
  WAREHOUSE_BOX_COUNT,
  WAREHOUSE_REWARDS,
  EXCHANGE_FACTORY_COST_TOKENS,

  REFERRAL_INVITER_REWARD,
  REFERRAL_INVITED_REWARD,

  SCIENCE_BUILD_FACTORY_COST,
  SCIENCE_BUILD_VIRT_COST,
  SCIENCE_INCOME_PER_HOUR,
  SCIENCE_LIMIT_LEVELS,

  FACTORY_LIMIT_LEVELS,

  AUCTION_COMMISSION_RATE,
  AUCTION_EXTEND_WINDOW_MS,
  AUCTION_EXTEND_BY_MS,
  AUCTION_MAX_DURATION_HOURS,
};
