'use strict';

const combat = require('./combat');
const combatDb = require('../db/combat');
const calc = require('./calc');
const C = require('./constants');
const msg = require('../utils/messages');

async function resolvePendingAttacks(bot) {
  const due = await combatDb.getDueAttacks();

  for (const attackRecord of due) {
    await combatDb.markAttackResolved(attackRecord.id);

    const result = await combat.resolveAttack(attackRecord);
    if (!result.ok) continue;

    const { attacker, defender, weapon, intercepted } = result;
    const qty = attackRecord.quantity;
    const attackerLink = msg.mentionLink(attacker.vk_id, attacker.state_name);
    const defenderLink = msg.mentionLink(defender.vk_id, defender.state_name);

    if (intercepted) {
      await bot
        .notifyUser(
          attacker.vk_id,
          `💥 Ваше ${weapon.key} (x${qty}) сбито ПВО «${result.adUsed}» противника (${defenderLink}). Потери: ${qty} шт.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `🎯 Ваше ПВО «${result.adUsed}» сбило вражеское ${weapon.key} (${qty} шт.), запущенное «${attackerLink}»!`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `🛡️ «${defenderLink}» отразил атаку с помощью ПВО «${result.adUsed}»`
          )
          .catch(() => {});
      }
      continue;
    }

    const { effectResult, loot } = result;

    if (effectResult.type === 'block') {
      const destroyedLine = effectResult.destroyedCount
        ? `\n💀 Снесено навсегда: ${effectResult.destroyedCount} завод(ов)!`
        : '';

      await bot
        .notifyUser(
          attacker.vk_id,
          `🔥 ПРЯМОЕ ПОПАДАНИЕ по городу «${defenderLink}»!${destroyedLine} Трофеи: +${loot} вирт.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `💥 Государство «${attackerLink}» прорвало вашу оборону!${destroyedLine}`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `💥 «${attackerLink}» нанёс удар по «${defenderLink}»${
              effectResult.destroyedCount ? `, снесено ${effectResult.destroyedCount}` : ''
            }`
          )
          .catch(() => {});
      }
    } else if (effectResult.type === 'block_all_radiation') {
      await bot
        .notifyUser(
          attacker.vk_id,
          `☢️ Радиационное заражение! Все заводы «${defenderLink}» получают -20% дохода на 2 часа.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `☢️ Государство «${attackerLink}» нанесло радиационный удар! Доход снижен на 20% на 2 часа.`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `☢️ «${attackerLink}» нанёс ядерный удар по «${defenderLink}»: радиация`
          )
          .catch(() => {});
      }
    } else if (effectResult.type === 'destroy_and_block') {
      await bot
        .notifyUser(
          attacker.vk_id,
          `☢️ ЯДЕРНЫЙ УДАР! Завод города «${defenderLink}» уничтожен навсегда! Трофеи: +${loot} вирт.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `☢️ ВАШ ЗАВОД УНИЧТОЖЕН государством «${attackerLink}»! Один завод стёрт с лица земли безвозвратно.`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `☢️ «${attackerLink}» уничтожил завод «${defenderLink}» ядерным ударом!`
          )
          .catch(() => {});
      }
    } else if (effectResult.type === 'wipe_air_defense') {
      await bot
        .notifyUser(
          attacker.vk_id,
          `🌊 ЦУНАМИ! Всё ПВО «${defenderLink}» сметено! Трофеи: +${loot} вирт.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `🌊 Государство «${attackerLink}» смыло всё ваше ПВО ударом Посейдона!`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `🌊 «${attackerLink}» смыл ПВО «${defenderLink}» ударом Посейдона!`
          )
          .catch(() => {});
      }
    }
  }
}

module.exports = { resolvePendingAttacks };
