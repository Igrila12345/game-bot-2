'use strict';

const economy = require('../game/economy');
const players = require('../db/players');
const calc = require('../game/calc');
const C = require('../game/constants');

async function handleBuild(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const result = await economy.buildFactory(vkId);

  if (!result.ok) {
    if (result.reason === 'max_reached') {
      await ctx.send(`⛔ У вас уже максимум заводов (${result.max}). Расширьте лимит: лимит расширить`);
    } else if (result.reason === 'build_limit') {
      await ctx.send(`⛔ Лимит постройки заводов: не более ${result.limit} в час. Попробуйте позже.`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Цена завода: ${calc.formatNumber(result.price)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось построить завод.');
    }
    return;
  }

  let text = `🏭 Завод построен за ${calc.formatNumber(result.price)} вирт!`;
  if (result.isGoldMine) {
    text += `\n✨ Вам повезло — это «Золотая жила»! Доход x2 (16 вирт/час).`;
  }
  await ctx.send(text);
}

async function handleUnblock(ctx) {
  // Блокировка заводов как игровая механика отключена — атаки больше не блокируют заводы,
  // поэтому и разблокировать нечего. Команда оставлена как заглушка для старых привычек игроков.
  await ctx.send('ℹ️ Блокировка заводов отключена. Атаки теперь бьют по заводам напрямую, разблокировать нечего.');
}

async function handleDailyBonus(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  const now = Date.now();
  if (player.last_daily_bonus) {
    const elapsed = now - new Date(player.last_daily_bonus).getTime();
    if (elapsed < C.DAILY_BONUS_COOLDOWN_MS) {
      const remaining = C.DAILY_BONUS_COOLDOWN_MS - elapsed;
      await ctx.send(`⛔ Ежедневный бонус уже получен. Следующий через: ${calc.formatDuration(remaining)}.`);
      return;
    }
  }

  await players.updateBalance(vkId, C.DAILY_BONUS_AMOUNT);
  await players.setLastDailyBonus(vkId, new Date());

  await ctx.send(`🎁 Ежедневный бонус получен: +${C.DAILY_BONUS_AMOUNT} вирт! Возвращайтесь через 24 часа.`);
}

async function handleTransfer(ctx, targetId, amountArg) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return;
  }

  if (!targetId) {
    await ctx.send('⛔ Формат: !перевод @юзер [сумма]');
    return;
  }

  if (targetId === vkId) {
    await ctx.send('⛔ Нельзя переводить вирты самому себе.');
    return;
  }

  const amount = parseInt(amountArg, 10);
  if (!Number.isInteger(amount) || amount < C.TRANSFER_MIN_AMOUNT) {
    await ctx.send(`⛔ Минимальная сумма перевода: ${C.TRANSFER_MIN_AMOUNT} вирт.`);
    return;
  }

  const target = await players.getPlayer(targetId);
  if (!target || target.registration_step !== 'done') {
    await ctx.send('⛔ Этот игрок не зарегистрирован.');
    return;
  }

  if (Number(player.balance) < amount) {
    await ctx.send(`⛔ Недостаточно вирт. Не хватает ${calc.formatNumber(amount - Number(player.balance))}.`);
    return;
  }

  const playersDb = require('../db/players');
  const transfersDb = require('../db/transfers');

  const lastTransfer = await transfersDb.getCooldown(vkId, targetId);
  if (lastTransfer) {
    const elapsed = Date.now() - new Date(lastTransfer).getTime();
    if (elapsed < C.TRANSFER_COOLDOWN_MS) {
      await ctx.send(
        `⛔ Этому игроку можно переводить вирты раз в 2 часа. Осталось: ${calc.formatDuration(
          C.TRANSFER_COOLDOWN_MS - elapsed
        )}.`
      );
      return;
    }
  }

  await playersDb.updateBalance(vkId, -amount);
  await playersDb.updateBalance(targetId, amount);
  await transfersDb.setCooldown(vkId, targetId);

  const msg = require('../utils/messages');
  await ctx.send(`✅ Переведено ${calc.formatNumber(amount)} вирт государству «${msg.mentionLink(targetId, target.state_name)}».`);
  if (ctx.bot) {
    await ctx.bot
      .notifyUser(targetId, `💸 «${msg.mentionLink(vkId, player.state_name)}» перевёл(а) вам ${calc.formatNumber(amount)} вирт.`)
      .catch(() => {});
  }
}

module.exports = { handleBuild, handleUnblock, handleDailyBonus, handleTransfer };
