'use strict';

const parse = require('../utils/parse');
const profile = require('./profile');
const economyHandlers = require('./economyHandlers');
const productionHandlers = require('./productionHandlers');
const shopHandlers = require('./shopHandlers');
const combatHandlers = require('./combatHandlers');
const clanHandlers = require('./clanHandlers');
const ratingHandlers = require('./ratingHandlers');
const adminHandlers = require('./adminHandlers');
const petHandlers = require('./petHandlers');
const workHandlers = require('./workHandlers');
const warehouseHandlers = require('./warehouseHandlers');
const scienceHandlers = require('./scienceHandlers');
const limitHandlers = require('./limitHandlers');
const auctionHandlers = require('./auctionHandlers');
const promoHandlers = require('./promoHandlers');
const players = require('../db/players');
const C = require('../game/constants');

// Кулдаун между командами одного игрока (в памяти процесса)
const lastCommandAt = new Map();

function isOnCommandCooldown(vkId) {
  const now = Date.now();
  const last = lastCommandAt.get(vkId);
  if (last && now - last < C.COMMAND_COOLDOWN_MS) {
    return C.COMMAND_COOLDOWN_MS - (now - last);
  }
  lastCommandAt.set(vkId, now);
  return 0;
}

// Разрешаем вызывать команды и без "!" — по алиасам ключевых слов.
// В беседах (не ЛС) это особенно важно: реагируем только на точное совпадение
// первого слова с известной командой, остальной текст беседы игнорируем.
const COMMAND_ALIASES = {
  начать: 'старт',
  начало: 'старт',
  старт: 'старт',
  регистрация: 'старт',
  команды: 'помощь',
  помощь: 'помощь',
  справка: 'помощь',
  правила: 'помощь',
  питомец: 'робот',
  работать: 'работа',
  склады: 'склад',
  баланс: 'профиль',
  инвентарь: 'арсенал',
  атаковать: 'атака',
  переименовка: 'переименовать',
};

const KNOWN_COMMANDS = new Set([
  'старт',
  'профиль',
  'переименовать',
  'построить',
  'бонус',
  'перевод',
  'магазин',
  'купить',
  'арсенал',
  'атака',
  'разведка',
  'произвести',
  'производство',
  'забрать',
  'разблокировать',
  'топ',
  'помощь',
  'гайд',
  'админ',
  'клан',
  'робот',
  'работа',
  'склад',
  'выбрать',
  'наука',
  'лимит',
  'аукцион',
  'продать',
  'ставка',
  'отмена',
  'лоты',
  'промо',
  'обменять',
  'рефералы',
]);

function isPrivateMessage(ctx) {
  // В VK личные сообщения имеют peer_id, равный user_id (< 2e9), беседы >= 2e9
  return ctx.peerId && ctx.peerId < 2000000000;
}

async function resolveMentionToId(text, tokens, index) {
  const token = tokens[index];
  if (!token) return null;
  let id = parse.extractMentionId(token);
  if (id) return id;

  // Возможно, это упоминание с пробелом в имени [id123|Имя Фамилия] — ищем в исходном тексте
  id = parse.findMentionInText(text);
  return id;
}

async function dispatch(ctx) {
  // Клики по инлайн-кнопкам мини-игры "работа" приходят с payload и обрабатываются
  // отдельно от текстовых команд (и без общего кулдауна команд — раунды короткие).
  const payload = ctx.messagePayload;
  if (payload && payload.cmd === 'work_pick') {
    return await workHandlers.handleWorkPick(ctx, payload.box, payload.round);
  }
  if (payload && payload.cmd === 'help_section') {
    return await ratingHandlers.handleHelpSection(ctx, payload.section);
  }

  const text = (ctx.text || '').trim();
  if (!text) return;

  // Ввод названия государства при регистрации перехватываем только в ЛС,
  // чтобы обычные сообщения в беседе не ломали чужую регистрацию.
  if (isPrivateMessage(ctx)) {
    const handledName = await profile.handleNameInput(ctx);
    if (handledName) return;
  }

  const tokens = parse.splitArgs(text);
  let rawCommand = tokens[0].toLowerCase();
  if (rawCommand.startsWith('!')) rawCommand = rawCommand.slice(1);
  const normalized = COMMAND_ALIASES[rawCommand] || rawCommand;

  // И в ЛС, и в беседах реагируем только на точное совпадение с известной командой —
  // так бот не отвечает на посторонние сообщения в общем чате.
  if (!KNOWN_COMMANDS.has(normalized)) return;

  const remainingCooldownMs = isOnCommandCooldown(ctx.senderId);
  if (remainingCooldownMs > 0) {
    await ctx.send(`⏳ Не так быстро! Подождите ${(remainingCooldownMs / 1000).toFixed(1)} сек. между командами.`);
    return;
  }

  const command = '!' + normalized;

  try {
    switch (command) {
      case '!старт':
        return await profile.handleStart(ctx, tokens[1]);

      case '!профиль': {
        const targetId = await resolveMentionToId(text, tokens, 1);
        return await profile.handleProfile(ctx, targetId);
      }

      case '!переименовать': {
        const newName = tokens.slice(1).join(' ');
        return await profile.handleRename(ctx, newName);
      }

      case '!построить':
        return await economyHandlers.handleBuild(ctx);

      case '!бонус':
        return await economyHandlers.handleDailyBonus(ctx);

      case '!перевод': {
        const targetId = await resolveMentionToId(text, tokens, 1);
        const rest = tokens.slice(2);
        const amountArg = rest[rest.length - 1];
        return await economyHandlers.handleTransfer(ctx, targetId, amountArg);
      }

      case '!магазин':
        return await shopHandlers.handleShop(ctx);

      case '!купить': {
        // Название товара может состоять из нескольких слов, количество — последний токен если число
        const rest = tokens.slice(1);
        let quantity = 1;
        let nameTokens = rest;
        const last = rest[rest.length - 1];
        if (last && /^\d+$/.test(last)) {
          quantity = parseInt(last, 10);
          nameTokens = rest.slice(0, -1);
        }
        const itemName = nameTokens.join(' ');
        return await shopHandlers.handleBuy(ctx, itemName, String(quantity));
      }

      case '!арсенал':
        return await shopHandlers.handleArsenal(ctx);

      case '!атака': {
        const targetId = await resolveMentionToId(text, tokens, 1);
        const rest = tokens.slice(2);
        if (rest.length < 2) {
          await ctx.send('⛔ Формат: !атака @юзер [оружие] [количество]');
          return;
        }
        const qty = rest[rest.length - 1];
        const weapon = rest.slice(0, -1).join(' ');
        return await combatHandlers.handleAttack(ctx, targetId, weapon, qty, ctx.peerId);
      }

      case '!разведка': {
        const targetId = await resolveMentionToId(text, tokens, 1);
        return await combatHandlers.handleRecon(ctx, targetId);
      }

      case '!произвести': {
        const rest = tokens.slice(1);
        // формат: [оружие...] [количество] [заводов]
        if (rest.length < 3) {
          await ctx.send('⛔ Формат: !произвести [оружие] [количество] [заводов]');
          return;
        }
        const factoriesArg = rest[rest.length - 1];
        const qtyArg = rest[rest.length - 2];
        const weaponArg = rest.slice(0, -2).join(' ');
        return await productionHandlers.handleProduce(ctx, weaponArg, qtyArg, factoriesArg);
      }

      case '!производство':
        return await productionHandlers.handleProductionStatus(ctx);

      case '!забрать': {
        const rest = tokens.slice(1);
        if (rest.length < 2) {
          await ctx.send('⛔ Формат: !забрать [оружие] [количество]');
          return;
        }
        const qtyArg = rest[rest.length - 1];
        const weaponArg = rest.slice(0, -1).join(' ');
        return await productionHandlers.handleCollect(ctx, weaponArg, qtyArg);
      }

      case '!разблокировать': {
        return await economyHandlers.handleUnblock(ctx, tokens[1]);
      }

      case '!топ': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'заводы') return await ratingHandlers.handleTopFactories(ctx);
        if (sub === 'вирты') return await ratingHandlers.handleTopBalance(ctx);
        if (sub === 'кланы') return await ratingHandlers.handleTopClans(ctx);
        await ctx.send('⛔ Формат: !топ заводы / !топ вирты / !топ кланы');
        return;
      }

      case '!помощь':
        return await ratingHandlers.handleHelp(ctx);

      case '!гайд':
        return await ratingHandlers.handleHelpSection(ctx, 'guide');

      case '!робот': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'прокачать') return await petHandlers.handleUpgrade(ctx);
        if (sub === 'старт') return await petHandlers.handleStart(ctx);
        if (sub === 'забрать') return await petHandlers.handleCollect(ctx);
        return await petHandlers.handleStatus(ctx);
      }

      case '!админ': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'помощь' || sub === 'рассылка') {
          const rest = tokens.slice(2);
          return await adminHandlers.handleAdmin(ctx, sub, null, rest);
        }
        const targetId = await resolveMentionToId(text, tokens, 2);
        const rest = tokens.slice(3);
        return await adminHandlers.handleAdmin(ctx, sub, targetId, rest);
      }

      case '!клан': {
        const sub = (tokens[1] || '').toLowerCase();
        const rest = tokens.slice(2);

        if (sub === 'создать') {
          return await clanHandlers.handleCreate(ctx, rest.join(' '));
        }
        if (sub === 'пригласить') {
          const targetId = await resolveMentionToId(text, tokens, 2);
          return await clanHandlers.handleInvite(ctx, targetId);
        }
        if (sub === 'вступить') {
          return await clanHandlers.handleJoin(ctx, rest.join(' '));
        }
        if (sub === 'кик') {
          const targetId = await resolveMentionToId(text, tokens, 2);
          return await clanHandlers.handleKick(ctx, targetId);
        }
        if (sub === 'бонус') {
          return await clanHandlers.handleBonus(ctx, rest.join(' '));
        }
        if (sub === 'сейф' || sub === 'казна') {
          const action = (rest[0] || '').toLowerCase();
          if (['пополнить', 'внести', 'закинуть', 'положить'].includes(action)) {
            return await clanHandlers.handleDeposit(ctx, rest[1]);
          }
          if (['забрать', 'снять', 'вывести'].includes(action)) {
            return await clanHandlers.handleWithdraw(ctx, rest[1]);
          }
          return await clanHandlers.handleVault(ctx);
        }
        if (sub === 'инфо') {
          return await clanHandlers.handleInfo(ctx);
        }
        if (sub === 'покинуть') {
          return await clanHandlers.handleLeave(ctx);
        }

        await ctx.send('⛔ Неизвестная команда клана. Введите !помощь для списка команд.');
        return;
      }

      case '!работа':
        return await workHandlers.handleWork(ctx);

      case '!склад':
        return await warehouseHandlers.handleShow(ctx);

      case '!выбрать':
        return await warehouseHandlers.handleSelect(ctx, tokens[1]);

      case '!наука': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'построить') return await scienceHandlers.handleBuild(ctx);
        if (sub === 'расширить') return await scienceHandlers.handleExpand(ctx);
        return await scienceHandlers.handleStatus(ctx);
      }

      case '!лимит': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'расширить') return await limitHandlers.handleExpand(ctx);
        return await limitHandlers.handleStatus(ctx);
      }

      case '!аукцион': {
        if (tokens[1] && /^\d+$/.test(tokens[1])) {
          return await auctionHandlers.handleDetails(ctx, tokens[1]);
        }
        return await auctionHandlers.handleList(ctx);
      }

      case '!продать': {
        const [itemName, qty, start, step, hours] = tokens.slice(1);
        return await auctionHandlers.handleCreate(ctx, itemName, qty, start, step, hours);
      }

      case '!ставка':
        return await auctionHandlers.handleBid(ctx, tokens[1], tokens[2]);

      case '!отмена':
        return await auctionHandlers.handleCancel(ctx, tokens[1]);

      case '!лоты':
        return await auctionHandlers.handleMyLots(ctx);

      case '!обменять':
        return await warehouseHandlers.handleExchangeFactory(ctx);

      case '!рефералы':
        return await profile.handleReferrals(ctx);

      case '!промо': {
        const sub = (tokens[1] || '').toLowerCase();
        if (sub === 'создать') {
          return await promoHandlers.handleCreate(ctx, tokens.slice(2));
        }
        if (sub === 'список') {
          return await promoHandlers.handleList(ctx);
        }
        if (sub === 'удалить') {
          return await promoHandlers.handleDelete(ctx, tokens[2]);
        }
        // !промо WAR2025 — активация игроком
        return await promoHandlers.handleRedeem(ctx, tokens[1]);
      }

      default: {
        // Проверяем, зарегистрирован ли игрок вообще, для более полезной подсказки
        const player = await players.getPlayer(ctx.senderId);
        if (!player) {
          await ctx.send('⛔ Неизвестная команда. Начните с команды !старт');
        } else {
          await ctx.send('⛔ Неизвестная команда. Введите !помощь для списка всех команд.');
        }
      }
    }
  } catch (err) {
    console.error(`[Dispatcher] Ошибка при обработке команды "${command}":`, err);
    await ctx.send('⛔ Произошла ошибка при выполнении команды. Попробуйте позже.');
  }
}

module.exports = { dispatch };
