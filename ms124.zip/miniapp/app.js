(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const fmt = (n) => Math.round(Number(n) || 0).toLocaleString('ru-RU');
  const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
  const launchParams = window.location.search.replace(/^\?/, '');

  const S = {
    screen: 'slots',
    name: '',
    balance: 0,
    config: null,
    stats: null,
    botUrl: null,
    bet: 1000,
    busy: false,
    slotReadyAt: 0,
    bjReadyAt: 0,
    hand: null,        // текущая раздача блэкджека (вид клиента)
    top: { game: 'slots', period: 'day' },
  };

  // ------------------------------------------------------------------ API
  async function api(method, path, body) {
    try {
      const res = await fetch(path, {
        method,
        headers: { 'Content-Type': 'application/json', 'X-Launch-Params': launchParams },
        body: body ? JSON.stringify(body) : undefined,
      });
      const data = await res.json().catch(() => null);
      if (!data) return { ok: false, reason: 'bad_response', message: 'Ошибка ответа сервера.' };
      if (res.status === 401) showGate(data.reason === 'expired' ? 'Сессия устарела' : 'Откройте приложение из VK', data.message || '');
      return data;
    } catch {
      return { ok: false, reason: 'network', message: 'Нет связи с сервером.' };
    }
  }

  // ------------------------------------------------------------------ UI helpers
  let toastTimer = null;
  function toast(text, bad) {
    const el = $('#toast');
    el.textContent = text;
    el.className = 'toast' + (bad ? ' bad' : '');
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (el.hidden = true), 2600);
  }

  function showGate(title, text, link) {
    $('#gateTitle').textContent = title;
    $('#gateText').textContent = text;
    const a = $('#gateLink');
    if (link) { a.href = link; a.hidden = false; } else a.hidden = true;
    $('#gate').hidden = false;
  }

  function setBalance(value, animate) {
    S.balance = Number(value) || 0;
    const el = $('#balance');
    el.textContent = fmt(S.balance);
    if (animate) { el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump'); }
    refreshButtons();
  }

  function haptic(type) {
    try { if (window.vkBridge) window.vkBridge.send('VKWebAppTapticNotificationOccurred', { type }).catch(() => {}); } catch {}
  }

  // ------------------------------------------------------------------ ставка
  function buildBetPanels() {
    $$('.bet-panel').forEach((panel) => {
      panel.innerHTML = `
        <div class="bet-row">
          <input class="bet-input" inputmode="numeric" autocomplete="off" aria-label="Ставка">
        </div>
        <div class="bet-chips">
          <button class="chip" data-bet="min" type="button">Мин</button>
          <button class="chip" data-bet="half" type="button">½</button>
          <button class="chip" data-bet="double" type="button">×2</button>
          <button class="chip" data-bet="max" type="button">Макс</button>
        </div>
        <div class="bet-limits"></div>`;
    });
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-bet]');
      if (!btn || S.busy) return;
      const { minBet, maxBet } = S.config;
      const act = btn.dataset.bet;
      if (act === 'min') S.bet = minBet;
      else if (act === 'half') S.bet = Math.max(minBet, Math.floor(S.bet / 2));
      else if (act === 'double') S.bet = Math.min(maxBet, S.bet * 2);
      else if (act === 'max') S.bet = Math.max(minBet, Math.min(maxBet, S.balance));
      renderBet();
    });
    $$('.bet-input').forEach((input) => {
      input.addEventListener('input', () => {
        const digits = input.value.replace(/\D/g, '').slice(0, 9);
        S.bet = digits ? parseInt(digits, 10) : 0;
        $$('.bet-input').forEach((i) => { if (i !== input) i.value = S.bet ? fmt(S.bet) : ''; });
        input.value = S.bet ? fmt(S.bet) : '';
        refreshButtons();
      });
      input.addEventListener('blur', () => {
        if (!S.config) return;
        S.bet = clamp(S.bet || S.config.minBet, S.config.minBet, S.config.maxBet);
        renderBet();
      });
    });
  }

  function renderBet() {
    $$('.bet-input').forEach((i) => (i.value = fmt(S.bet)));
    if (S.config) {
      $$('.bet-limits').forEach((el) => (el.textContent = `От ${fmt(S.config.minBet)} до ${fmt(S.config.maxBet)} вирт`));
    }
    try { localStorage.setItem('casino_bet', String(S.bet)); } catch {}
    refreshButtons();
  }

  function betError() {
    if (!S.config) return 'Загрузка…';
    if (!S.bet || S.bet < S.config.minBet) return `Минимум ${fmt(S.config.minBet)}`;
    if (S.bet > S.config.maxBet) return `Максимум ${fmt(S.config.maxBet)}`;
    if (S.bet > S.balance) return 'Не хватает вирт';
    return null;
  }

  function refreshButtons() {
    const err = betError();
    const spin = $('#spinBtn');
    const deal = $('#dealBtn');
    const cd = (ready) => Math.max(0, ready - Date.now());
    spin.disabled = S.busy || !!err || cd(S.slotReadyAt) > 0;
    spin.textContent = err ? err : `Крутить · ${fmt(S.bet)}`;
    deal.disabled = S.busy || !!err || cd(S.bjReadyAt) > 0 || !!S.hand;
    deal.textContent = err ? err : `Раздать · ${fmt(S.bet)}`;
    $('#hitBtn').disabled = S.busy;
    $('#standBtn').disabled = S.busy;
  }

  // Кнопки «оживают» сами, когда истёк кулдаун
  setInterval(() => { if (S.slotReadyAt || S.bjReadyAt) refreshButtons(); }, 400);

  // ------------------------------------------------------------------ слоты
  const SYMS = ['cherry', 'lemon', 'bell', 'star', 'diamond', 'seven'];
  const randSym = () => SYMS[Math.floor(Math.random() * SYMS.length)];
  const cellH = () => parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--cell')) || 78;
  const symCell = (key) => `<div class="cell"><svg class="sym"><use href="#s-${key}"/></svg></div>`;

  const reels = $$('#reels .reel').map((el) => ({ el, strip: $('.strip', el), cells: [randSym(), randSym(), randSym()] }));
  function paintReel(r) {
    r.strip.innerHTML = r.cells.map(symCell).join('');
    r.strip.style.transform = 'translateY(0)';
  }
  reels.forEach(paintReel);

  async function animateReel(r, finalKey, duration) {
    const H = cellH();
    const extra = 12 + Math.floor(duration / 90);
    const list = [...r.cells];
    for (let i = 0; i < extra; i++) list.push(randSym());
    list.push(finalKey);
    list.push(randSym());
    const k = list.length - 2; // индекс итогового символа (он окажется по центру)
    r.strip.innerHTML = list.map(symCell).join('');
    r.el.classList.add('spinning');
    const anim = r.strip.animate(
      [{ transform: 'translateY(0)' }, { transform: `translateY(${-(k - 1) * H}px)` }],
      { duration, easing: 'cubic-bezier(.16,.72,.22,1)', fill: 'forwards' }
    );
    await anim.finished.catch(() => {});
    r.el.classList.remove('spinning');
    r.cells = [list[k - 1], list[k], list[k + 1]];
    anim.cancel();
    paintReel(r);
  }

  async function doSpin() {
    if (S.busy || betError()) return;
    S.busy = true;
    const bet = S.bet;
    refreshButtons();
    $('#reels').classList.remove('win');
    setResult('', '');

    const res = await api('POST', '/api/casino/slot', { bet });
    if (!res.ok) {
      S.busy = false;
      if (res.reason === 'cooldown' && res.cooldownMs) S.slotReadyAt = Date.now() + res.cooldownMs;
      if (typeof res.balance === 'number') setBalance(res.balance);
      toast(res.message || 'Не удалось крутить', true);
      refreshButtons();
      return;
    }

    setBalance(S.balance - bet); // ставка списана сразу, выигрыш покажем после анимации
    const dur = res.animMs || 2600;
    S.slotReadyAt = Date.now() + Math.max(dur, res.cooldownMs || 0);
    await Promise.all(reels.map((r, i) => animateReel(r, res.reels[i], dur * (0.6 + 0.2 * i))));

    setBalance(res.balance, res.win > 0);
    if (res.win > 0) {
      $('#reels').classList.add('win');
      setResult(`+${fmt(res.win)} вирт`, 'win');
      haptic('success');
    } else {
      setResult(`−${fmt(res.bet)} вирт`, 'lose');
      haptic('warning');
    }
    S.busy = false;
    refreshButtons();
  }

  function setResult(text, cls) {
    const el = $('#slotResult');
    el.textContent = text || 'Три одинаковых символа — выигрыш';
    el.className = 'result ' + (cls || '');
  }

  function buildPaytable() {
    const rows = [...S.config.symbols].sort((a, b) => a.mult - b.mult);
    $('#paytable').innerHTML =
      rows.map((s) => `<div class="pay-row"><div class="trio">${[0, 1, 2].map(() => `<svg><use href="#s-${s.key}"/></svg>`).join('')}</div><b>×${String(s.mult).replace('.', ',')}</b></div>`).join('') +
      '<div class="pay-note">Выигрыш — только когда все три символа совпали. Сумма = ставка × множитель.</div>';
  }

  // ------------------------------------------------------------------ блэкджек
  const SUIT = { spades: '♠', hearts: '♥', diamonds: '♦', clubs: '♣' };
  function cardEl(card, isNew) {
    const suit = SUIT[card.suit] || '';
    const red = card.suit === 'hearts' || card.suit === 'diamonds';
    return `<div class="card${red ? ' red' : ''}${isNew ? ' deal' : ''}" data-suit="${suit}"><b>${card.rank}</b><i>${suit}</i></div>`;
  }
  const backEl = (isNew) => `<div class="card back${isNew ? ' deal' : ''}"></div>`;

  function handTotal(cards) {
    let total = cards.reduce((s, c) => s + (c.rank === 'A' ? 11 : ['J', 'Q', 'K'].includes(c.rank) ? 10 : parseInt(c.rank, 10)), 0);
    let aces = cards.filter((c) => c.rank === 'A').length;
    while (total > 21 && aces > 0) { total -= 10; aces--; }
    return total;
  }

  const prevCount = { player: 0, dealer: 0 };
  function paintHand(hand, opts = {}) {
    const dealerCards = opts.dealerCards || hand.dealerCards;
    const pc = hand.playerCards;
    $('#playerCards').innerHTML = pc.map((c, i) => cardEl(c, i >= prevCount.player)).join('');
    $('#dealerCards').innerHTML =
      dealerCards.map((c, i) => cardEl(c, i >= prevCount.dealer)).join('') + (opts.hideSecond ? backEl(prevCount.dealer < 2) : '');
    prevCount.player = pc.length;
    prevCount.dealer = dealerCards.length + (opts.hideSecond ? 1 : 0);

    const pt = hand.playerTotal != null ? hand.playerTotal : handTotal(pc);
    const pEl = $('#playerTotal');
    pEl.textContent = String(pt);
    pEl.className = 'total' + (pt > 21 ? ' bust' : '');
    const dEl = $('#dealerTotal');
    if (opts.hideSecond) { dEl.textContent = ''; dEl.className = 'total'; }
    else { const dt = handTotal(dealerCards); dEl.textContent = String(dt); dEl.className = 'total' + (dt > 21 ? ' bust' : ''); }
  }

  function setBanner(text, cls) {
    const el = $('#bjBanner');
    el.textContent = text;
    el.className = 'table-mid ' + (cls || '');
  }

  function bjIdle() {
    $('#bjBetBlock').hidden = false;
    $('#bjActions').hidden = true;
    refreshButtons();
  }
  function bjPlaying() {
    $('#bjBetBlock').hidden = true;
    $('#bjActions').hidden = false;
    refreshButtons();
  }

  function showTurn(hand) {
    S.hand = hand;
    paintHand(hand, { hideSecond: true });
    setBanner('Ваш ход: ещё карту или хватит', '');
    bjPlaying();
  }

  async function showFinish(hand) {
    // Дилер «доигрывает» на глазах: сначала вскрывается закрытая карта, затем добираются остальные.
    const all = hand.dealerCards;
    if (all.length >= 2 && S.hand) {
      paintHand(hand, { dealerCards: all.slice(0, 2) });
      for (let n = 3; n <= all.length; n++) {
        await sleep(520);
        paintHand(hand, { dealerCards: all.slice(0, n) });
      }
    } else {
      paintHand(hand, { dealerCards: all });
    }
    S.hand = null;

    const texts = {
      win: [`Победа  +${fmt(hand.net)}`, 'win'],
      blackjack: [`Блэкджек!  +${fmt(hand.net)}`, 'win'],
      push: ['Ничья — ставка возвращена', 'push'],
      lose: [`Поражение  −${fmt(hand.bet)}`, 'lose'],
    };
    const [text, cls] = texts[hand.outcome] || texts.lose;
    setBanner(text, cls);
    setBalance(hand.balance, hand.win > 0);
    haptic(hand.win > hand.bet ? 'success' : hand.win === hand.bet ? 'warning' : 'error');
    bjIdle();
  }

  async function bjStart() {
    if (S.busy || betError() || S.hand) return;
    S.busy = true;
    const bet = S.bet;
    refreshButtons();
    prevCount.player = 0; prevCount.dealer = 0;
    $('#playerCards').innerHTML = ''; $('#dealerCards').innerHTML = '';
    $('#playerTotal').textContent = ''; $('#dealerTotal').textContent = '';

    const res = await api('POST', '/api/casino/blackjack/start', { bet });
    if (!res.ok) {
      S.busy = false;
      if (res.reason === 'cooldown' && res.cooldownMs) S.bjReadyAt = Date.now() + res.cooldownMs;
      toast(res.message || 'Не удалось начать раздачу', true);
      setBanner('Ставка → раздача', '');
      refreshButtons();
      return;
    }
    S.bjReadyAt = Date.now() + (res.cooldownMs || 3000);
    setBalance(S.balance - bet);
    const hand = res.hand;
    if (hand.phase === 'turn') {
      S.hand = hand;
      showTurn(hand);
    } else {
      S.hand = { playerCards: [], dealerCards: [] }; // раздача уже закрыта (натуральный блэкджек)
      paintHand({ playerCards: hand.playerCards, dealerCards: hand.dealerCards.slice(0, 1), playerTotal: hand.playerTotal }, { hideSecond: true });
      await sleep(600);
      await showFinish(hand);
    }
    S.busy = false;
    refreshButtons();
  }

  async function bjAction(kind) {
    if (S.busy || !S.hand) return;
    S.busy = true;
    refreshButtons();
    const res = await api('POST', `/api/casino/blackjack/${kind}`);
    if (!res.ok) {
      toast(res.message || 'Ошибка', true);
      if (res.reason === 'no_active_hand') { S.hand = null; setBanner('Раздача закрыта — начните новую', ''); bjIdle(); }
      S.busy = false;
      refreshButtons();
      return;
    }
    const hand = res.hand;
    if (hand.phase === 'turn') showTurn(hand);
    else {
      if (kind === 'hit') {
        // сначала показываем добранную карту (перебор), потом вскрываем дилера
        paintHand(hand, { dealerCards: hand.dealerCards.slice(0, 1), hideSecond: true });
        await sleep(700);
      }
      await showFinish(hand);
    }
    S.busy = false;
    refreshButtons();
  }

  function buildRules() {
    const c = S.config;
    $('#bjRules').textContent =
      `Блэкджек (21 с двух карт) платит ${String(c.blackjackNaturalMult).replace('.', ',')}:1, обычная победа — 1:1, при равном счёте побеждаете вы. ` +
      `Дилер берёт карты до 17. Брошенная раздача сгорает через ${c.blackjackTimeoutMin} мин.`;
  }

  // ------------------------------------------------------------------ топ
  async function loadTop() {
    const { game, period } = S.top;
    $$('#topGame button').forEach((b) => b.classList.toggle('on', b.dataset.game === game));
    $$('#topPeriod button').forEach((b) => b.classList.toggle('on', b.dataset.period === period));
    $('#topList').innerHTML = '<li class="empty">Загрузка…</li>';

    const [top, st] = await Promise.all([api('GET', `/api/casino/top?game=${game}&period=${period}`), api('GET', '/api/casino/state')]);
    if (st.ok) { S.stats = st.stats; setBalance(st.player.balance); }
    if (!top.ok) { $('#topList').innerHTML = `<li class="empty">${top.message || 'Не удалось загрузить'}</li>`; return; }

    const reward = $('#topReward');
    if (top.dailyRewards) {
      reward.hidden = false;
      reward.textContent = `В 00:00 МСК топ-3 слотов за день получают: ${top.dailyRewards.map(fmt).join(' / ')} вирт`;
    } else reward.hidden = true;

    $('#topList').innerHTML = top.top.length
      ? top.top.map((r) => `<li class="${r.isMe ? 'me' : ''}"><span class="place p${r.place}">${r.place}</span><span class="pname">${escapeHtml(r.name)}</span><span class="psum">${fmt(r.totalWin)}</span></li>`).join('')
      : '<li class="empty">За этот период ещё никто не выигрывал</li>';

    if (S.stats) {
      const s = game === 'slots' ? S.stats.slots : S.stats.blackjack;
      const label = game === 'slots' ? 'Партий' : 'Раздач';
      const net = s.totalNet;
      $('#myStats').innerHTML =
        `${label}: <b>${fmt(s.games)}</b> · поставлено <b>${fmt(s.totalBet)}</b><br>` +
        `Выиграно: <b>${fmt(s.totalWin)}</b> · итог <b class="${net >= 0 ? 'plus' : 'minus'}">${net >= 0 ? '+' : '−'}${fmt(Math.abs(net))}</b><br>` +
        `Сегодня: поставлено <b>${fmt(s.todayBet)}</b>, выиграно <b>${fmt(s.todayWin)}</b>`;
    }
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // ------------------------------------------------------------------ навигация
  function go(screen) {
    S.screen = screen;
    $$('.screen').forEach((el) => (el.hidden = el.id !== `screen-${screen}`));
    $$('.tab').forEach((t) => t.classList.toggle('on', t.dataset.screen === screen));
    if (screen === 'top') loadTop();
    window.scrollTo(0, 0);
  }

  // ------------------------------------------------------------------ VK Bridge
  function loadScript(src, ms) {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      const timer = setTimeout(() => { s.remove(); reject(new Error('timeout')); }, ms);
      s.src = src;
      s.onload = () => { clearTimeout(timer); resolve(); };
      s.onerror = () => { clearTimeout(timer); s.remove(); reject(new Error('load_failed')); };
      document.head.appendChild(s);
    });
  }

  async function initBridge() {
    // 1) свой файл /vendor/vk-bridge.min.js (надёжнее всего), 2) запасные CDN
    const sources = ['/vendor/vk-bridge.min.js', 'https://cdn.jsdelivr.net/npm/@vkontakte/vk-bridge/dist/browser.min.js', 'https://unpkg.com/@vkontakte/vk-bridge/dist/browser.min.js'];
    for (const src of sources) {
      if (window.vkBridge) break;
      try { await loadScript(src, 4000); } catch {}
    }
    if (!window.vkBridge) return;
    try {
      await window.vkBridge.send('VKWebAppInit');
      window.vkBridge.send('VKWebAppSetViewSettings', { status_bar_style: 'light', action_bar_color: '#0f1013' }).catch(() => {});
    } catch {}
  }

  // ------------------------------------------------------------------ старт
  async function boot() {
    initBridge(); // не блокирует интерфейс

    const st = await api('GET', '/api/casino/state');
    if (!st.ok) {
      if (st.reason === 'not_registered') showGate('Нужен аккаунт', st.message, st.botUrl);
      else if (st.reason === 'banned') showGate('Доступ закрыт', st.message);
      else if ($('#gate').hidden) showGate('Не удалось загрузить', st.message || 'Попробуйте открыть приложение ещё раз.');
      return; // при 401 заглушку уже показал api()
    }

    S.config = st.config;
    S.stats = st.stats;
    S.botUrl = st.botUrl;
    S.name = st.player.name;
    $('#playerName').textContent = S.name;
    try { const saved = parseInt(localStorage.getItem('casino_bet'), 10); if (saved) S.bet = saved; } catch {}
    S.bet = clamp(S.bet, S.config.minBet, S.config.maxBet);
    S.slotReadyAt = Date.now() + (st.cooldowns.slotMs || 0);
    S.bjReadyAt = Date.now() + (st.cooldowns.blackjackMs || 0);

    buildBetPanels();
    buildPaytable();
    buildRules();
    setBalance(st.player.balance);
    renderBet();

    if (st.blackjack) { // недоигранная раздача — продолжаем с того же места
      go('blackjack');
      showTurn(st.blackjack);
    } else {
      bjIdle();
    }

    $('#spinBtn').addEventListener('click', doSpin);
    $('#dealBtn').addEventListener('click', bjStart);
    $('#hitBtn').addEventListener('click', () => bjAction('hit'));
    $('#standBtn').addEventListener('click', () => bjAction('stand'));
    $$('.tab').forEach((t) => t.addEventListener('click', () => go(t.dataset.screen)));
    $$('#topGame button').forEach((b) => b.addEventListener('click', () => { S.top.game = b.dataset.game; loadTop(); }));
    $$('#topPeriod button').forEach((b) => b.addEventListener('click', () => { S.top.period = b.dataset.period; loadTop(); }));
  }

  boot();
})();
