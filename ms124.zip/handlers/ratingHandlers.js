'use strict';

const { Keyboard } = require('vk-io');
const players = require('../db/players');
const clansDb = require('../db/clans');
const clanGame = require('../game/clan');
const production = require('../db/production');
const economy = require('../game/economy');
const globalBoost = require('../game/globalBoost');
const farm = require('../game/farm');
const depositsGame = require('../game/deposits');
const msg = require('../utils/messages');
const images = require('../game/commandImages');

async function handleTopFactories(ctx) {
  const list = await players.getTopByFactories(10);
  const viewer = await players.getPlayer(ctx.senderId);
  const viewerCoords = viewer && viewer.registration_step === 'done' ? { x: viewer.x, y: viewer.y } : null;
  await ctx.send(msg.topFactoriesMessage(list, viewerCoords));
}

async function handleTopBalance(ctx) {
  const list = await players.getTopByBalance(15);
  await ctx.send(msg.topBalanceMessage(list));
}

async function handleTopClans(ctx) {
  const list = await clanGame.getTopClansByIncome(10);
  await ctx.send(msg.topClansMessage(list));
}

async function handleTopRobot(ctx) {
  const list = await players.getTopByRobotLevel(10);
  await ctx.send(msg.topRobotMessage(list));
}

async function handleTopSuperRobot(ctx) {
  const list = await players.getTopBySuperRobotLevel(10);
  await ctx.send(msg.topSuperRobotMessage(list));
}

// Общий топ по суммарному доходу в час (заводы + научные центры + бонусы) — считаем на лету
// для всех активных игроков, как и в почасовом тике (game/economy.js: hourlyTick), затем берём топ-10.
// Общий топ по суммарному доходу в час (заводы + научные центры + бонусы) — считаем на лету
// для всех активных игроков, ТА ЖЕ функция и цепочка множителей, что и в почасовом тике
// (game/economy.js: computeIncomeBreakdown — заводы+наука+прокачка заводов+VIP из
// calc.incomePerHour, ПЛЮС глобальный буст/индустриализация клана/бонус зон клана поверх).
// Раньше здесь вызывался calc.incomePerHour() напрямую, без этих трёх множителей — топ
// занижал доход игрокам с активной зоной клана/индустриализацией/глобальным бустом,
// показывая другое число, чем в профиле того же игрока.
async function handleTopIncome(ctx) {
  const all = await players.getAllActivePlayers();
  const boost = await globalBoost.getBoost();
  const globalMult = boost ? Number(boost.multiplier) : 1;

  const withIncome = [];
  for (const player of all) {
    // Забаненные игроки не должны светиться в топе дохода — их реальный доход уже 0
    // (game/economy.js: hourlyTick), топ должен показывать то же самое, а не проекцию.
    if (player.is_banned) continue;
    if (player.factories <= 0 && (player.science_centers || 0) <= 0) continue;
    const factoriesInProd = await production.getFactoriesInUse(player.vk_id);
    const breakdown = await economy.computeIncomeBreakdown(player, factoriesInProd, globalMult);
    if (breakdown.total > 0) withIncome.push({ player, income: breakdown.total });
  }
  withIncome.sort((a, b) => b.income - a.income);
  const top = withIncome.slice(0, 10);
  await ctx.send(msg.topIncomeMessage(top));
}

async function handleTopScience(ctx) {
  const list = await players.getTopByScienceCenters(10);
  await ctx.send(msg.topScienceMessage(list));
}

async function handleTopFarmLevel(ctx) {
  const list = await players.getTopByFarmLevel(10);
  await ctx.send(msg.topFarmLevelMessage(list));
}

async function handleTopFarmIncome(ctx) {
  const list = await players.getTopByFarmLevel(10); // доход монотонно растёт с уровнем — порядок тот же
  const rate = await farm.getExchangeRate();
  await ctx.send(msg.topFarmIncomeMessage(list, rate));
}

// Топ по деньгам, фактически снятым/полученным с депозитов (payout закрытых вкладов),
// см. db/deposits.js: getTopByDepositPayout — засчитываются только вклады, пролежавшие
// от открытия до закрытия не меньше C.DEPOSIT_TOP_MIN_HOLD_HOURS часов.
async function handleTopDeposits(ctx) {
  const list = await depositsGame.getTopByPayout(10);
  await ctx.send(msg.topDepositsMessage(list));
}

// Разделов помощи стало 11 (msg.HELP_SECTION_ORDER) — при 2 кнопках в ряд это 11 кнопок в
// одной инлайн-клавиатуре, а ВК валит messages.send с "Code №911 - Keyboard format is
// invalid: keyboard contains too much buttons" при инлайн-клавиатуре больше ~10 кнопок (это
// отдельный, более строгий лимит, чем 10 рядов/40 кнопок у ОБЫЧНОЙ клавиатуры). Листаем
// страницами по HELP_PAGE_SIZE, как уже сделано для магазина бизнесов (см.
// handlers/businessHandlers.js: shopKeyboard) — с учётом строки навигации это максимум
// 8 + 2 = 10 кнопок и 5 рядов на страницу, что укладывается в лимит.
const HELP_PAGE_SIZE = 8;

function buildHelpKeyboard(page = 0) {
  const order = msg.HELP_SECTION_ORDER;
  const totalPages = Math.max(1, Math.ceil(order.length / HELP_PAGE_SIZE));
  const safePage = Math.min(Math.max(page, 0), totalPages - 1);
  const pageKeys = order.slice(safePage * HELP_PAGE_SIZE, safePage * HELP_PAGE_SIZE + HELP_PAGE_SIZE);

  const rows = [];
  for (let i = 0; i < pageKeys.length; i += 2) {
    const chunk = pageKeys.slice(i, i + 2);
    rows.push(
      chunk.map((key) =>
        Keyboard.textButton({
          label: msg.HELP_SECTIONS[key].label,
          payload: { cmd: 'help_section', section: key, page: safePage },
          color: Keyboard.PRIMARY_COLOR,
        })
      )
    );
  }

  const nav = [];
  if (safePage > 0) {
    nav.push(
      Keyboard.textButton({ label: '◀️ Пред. страница', payload: { cmd: 'help_page', page: safePage - 1 }, color: Keyboard.SECONDARY_COLOR })
    );
  }
  if (safePage < totalPages - 1) {
    nav.push(
      Keyboard.textButton({ label: 'След. страница ▶️', payload: { cmd: 'help_page', page: safePage + 1 }, color: Keyboard.SECONDARY_COLOR })
    );
  }
  if (nav.length) rows.push(nav);

  return Keyboard.keyboard(rows).inline();
}

async function handleHelp(ctx, page = 0) {
  await ctx.send(
    images.withImage('help', {
      message: msg.HELP_INTRO,
      keyboard: buildHelpKeyboard(page),
    })
  );
}

async function handleHelpSection(ctx, sectionKey, page = 0) {
  const section = msg.HELP_SECTIONS[sectionKey];
  if (!section) {
    // Устаревшая/битая кнопка — просто показываем меню заново
    await handleHelp(ctx, page);
    return;
  }
  await ctx.send({
    message: section.text,
    keyboard: buildHelpKeyboard(page),
  });
}

async function handleHelpPage(ctx, page) {
  await handleHelp(ctx, page);
}

module.exports = {
  handleTopFactories,
  handleTopBalance,
  handleTopClans,
  handleTopRobot,
  handleTopSuperRobot,
  handleTopScience,
  handleTopIncome,
  handleTopFarmLevel,
  handleTopFarmIncome,
  handleTopDeposits,
  handleHelp,
  handleHelpSection,
  handleHelpPage,
};
