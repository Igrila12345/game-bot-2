'use strict';

const players = require('../db/players');
const styles = require('../game/styles');
const calc = require('../game/calc');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

function kindEmoji(kind) {
  return kind === 'video' ? '🎬' : '🖼️';
}

async function handleInventory(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const inventory = await styles.getInventory(ctx.senderId);

  if (!inventory.length) {
    await ctx.send(
      `🎨 ИНВЕНТАРЬ СТИЛЕЙ\n\nУ вас пока нет ни одного стиля.\n` +
        `Стили можно получить от администратора или купить на витрине: витрина`
    );
    return;
  }

  const lines = inventory.map((s) => {
    const isActive = player.active_style_id === s.id;
    const lockMark = s.forced ? ' 🔒 (принудительный, нельзя снять/продать)' : '';
    return `#${s.id} ${kindEmoji(s.kind)} ${s.kind === 'photo' ? 'фото' : 'видео'}${isActive ? ' ← активен сейчас' : ''}${lockMark}`;
  });

  const lockedNote = player.style_locked
    ? `\n\n🔒 Ваш активный стиль зафиксирован администратором — сменить или продать стили сейчас нельзя.`
    : `\n\nВыбрать другой: стиль выбрать [номер]\nСнять текущий: стиль снять\nПродать: стиль продать [номер] [цена]`;

  await ctx.send(`🎨 ИНВЕНТАРЬ СТИЛЕЙ\n\n${lines.join('\n')}${lockedNote}`);
}

async function handleEquip(ctx, idArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const id = parseInt(idArg, 10);
  if (!Number.isInteger(id)) {
    await ctx.send('⛔ Формат: стиль выбрать [номер] (номер — из списка команды "стиль")');
    return;
  }

  const result = await styles.equipStyle(ctx.senderId, id);
  if (!result.ok) {
    if (result.reason === 'locked') {
      await ctx.send('🔒 Ваш стиль зафиксирован администратором — сменить нельзя.');
    } else if (result.reason === 'not_owner') {
      await ctx.send('⛔ Этот стиль вам не принадлежит.');
    } else if (result.reason === 'not_found') {
      await ctx.send('⛔ Стиль с таким номером не найден.');
    } else {
      await ctx.send('⛔ Не удалось экипировать стиль.');
    }
    return;
  }

  await ctx.send(`✅ Стиль #${id} экипирован! Посмотреть: профиль`);
}

async function handleUnequip(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await styles.unequipStyle(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'locked') {
      await ctx.send('🔒 Ваш стиль зафиксирован администратором — снять нельзя.');
    } else {
      await ctx.send('⛔ Не удалось снять стиль.');
    }
    return;
  }
  await ctx.send('✅ Стиль снят, профиль вернулся к стандартному виду.');
}

async function handleSell(ctx, idArg, priceArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const id = parseInt(idArg, 10);
  const price = parseInt(priceArg, 10);
  if (!Number.isInteger(id) || !Number.isInteger(price)) {
    await ctx.send(`⛔ Формат: стиль продать [номер] [цена в виртах, не менее ${styles.MIN_LISTING_PRICE}]`);
    return;
  }

  const result = await styles.listStyle(ctx.senderId, id, price);
  if (!result.ok) {
    if (result.reason === 'forced') {
      await ctx.send('🔒 Этот стиль зафиксирован администратором — продать нельзя.');
    } else if (result.reason === 'not_owner') {
      await ctx.send('⛔ Этот стиль вам не принадлежит.');
    } else if (result.reason === 'not_found') {
      await ctx.send('⛔ Стиль с таким номером не найден.');
    } else if (result.reason === 'already_listed') {
      await ctx.send('⛔ Этот стиль уже выставлен на витрине.');
    } else if (result.reason === 'price_too_low') {
      await ctx.send(`⛔ Минимальная цена лота — ${result.minPrice} вирт.`);
    } else {
      await ctx.send('⛔ Не удалось выставить стиль на продажу.');
    }
    return;
  }

  await ctx.send(
    `✅ Стиль #${id} выставлен на витрину за ${calc.formatNumber(price)} вирт (лот #${result.listing.id}).\n` +
      `Отменить: витрина снять ${result.listing.id}`
  );
}

async function handleCancelListing(ctx, listingIdArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const listingId = parseInt(listingIdArg, 10);
  if (!Number.isInteger(listingId)) {
    await ctx.send('⛔ Формат: витрина снять [номер лота]');
    return;
  }

  const result = await styles.cancelListing(ctx.senderId, listingId);
  if (!result.ok) {
    if (result.reason === 'not_owner') {
      await ctx.send('⛔ Это не ваш лот.');
    } else if (result.reason === 'not_found') {
      await ctx.send('⛔ Лот с таким номером не найден.');
    } else {
      await ctx.send('⛔ Не удалось снять лот.');
    }
    return;
  }

  await ctx.send('✅ Лот снят с витрины.');
}

async function handleShowcase(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const listings = await styles.getShowcase();
  if (!listings.length) {
    await ctx.send(
      `🖼️ ВИТРИНА СТИЛЕЙ\n\nСейчас на продаже ничего нет.\n` +
        `Выставить свой стиль: стиль продать [номер] [цена]`
    );
    return;
  }

  const lines = await Promise.all(
    listings.map(async (l) => {
      const seller = await players.getPlayer(l.seller_vk_id);
      const sellerName = seller ? seller.state_name : `id${l.seller_vk_id}`;
      return `Лот #${l.id}: ${kindEmoji(l.kind)} ${l.kind === 'photo' ? 'фото' : 'видео'} — ${calc.formatNumber(
        l.price
      )} вирт (продавец: ${sellerName})`;
    })
  );

  await ctx.send(
    `🖼️ ВИТРИНА СТИЛЕЙ\n\n${lines.join('\n')}\n\n` +
      `Купить: витрина купить [номер лота]\nВыставить свой стиль: стиль продать [номер] [цена]`
  );
}

async function handleBuy(ctx, listingIdArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const listingId = parseInt(listingIdArg, 10);
  if (!Number.isInteger(listingId)) {
    await ctx.send('⛔ Формат: витрина купить [номер лота]');
    return;
  }

  const result = await styles.buyListing(ctx.senderId, listingId);
  if (!result.ok) {
    if (result.reason === 'own_listing') {
      await ctx.send('⛔ Нельзя купить собственный лот.');
    } else if (result.reason === 'insufficient_balance') {
      await ctx.send(`⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.price)}, у вас ${calc.formatNumber(result.have)}.`);
    } else if (result.reason === 'not_found') {
      await ctx.send('⛔ Лот с таким номером не найден (возможно, уже куплен).');
    } else {
      await ctx.send('⛔ Не удалось купить лот.');
    }
    return;
  }

  await ctx.send(
    `✅ Куплено! Стиль #${result.styleId} (${kindEmoji(result.kind)}) добавлен в ваш инвентарь за ${calc.formatNumber(
      result.price
    )} вирт.\nЭкипировать: стиль выбрать ${result.styleId}`
  );

  if (ctx.bot) {
    await ctx.bot
      .notifyUser(result.sellerVkId, `💰 Ваш стиль #${result.styleId} куплен за ${calc.formatNumber(result.price)} вирт!`)
      .catch(() => {});
  }
}

module.exports = {
  handleInventory,
  handleEquip,
  handleUnequip,
  handleSell,
  handleCancelListing,
  handleShowcase,
  handleBuy,
};
