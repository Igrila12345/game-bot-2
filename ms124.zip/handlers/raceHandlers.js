'use strict';

const C = require('../game/constants');
const calc = require('../game/calc');
const players = require('../db/players');
const factoryRace = require('../game/factoryRace');

function formatTimeLeft(untilDate) {
  const ms = new Date(untilDate).getTime() - Date.now();
  if (ms <= 0) return 'сейчас';
  const days = Math.floor(ms / (24 * 60 * 60 * 1000));
  const hours = Math.floor((ms % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  if (days > 0) return `${days} дн. ${hours} ч.`;
  return `${hours} ч.`;
}

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите !старт');
    return null;
  }
  return player;
}

// "!гонка" — статус недельной гонки заводов: сколько времени осталось, ваш личный прогресс,
// топ-5 игроков и топ-5 кланов по проценту прироста заводов прямо сейчас.
async function handleStatus(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const enabled = await factoryRace.isEnabled();
  if (!enabled) {
    await ctx.send('🏁 Гонка заводов сейчас не проводится администрацией.');
    return;
  }

  const cycleInfo = await factoryRace.getCycleInfo();
  const progress = await factoryRace.getPlayerProgress(ctx.senderId);
  const topPlayers = await factoryRace.getLivePlayerRanking(5);
  const topClans = await factoryRace.getLiveClanRanking(5);
  const rewardsPlayer = await factoryRace.getRewardsConfig('player');
  const rewardsClan = await factoryRace.getRewardsConfig('clan');

  let text = `🏁 ГОНКА ЗАВОДОВ (неделя)\n`;
  text += `⏳ До подведения итогов: ${formatTimeLeft(cycleInfo.endsAt)}\n\n`;

  if (progress) {
    text += `📈 Ваш прирост: +${progress.growth} завод. (было ${progress.start}, сейчас ${progress.current})\n`;
    text += `Минимум для зачёта: +${C.FACTORY_RACE_MIN_GROWTH_PLAYER} завод.\n\n`;
  }

  text += `👤 ТОП-5 ИГРОКОВ ПО ПРИРОСТУ:\n`;
  if (topPlayers.length) {
    topPlayers.forEach((p, i) => {
      text += `${i + 1}. ${p.name} — +${p.growth} завод. (${Math.round(p.percent * 100)}%)\n`;
    });
  } else {
    text += `Пока никто не набрал минимум +${C.FACTORY_RACE_MIN_GROWTH_PLAYER} завод.\n`;
  }

  text += `\n👥 ТОП-5 КЛАНОВ ПО ПРИРОСТУ:\n`;
  if (topClans.length) {
    topClans.forEach((c, i) => {
      text += `${i + 1}. «${c.name}» — +${c.growth} завод. (${Math.round(c.percent * 100)}%)\n`;
    });
  } else {
    text += `Пока никто не набрал минимум +${C.FACTORY_RACE_MIN_GROWTH_CLAN} завод.\n`;
  }

  text += `\n🏆 Награды (топ-3):\n`;
  text += `Игроки: ${rewardsPlayer.map((r) => `${r.place} место — ${calc.formatNumber(r.virts)} вирт`).join(', ')}\n`;
  text += `Кланы (в сейф): ${rewardsClan.map((r) => `${r.place} место — ${calc.formatNumber(r.virts)} вирт`).join(', ')}`;

  await ctx.send(text.trim());
}

module.exports = { handleStatus };
