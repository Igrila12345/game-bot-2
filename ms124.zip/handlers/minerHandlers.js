'use strict';

const players = require('../db/players');
const calc = require('../game/calc');
const C = require('../game/constants');
const miner = require('../game/miner');
const msg = require('../utils/messages');
const images = require('../game/commandImages');

async function handleStatus(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  if (!calc.isMinerActive(player)) {
    await ctx.send(
      images.withImage(
        'miner',
        `⛏️ Майнер у вас не активен.\n` +
          `Майнер — донат-предмет: выдаётся администратором после оплаты и пассивно приносит немного вирт и жетонов каждый час, без каких-либо действий с вашей стороны.`
      )
    );
    return;
  }

  const untilText = calc.isMinerForever(player) ? 'НАВСЕГДА' : `до ${msg.formatDateTimeMsk(player.miner_until)}`;
  const level = player.miner_level || 0;
  const tokensPerHour = miner.tokensForLevel(level);
  const levelLine =
    level < C.MINER_MAX_LEVEL
      ? `📈 Уровень: ${level}/${C.MINER_MAX_LEVEL} (прокачка — ${C.MINER_LEVEL_UP_PRICE_RUB}₽/уровень, +${Math.round(
          C.MINER_LEVEL_TOKEN_BONUS_PER_LEVEL * 100
        )}% жетонов за уровень, см. донат)`
      : `📈 Уровень: ${level}/${C.MINER_MAX_LEVEL} (максимум!)`;

  await ctx.send(
    images.withImage(
      'miner',
      `⛏️ Майнер активен ${untilText}.\n` +
        `${levelLine}\n` +
        `Каждый час пассивно приносит: ${calc.formatNumber(C.MINER_HOURLY_VIRTS_MIN)} вирт + ${tokensPerHour} жетонов.`
    )
  );
}

module.exports = { handleStatus };
