'use strict';

const players = require('../db/players');
const science = require('../game/science');
const calc = require('../game/calc');
const C = require('../game/constants');
const events = require('../game/events');
const images = require('../game/commandImages');
const scienceExchangeDb = require('../db/scienceExchange');

async function requireRegistered(ctx) {
  const player = await players.getPlayer(ctx.senderId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return null;
  }
  return player;
}

async function handleStatus(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const limit = calc.currentScienceLimit(player.science_limit_level);
  const nextRow = C.SCIENCE_LIMIT_LEVELS.find((l) => l.level === (player.science_limit_level || 1) + 1);
  const nextCost = calc.scienceBuildCost(player.science_centers || 0);

  let text =
    `🔬 НАУЧНЫЕ ЦЕНТРЫ\n` +
    `Построено: ${player.science_centers || 0}/${limit}\n` +
    `Доход с центра: ${C.SCIENCE_INCOME_PER_HOUR} вирт/час\n` +
    `Постройка следующего: ${C.SCIENCE_BUILD_FACTORY_COST} заводов + ${calc.formatNumber(nextCost)} вирт — наука построить\n` +
    `(цена растёт на ${calc.formatNumber(C.SCIENCE_BUILD_COST_STEP_AMOUNT)} вирт каждые ${C.SCIENCE_BUILD_COST_STEP_SIZE} построенных центров)`;

  if (nextRow) {
    text += `\n\n📈 Расширить лимит до ${nextRow.limit}: ${calc.formatNumber(nextRow.cost)} вирт — наука расширить`;
  } else {
    text += `\n\n🏆 Максимальный уровень лимита достигнут!`;
  }

  const scienceLeftToExchange = Math.max(
    0,
    (player.science_centers || 0) - C.NEWBIE_PROTECTION_SCIENCE_CENTERS
  );
  const exchangeLimit = calc.isVipActive(player)
    ? C.SCIENCE_TO_FACTORY_LIMIT_PER_HOUR * C.VIP_EXCHANGE_LIMIT_MULTIPLIER
    : C.SCIENCE_TO_FACTORY_LIMIT_PER_HOUR;
  const usedThisHour = await scienceExchangeDb.countRecentExchanges(player.vk_id, 60 * 60 * 1000);
  const exchangeLeftThisHour = Math.max(0, exchangeLimit - usedThisHour);
  const factoriesPerCenter = Math.max(1, Math.floor(C.SCIENCE_BUILD_FACTORY_COST * C.SCIENCE_TO_FACTORY_RATE));
  text +=
    `\n\n🔁 Обменять центр(ы) обратно на заводы: наука обменять [количество] (или наука обменять всё)\n` +
    `Курс: 1 центр = ${factoriesPerCenter} завода (вирты за постройку не возвращаются)\n` +
    `Доступно к обмену: ${scienceLeftToExchange} (защищено: ${C.NEWBIE_PROTECTION_SCIENCE_CENTERS}) | Осталось обменов в этот час: ${exchangeLeftThisHour}/${exchangeLimit}`;

  await ctx.send(images.withImage('science', text));
}

async function handleBuild(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await science.buildCenter(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'limit_reached') {
      await ctx.send(`⛔ Достигнут лимит научных центров (${result.limit}). Расширьте: наука расширить`);
    } else if (result.reason === 'factory_threshold') {
      await ctx.send(`⛔ Для обмена на науку нужно иметь на балансе не менее ${result.need} заводов (сейчас: ${result.have}).`);
    } else if (result.reason === 'not_enough_factories') {
      await ctx.send(`⛔ Нужно ${result.need} обычных заводов (есть: ${result.have}).`);
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(result.missing)}.`
      );
    } else {
      await ctx.send('⛔ Не удалось построить научный центр.');
    }
    return;
  }

  const drop = await events.awardDrop(ctx.senderId);
  await ctx.send(
    `🔬 НАУЧНЫЙ ЦЕНТР ПОСТРОЕН!\n${C.SCIENCE_BUILD_FACTORY_COST} заводов и ${calc.formatNumber(
      result.cost
    )} вирт было списано.\nНовый доход: +${C.SCIENCE_INCOME_PER_HOUR} вирт/час.${events.dropSuffix(drop)}`
  );
}

async function handleExpand(ctx) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  const result = await science.expandLimit(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'max_level') {
      await ctx.send('⛔ Уже максимальный уровень лимита научных центров.');
    } else if (result.reason === 'not_enough_money') {
      await ctx.send(
        `⛔ Недостаточно вирт. Нужно ${calc.formatNumber(result.cost)}, не хватает ${calc.formatNumber(
          result.missing
        )}.`
      );
    } else {
      await ctx.send('⛔ Не удалось расширить лимит.');
    }
    return;
  }

  await ctx.send(`✅ Лимит научных центров расширен до ${result.newLimit}! Потрачено: ${calc.formatNumber(result.cost)} вирт.`);
}

async function handleExchangeToFactories(ctx, countArg) {
  const player = await requireRegistered(ctx);
  if (!player) return;

  if ((countArg || '').toLowerCase() === 'всё' || (countArg || '').toLowerCase() === 'все') {
    return handleExchangeAllToFactories(ctx);
  }

  const count = parseInt(countArg, 10);
  if (!Number.isInteger(count) || count <= 0) {
    await ctx.send('⛔ Формат: наука обменять [количество] — например: наука обменять 1 (или: наука обменять всё)');
    return;
  }

  const result = await science.exchangeToFactories(ctx.senderId, count);
  if (!result.ok) {
    if (result.reason === 'hourly_limit') {
      await ctx.send(`⛔ Часовой лимит обмена науки на заводы исчерпан (${result.limit}/час). Попробуйте позже.`);
    } else if (result.reason === 'exceeds_hourly_limit') {
      await ctx.send(
        `⛔ В этот час можно обменять ещё максимум ${result.remainingThisHour} центр(ов) (лимит ${result.limit}/час). Попробуйте "наука обменять всё".`
      );
    } else if (result.reason === 'not_enough_science') {
      await ctx.send(
        `⛔ Недостаточно научных центров сверх защиты новичков. Есть: ${result.have}, порог защиты: ${result.protectedFloor}, максимум к обмену сейчас: ${result.maxExchangeable}.`
      );
    } else {
      await ctx.send('⛔ Не удалось обменять науку на заводы.');
    }
    return;
  }

  await ctx.send(
    `✅ Обменяно ${result.centersSpent} науч. центр(ов) на ${result.factoriesGained} завод(ов) (курс: 1 центр = ${result.factoriesPerCenter} завода, вирты за постройку центра не возвращаются).\n` +
      `Осталось обменов в этот час: ${result.remainingThisHour}/${result.limit}.`
  );
}

// "наука обменять всё" — меняет сразу столько центров, на сколько хватает и часового
// лимита, и самой науки сверх защиты новичков (тот же принцип, что и "обменять всё" для
// жетонов на завод/науку — см. handlers/warehouseHandlers.js).
async function handleExchangeAllToFactories(ctx) {
  const result = await science.exchangeAllToFactories(ctx.senderId);
  if (!result.ok) {
    if (result.reason === 'hourly_limit') {
      await ctx.send(`⛔ Часовой лимит обмена науки на заводы исчерпан (${result.limit}/час). Попробуйте позже.`);
    } else if (result.reason === 'not_enough_science') {
      await ctx.send(
        `⛔ Недостаточно научных центров сверх защиты новичков. Есть: ${result.have}, порог защиты: ${result.protectedFloor}.`
      );
    } else {
      await ctx.send('⛔ Не удалось обменять науку на заводы.');
    }
    return;
  }

  await ctx.send(
    `✅ Обменяно всё, на что хватило: ${result.centersSpent} науч. центр(ов) → ${result.factoriesGained} завод(ов) ` +
      `(курс: 1 центр = ${result.factoriesPerCenter} завода, вирты за постройку центра не возвращаются).\n` +
      `Осталось обменов в этот час: ${result.remainingThisHour}/${result.limit}.`
  );
}

module.exports = { handleStatus, handleBuild, handleExpand, handleExchangeToFactories, handleExchangeAllToFactories };
