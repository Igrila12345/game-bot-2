'use strict';

const commentFarm = require('../game/commentFarm');

// ctx — CommentContext от vk-io (см. bot.js: onWallReply). Это МГНОВЕННЫЙ путь начисления
// бонуса — сработает, только если у сообщества в настройках Long Poll API включён тип
// событий "Добавление комментария к записи" (см. game/commentFarm.js). Если он выключен
// (или недоступен админу), это событие просто никогда не придёт — в таком случае бонус
// всё равно найдётся и начислится через периодический опрос без Long Poll'а (см.
// game/commentFarmPoll.js), просто с задержкой до ближайшего тика.
async function handleWallReply(ctx) {
  if (!ctx.isWallComment || !ctx.isNew) return;

  const vkId = ctx.fromId;
  // Комментарии от самого сообщества (например, служебные) идут с отрицательным
  // fromId — их пропускаем, это не игрок.
  if (!vkId || vkId <= 0) return;

  if (!commentFarm.containsTrigger(ctx.text)) return;

  const postId = ctx.objectId; // wall_reply_new: object_id === post_id
  const result = await commentFarm.tryClaim(vkId, postId, ctx.text);
  if (!result.ok) {
    // not_registered / already_claimed — намеренно молча, без уведомления: это не
    // ошибка игрока, на которую нужно реагировать, а просто "бонус тут не сработал".
    return;
  }

  const replyText = commentFarm.buildRewardReplyText(result);

  // Отвечаем ПРЯМО В ВЕТКЕ КОММЕНТАРИЕВ (а не в личку) — так награду сразу видно под
  // самим комментарием, всем, без необходимости открывать личные сообщения бота.
  // ownerId берём не из ctx, а из VK_GROUP_ID (см. commentFarm.getGroupOwnerId) — вся
  // игра всегда работает с одним конкретным сообществом.
  const ownerId = commentFarm.getGroupOwnerId();
  const posted = ownerId && ctx.bot ? await commentFarm.replyInComments(ctx.bot, ownerId, postId, ctx.id, replyText) : false;

  // Если ответить в комментариях не удалось (например, у токена сообщества нет права
  // "Стена", или не задан VK_GROUP_ID) — не оставляем игрока совсем без уведомления,
  // подстраховываемся личным сообщением, как раньше.
  if (!posted && ctx.bot) {
    await ctx.bot.notifyUser(vkId, replyText).catch(() => {});
  }
}

module.exports = { handleWallReply };
