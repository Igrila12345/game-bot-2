'use strict';

const C = require('../game/constants');
const calc = require('../game/calc');
const msg = require('../utils/messages');
const bankOfLuck = require('../game/bankOfLuck');

// "банк" без аргументов — статус текущего лобби/отсчёта, или подсказка как начать раунд.
async function handleStatus(ctx) {
  const status = bankOfLuck.getStatus();

  if (!status) {
    const maxBet = await bankOfLuck.getMaxBet();
    await ctx.send(
      `🏦 БАНК УДАЧИ\n\n` +
        `Сейчас нет активного раунда.\n` +
        `Ставка от ${calc.formatNumber(C.BANK_MIN_BET)} до ${calc.formatNumber(maxBet)} вирт открывает новый раунд — присоединяйтесь: банк <сумма>\n` +
        `Нужно от ${C.BANK_MIN_PLAYERS} до ${C.BANK_MAX_PLAYERS} игроков. Чем больше ваша ставка — тем выше шанс на победу.\n\n` +
        `📜 История последних выигрышей: банк история`
    );
    return;
  }

  const lines = status.players
    .map((p, i) => {
      const chancePercent = ((p.bet / status.pot) * 100).toFixed(1);
      return `${i + 1}. ${msg.mentionLink(p.vkId, p.name || String(p.vkId))} — ${calc.formatNumber(p.bet)} вирт (шанс ${chancePercent}%)`;
    })
    .join('\n');

  const phaseLine =
    status.status === 'open'
      ? `⏳ Сбор ставок ещё ${calc.formatDuration(status.msLeft)} (или пока не наберётся ${C.BANK_MAX_PLAYERS} игроков)`
      : `🔒 Ставки закрыты! Результат через ${calc.formatDuration(status.msLeft)}`;

  await ctx.send(
    `🏦 БАНК УДАЧИ\n\n` +
      `${lines}\n\n` +
      `💰 Банк: ${calc.formatNumber(status.pot)} вирт · 👥 Игроков: ${status.players.length}/${C.BANK_MAX_PLAYERS}\n` +
      `${phaseLine}`
  );
}

async function handleBet(ctx, amountArg) {
  const result = await bankOfLuck.placeBet(ctx, amountArg);

  if (!result.ok) {
    const messages = {
      bad_bet: `⛔ Ставка должна быть от ${calc.formatNumber(C.BANK_MIN_BET)} до ${calc.formatNumber(
        result.maxBet != null ? result.maxBet : C.BANK_MAX_BET
      )} вирт. Формат: банк <сумма>`,
      not_registered: '⛔ Вы ещё не зарегистрированы. Напишите !старт',
      closed: '⛔ Ставки на этот раунд уже закрыты — идёт отсчёт до результата. Дождитесь следующего раунда.',
      already_in: '⛔ Вы уже участвуете в текущем раунде — ставка одна на игрока за раунд.',
      full: `⛔ Лобби уже заполнено (${C.BANK_MAX_PLAYERS}/${C.BANK_MAX_PLAYERS}) — дождитесь следующего раунда.`,
      not_enough_money: `⛔ Недостаточно вирт. Не хватает ${calc.formatNumber(result.missing)}.`,
    };
    await ctx.send(messages[result.reason] || '⛔ Не удалось сделать ставку.');
    return;
  }

  if (result.isNewRound) {
    await ctx.send(
      `🏦 Раунд «Банк Удачи» открыт! Ваша ставка: ${calc.formatNumber(
        Number(amountArg)
      )} вирт.\n` +
        `Нужно ещё минимум ${C.BANK_MIN_PLAYERS - 1} игрок(ов) — присоединяйтесь: банк <сумма>\n` +
        `⏳ Сбор ставок: ${calc.formatDuration(result.msLeft)} (или пока не наберётся ${C.BANK_MAX_PLAYERS} игроков)\n` +
        `Статус в любой момент: банк`
    );
    return;
  }

  const startedNow = result.reachedMax;
  await ctx.send(
    `✅ Ставка принята! Игроков: ${result.playersCount}/${C.BANK_MAX_PLAYERS}, банк: ${calc.formatNumber(
      result.pot
    )} вирт.\n` +
      (startedNow
        ? `🔒 Лобби заполнилось — ставки закрыты, результат через ${calc.formatDuration(result.msLeft)}!`
        : `Статус: банк`)
  );
}

async function handleHistory(ctx) {
  const rows = await bankOfLuck.getHistory(C.BANK_HISTORY_LIMIT);
  if (!rows.length) {
    await ctx.send('🏦 БАНК УДАЧИ — ИСТОРИЯ\n\nПока ни одного завершённого раунда.');
    return;
  }

  const lines = rows.map((r, i) => {
    const name = r.state_name || String(r.winner_vk_id);
    return (
      `${i + 1}. ${msg.mentionLink(r.winner_vk_id, name)} — выиграл ${calc.formatNumber(r.payout)} вирт ` +
      `(банк ${calc.formatNumber(r.pot)}, ${r.players_count} игроков) · ${msg.formatDateTimeMsk(r.created_at)}`
    );
  });

  await ctx.send(`🏦 БАНК УДАЧИ — ИСТОРИЯ ПОСЛЕДНИХ ${rows.length}\n\n${lines.join('\n')}`);
}

module.exports = { handleStatus, handleBet, handleHistory };
