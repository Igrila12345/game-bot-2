'use strict';

const { Keyboard } = require('vk-io');

// Казино (слоты и блэкджек) переехало из бота в VK-мини-приложение (см. api/, miniapp/).
// Старые команды (!казино, !слот, !бж и их алиасы) больше ничего не играют — только
// подсказывают, где теперь казино, и дают кнопку запуска приложения.
async function handleCasinoMoved(ctx) {
  const appId = Number(process.env.VK_APP_ID);
  const text =
    '🎰 Казино (слоты и блэкджек) переехало в мини-приложение — там анимации, удобные ставки и топы.\n' +
    'Баланс тот же, что и в боте.';

  if (!appId) {
    await ctx.send(text);
    return;
  }

  const link = `https://vk.com/app${appId}`;
  try {
    if (typeof Keyboard.applicationButton !== 'function') throw new Error('applicationButton недоступна');
    const keyboard = Keyboard.keyboard([[Keyboard.applicationButton({ label: '🎰 Открыть казино', appId })]]).inline();
    await ctx.send({ message: text, keyboard });
  } catch (err) {
    console.error('[Casino] Не удалось отправить кнопку мини-приложения, отправляю ссылкой:', err.message);
    await ctx.send(`${text}\n\nОткрыть: ${link}`);
  }
}

module.exports = { handleCasinoMoved };
