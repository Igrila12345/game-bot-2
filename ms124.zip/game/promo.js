'use strict';

const C = require('./constants');
const players = require('../db/players');
const promoDb = require('../db/promocodes');
const calc = require('./calc');

const VALID_TYPES = ['weapon', 'air_defense', 'virts', 'tokens', 'science'];

async function createPromo(code, rewardType, rewardName, rewardQuantity, maxUses, expiresHours, vipOnly) {
  if (!VALID_TYPES.includes(rewardType)) return { ok: false, reason: 'invalid_type' };
  if ((rewardType === 'weapon' && !C.WEAPONS[rewardName]) || (rewardType === 'air_defense' && !C.AIR_DEFENSE[rewardName])) {
    return { ok: false, reason: 'invalid_reward_name' };
  }

  const expiresAt = expiresHours ? new Date(Date.now() + expiresHours * 60 * 60 * 1000) : null;
  const promo = await promoDb.createPromo(
    code.toUpperCase(),
    rewardType,
    rewardName || null,
    rewardQuantity,
    maxUses,
    expiresAt,
    vipOnly
  );
  if (!promo) return { ok: false, reason: 'already_exists' };
  return { ok: true, promo };
}

async function redeem(vkId, code) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const promo = await promoDb.getPromo(code.toUpperCase());
  if (!promo) return { ok: false, reason: 'not_found' };
  if (promo.expires_at && new Date(promo.expires_at) <= new Date()) return { ok: false, reason: 'expired' };
  if (promo.used_count >= promo.max_uses) return { ok: false, reason: 'exhausted' };
  // Явное приведение к boolean — защита на случай, если vip_only когда-либо придёт не
  // строгим true/false (например, из старой записи БД или ручной правки). Раньше здесь
  // уже была верная проверка `promo.vip_only && !calc.isVipActive(player)`, но если
  // промокод был СОЗДАН без флага "vip" в последнем аргументе (см. !промо создать —
  // самая частая причина того, что промокод "для VIP" на деле доступен всем), то
  // vip_only в БД изначально false, и никакая проверка здесь это не исправит — только
  // пересоздание кода или новая команда !промо vip [код] (см. handleSetVipOnly ниже).
  if (Boolean(promo.vip_only) && !calc.isVipActive(player)) return { ok: false, reason: 'vip_only' };

  const already = await promoDb.hasRedeemed(promo.code, vkId);
  if (already) return { ok: false, reason: 'already_used' };

  switch (promo.reward_type) {
    case 'virts':
      await players.updateBalance(vkId, promo.reward_quantity);
      break;
    case 'tokens':
      await players.addTokens(vkId, promo.reward_quantity);
      break;
    case 'weapon':
      await players.addToArsenal(vkId, promo.reward_name, promo.reward_quantity);
      break;
    case 'air_defense':
      await players.addToAirDefense(vkId, promo.reward_name, promo.reward_quantity);
      break;
    case 'science': {
      // Не выдаём науку промокодом сверх личного лимита игрока.
      const player = await players.getPlayer(vkId);
      const limit = calc.currentScienceLimit(player ? player.science_limit_level : 1);
      const room = Math.max(0, limit - (player ? player.science_centers || 0 : 0));
      const granted = Math.min(promo.reward_quantity, room);
      if (granted > 0) await players.addScienceCenters(vkId, granted);
      break;
    }
    default:
      break;
  }

  await promoDb.incrementUsage(promo.code);
  await promoDb.recordRedemption(promo.code, vkId);

  return { ok: true, promo };
}

// Включить/выключить ограничение "только для VIP" у УЖЕ созданного промокода задним
// числом — без пересоздания (см. !промо vip [код] в handlers/promoHandlers.js).
// Основной сценарий использования: админ забыл добавить "vip" последним аргументом
// при создании — раньше единственным выходом было удалить код и создать заново.
async function setVipOnly(code, vipOnly) {
  const res = await promoDb.setVipOnly(code.toUpperCase(), vipOnly);
  return res;
}

module.exports = { createPromo, redeem, setVipOnly };
