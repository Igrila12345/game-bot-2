'use strict';

// ===================== БАНК УДАЧИ =====================
// Общий лотерейный банк на 2-15 игроков. Правила — см. подробный комментарий у
// C.BANK_* в game/constants.js. Коротко: первая ставка открывает раунд (окно сбора —
// BANK_JOIN_WINDOW_MS), остальные присоединяются своими ставками; когда окно истекает
// (или набрался максимум игроков) — раунд переходит в "resolving": ставки закрываются,
// идёт BANK_COUNTDOWN_MS обратного отсчёта, затем выбирается победитель (шанс
// пропорционален его ставке от банка) и выплачивается награда (банк × множитель по
// C.BANK_POT_TIERS — чем больше банк, тем выгоднее множитель).
//
// Раунд живёт В ПАМЯТИ процесса (как activeHands у блэкджека — см. game/blackjack.js) —
// это осознанный выбор для быстро идущих раундов с таймерами на секунды, а не часы. На
// случай падения/перезапуска бота посреди раунда — снапшот участников лежит в game_meta
// (C.BANK_META_KEY), и при старте bootstrapRecovery() возвращает всем ставки: пытаться
// "продолжить как было" небезопасно, т.к. неизвестно, сколько реального времени прошло,
// пока процесс был выключен (окно/отсчёт могли уже давно истечь).

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const shopDb = require('../db/shop');
const bankDb = require('../db/bankOfLuck');
const asyncLock = require('./asyncLock');
const msg = require('../utils/messages');

const LOCK_KEY = 'bank-of-luck';
const MAX_BET_META_KEY = 'bank_of_luck_max_bet_override';

// Админ может поднять/опустить максимальную ставку (!админ банкставка [сумма] / сброс) —
// например, разово провести "vip-раунд" с более крупными ставками. Храним в game_meta
// (как и другие переопределяемые настройки — см. game/factoryPriceConfig.js, тот же
// паттерн: пустая строка/нет значения = override не задан, используется дефолт из
// constants.js). BANK_MIN_BET НЕ переопределяется — просили только максимум.
async function getMaxBetOverride() {
  const raw = await shopDb.getMeta(MAX_BET_META_KEY);
  if (raw === null || raw === undefined || raw === '') return null;
  const val = parseInt(raw, 10);
  return Number.isFinite(val) && val >= C.BANK_MIN_BET ? val : null;
}

async function getMaxBet() {
  const override = await getMaxBetOverride();
  return override != null ? override : C.BANK_MAX_BET;
}

async function setMaxBetOverride(value) {
  const clean = Math.max(C.BANK_MIN_BET, Math.floor(value));
  await shopDb.setMeta(MAX_BET_META_KEY, String(clean));
  return clean;
}

async function resetMaxBetOverride() {
  await shopDb.setMeta(MAX_BET_META_KEY, '');
  return C.BANK_MAX_BET;
}

// { peerId, status: 'open'|'resolving', players: [{vkId, bet, name}], joinEndsAt, resolvesAt }
let currentRound = null;

function snapshotForMeta() {
  if (!currentRound) return null;
  return {
    peerId: currentRound.peerId,
    status: currentRound.status,
    players: currentRound.players,
    joinEndsAt: currentRound.joinEndsAt,
    resolvesAt: currentRound.resolvesAt,
  };
}

async function persist() {
  await shopDb.setMeta(C.BANK_META_KEY, currentRound ? JSON.stringify(snapshotForMeta()) : '');
}

// Вызывается один раз при старте бота (см. index.js) — см. объяснение в шапке файла.
async function bootstrapRecovery() {
  const raw = await shopDb.getMeta(C.BANK_META_KEY);
  if (!raw) return;

  let snapshot = null;
  try {
    snapshot = JSON.parse(raw);
  } catch (err) {
    // Битый JSON (не должно случаться, но не должно и падать старт бота из-за этого)
    snapshot = null;
  }

  await shopDb.setMeta(C.BANK_META_KEY, '');

  if (!snapshot || !Array.isArray(snapshot.players) || !snapshot.players.length) return;

  for (const p of snapshot.players) {
    await players.updateBalance(p.vkId, p.bet);
  }
  console.log(
    `[BankOfLuck] Раунд прерван перезапуском бота — ставки возвращены ${snapshot.players.length} игрокам.`
  );
}

// Для команды "банк" без аргументов — текущее состояние лобби/отсчёта.
function getStatus() {
  if (!currentRound) return null;
  const now = Date.now();
  const pot = currentRound.players.reduce((sum, p) => sum + p.bet, 0);
  const deadline = currentRound.status === 'open' ? currentRound.joinEndsAt : currentRound.resolvesAt;
  return {
    status: currentRound.status,
    players: currentRound.players,
    pot,
    msLeft: Math.max(0, deadline - now),
  };
}

async function placeBet(ctx, amountRaw) {
  return asyncLock.withLock(LOCK_KEY, () => placeBetLocked(ctx, amountRaw));
}

async function placeBetLocked(ctx, amountRaw) {
  const vkId = ctx.senderId;
  const amount = parseInt(amountRaw, 10);
  const maxBet = await getMaxBet();

  if (!Number.isInteger(amount) || amount < C.BANK_MIN_BET || amount > maxBet) {
    return { ok: false, reason: 'bad_bet', maxBet };
  }

  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    return { ok: false, reason: 'not_registered' };
  }

  // "Во время отсчёта ставки ставить нельзя" — отсчёт это именно фаза resolving
  // (финальные BANK_COUNTDOWN_MS секунд), фаза открытого сбора ставок (open) сюда не
  // относится, туда как раз можно присоединяться в любой момент окна.
  if (currentRound && currentRound.status === 'resolving') {
    return { ok: false, reason: 'closed' };
  }

  if (currentRound && currentRound.players.some((p) => p.vkId === vkId)) {
    return { ok: false, reason: 'already_in' };
  }

  if (currentRound && currentRound.players.length >= C.BANK_MAX_PLAYERS) {
    return { ok: false, reason: 'full' };
  }

  if (Number(player.balance) < amount) {
    return { ok: false, reason: 'not_enough_money', missing: amount - Number(player.balance) };
  }

  await players.updateBalance(vkId, -amount);

  const isNewRound = !currentRound;
  if (isNewRound) {
    currentRound = {
      peerId: ctx.peerId,
      status: 'open',
      players: [],
      joinEndsAt: Date.now() + C.BANK_JOIN_WINDOW_MS,
      resolvesAt: null,
    };
  }
  currentRound.players.push({ vkId, bet: amount, name: player.state_name });

  // Набрался максимум игроков раньше конца окна — не ждём, стартуем сразу.
  const reachedMax = currentRound.players.length >= C.BANK_MAX_PLAYERS;
  if (reachedMax) {
    currentRound.status = 'resolving';
    currentRound.resolvesAt = Date.now() + C.BANK_COUNTDOWN_MS;
  }

  await persist();

  const deadline = currentRound.status === 'open' ? currentRound.joinEndsAt : currentRound.resolvesAt;
  return {
    ok: true,
    isNewRound,
    reachedMax,
    playersCount: currentRound.players.length,
    pot: currentRound.players.reduce((sum, p) => sum + p.bet, 0),
    msLeft: Math.max(0, deadline - Date.now()),
  };
}

// Множитель к банку по его размеру — см. подробное объяснение формулы у C.BANK_POT_TIERS.
// Границы включительные (pot <= maxPot), чтобы банк РОВНО 400000 и РОВНО 600000 попадали
// именно в те уровни, что описаны в примере задания.
function potMultiplier(pot) {
  const tier = C.BANK_POT_TIERS.find((t) => pot <= t.maxPot);
  return tier ? tier.multiplier : C.BANK_POT_TIERS[C.BANK_POT_TIERS.length - 1].multiplier;
}

// Взвешенный случайный выбор: шанс игрока = его ставка / банк.
function pickWinner(list) {
  const pot = list.reduce((sum, p) => sum + p.bet, 0);
  let roll = Math.random() * pot;
  for (const p of list) {
    roll -= p.bet;
    if (roll <= 0) return p;
  }
  return list[list.length - 1]; // страховка от погрешности плавающей точки на самом краю
}

// Вызывается часто (см. game/scheduler.js — раз в секунду) и сама решает, пора ли что-то
// делать: пока время не пришло, просто ничего не делает (дешёвая проверка дат).
async function tick(bot) {
  return asyncLock.withLock(LOCK_KEY, () => tickLocked(bot));
}

async function tickLocked(bot) {
  if (!currentRound) return;
  const now = Date.now();

  if (currentRound.status === 'open' && now >= currentRound.joinEndsAt) {
    if (currentRound.players.length < C.BANK_MIN_PLAYERS) {
      const round = currentRound;
      currentRound = null;
      await persist();
      for (const p of round.players) {
        await players.updateBalance(p.vkId, p.bet);
      }
      if (bot && round.peerId) {
        await bot.sendToChat(
          round.peerId,
          `🏦 Банк Удачи не набрал минимум ${C.BANK_MIN_PLAYERS} игроков за отведённое время — ставки возвращены.`
        );
      }
      return;
    }

    currentRound.status = 'resolving';
    currentRound.resolvesAt = now + C.BANK_COUNTDOWN_MS;
    await persist();
    if (bot && currentRound.peerId) {
      const pot = currentRound.players.reduce((sum, p) => sum + p.bet, 0);
      await bot.sendToChat(
        currentRound.peerId,
        `🏦 Банк Удачи стартует! Игроков: ${currentRound.players.length}, банк: ${calc.formatNumber(pot)} вирт.\n` +
          `⏳ Результат через ${Math.round(C.BANK_COUNTDOWN_MS / 1000)} сек — ставки больше не принимаются!`
      );
    }
    return;
  }

  if (currentRound.status === 'resolving' && now >= currentRound.resolvesAt) {
    const round = currentRound;
    currentRound = null;
    await persist();

    const pot = round.players.reduce((sum, p) => sum + p.bet, 0);
    const winner = pickWinner(round.players);
    const multiplier = potMultiplier(pot);
    const payout = Math.round(pot * multiplier);

    await players.updateBalance(winner.vkId, payout);
    await bankDb.insertHistory(winner.vkId, pot, payout, round.players.length);

    if (bot && round.peerId) {
      await bot.sendToChat(
        round.peerId,
        `🎉 БАНК УДАЧИ разыгран!\n` +
          `🏆 Победитель: ${msg.mentionLink(winner.vkId, winner.name || String(winner.vkId))}\n` +
          `🏦 Банк: ${calc.formatNumber(pot)} вирт (${round.players.length} игроков) × ${multiplier} = ` +
          `${calc.formatNumber(payout)} вирт выплата!`
      );
    }
  }
}

async function getHistory(limit) {
  return bankDb.getRecentHistory(limit || C.BANK_HISTORY_LIMIT);
}

module.exports = {
  placeBet,
  getStatus,
  tick,
  getHistory,
  bootstrapRecovery,
  getMaxBet,
  setMaxBetOverride,
  resetMaxBetOverride,
};
