'use strict';

const combatDb = require('../db/combat');
const asyncLock = require('./asyncLock');

// Группы аккаунтов одного игрока, для которых введены отдельные ограничения:
//  - не более LINKED_MAX_ATTACKERS_PER_TARGET разных аккаунтов из группы могут
//    одновременно (в течение LINKED_ATTACK_WINDOW_MS) атаковать одну и ту же цель;
//  - не более LINKED_TRANSFER_DAILY_LIMIT суммарных переводов в сутки МЕЖДУ
//    аккаунтами внутри одной группы (переводы вовне группы не ограничены этим правилом).
//
// Решение по конкретному игроку: ранее уличён в игре с 10 аккаунтов, лимит клана/сервера — 6,
// лишние забанены. Оставшиеся 6 — ниже. Добавлено доп. ограничение на координированный снос
// новичков и перекачку виртов между своими же аккаунтами.
const LINKED_ACCOUNT_GROUPS = [
  [804638109, 1065679388, 563044208, 200001908920, 1124122258, 1117375544],
];

const LINKED_MAX_ATTACKERS_PER_TARGET = 2;
const LINKED_ATTACK_WINDOW_MS = 24 * 60 * 60 * 1000; // 24 часа

const LINKED_TRANSFER_DAILY_LIMIT = 100000;
const LINKED_TRANSFER_WINDOW_MS = 24 * 60 * 60 * 1000; // 24 часа

const GROUP_BY_ID = new Map();
for (const group of LINKED_ACCOUNT_GROUPS) {
  for (const id of group) {
    GROUP_BY_ID.set(Number(id), group);
  }
}

// Возвращает массив ID группы, к которой принадлежит vkId, или null, если игрок
// не состоит ни в одной сконфигурированной группе связанных аккаунтов.
function getLinkedGroup(vkId) {
  return GROUP_BY_ID.get(Number(vkId)) || null;
}

function isLinkedPair(vkIdA, vkIdB) {
  const group = getLinkedGroup(vkIdA);
  return !!group && group.includes(Number(vkIdB));
}

// Единая точка проверки лимита "не более N разных аккаунтов группы бьют одну цель".
// ВАЖНО: эту функцию обязан вызывать КАЖДЫЙ игровой механизм, который может нанести урон
// (снести заводы/иначе ударить) конкретному defenderId — обычное оружие (game/combat.js),
// робот-питомец (game/robot.js), суперробот (game/superRobot.js) и любой будущий "ещё один вид
// атаки". Раньше проверка была захардкожена только внутри combat.js, из-за чего игрок из
// сконфигурированной группы мог в обход лимита сносить одну и ту же цель роботом/суперроботом
// со всех своих аккаунтов сразу — эти атаки пишутся в ту же таблицу attacks_in_flight, что и
// обычное оружие, поэтому подсчёт корректно видит их все, если этот гейт действительно вызван.
async function enforceAttackLimit(attackerId, defenderId) {
  const group = getLinkedGroup(attackerId);
  if (!group) return { ok: true };

  const recentAttackers = await combatDb.getDistinctAttackersInWindow(
    group,
    defenderId,
    LINKED_ATTACK_WINDOW_MS
  );
  const alreadyCounted = recentAttackers.includes(Number(attackerId));
  if (!alreadyCounted && recentAttackers.length >= LINKED_MAX_ATTACKERS_PER_TARGET) {
    return { ok: false, reason: 'linked_account_limit', max: LINKED_MAX_ATTACKERS_PER_TARGET };
  }
  return { ok: true };
}

// ВАЖНО (race condition): enforceAttackLimit() сама по себе НЕ атомарна — она просто читает
// текущее состояние БД. Если несколько аккаунтов одной группы бьют по одной цели практически
// одновременно (например, скриптом/несколькими открытыми вкладками), каждый запрос может
// пройти проверку ДО того, как записи атак остальных успеют закоммититься в БД — и тогда
// лимит не сработает: все атаки "увидят", что якобы ещё никто из группы не бил, и пройдут
// параллельно. Раньше именно так и происходило.
//
// Чтобы исключить это, вызывающий код (combat.js/robot.js/superRobot.js) обязан выполнять
// ВЕСЬ путь "проверка лимита -> запись атаки в attacks_in_flight" внутри withAttackLock() —
// она ставит все атаки одной группы по одной и той же цели в строгую очередь (см.
// asyncLock.withLock), так что вторая атака физически не может начать проверку, пока первая
// не закончила (и не записала свою атаку в БД). Для игроков вне сконфигурированных групп
// это просто вызывает fn() напрямую, без каких-либо задержек/очередей.
function attackLockKey(group, defenderId) {
  return `linked-attack:${group.join(',')}:${defenderId}`;
}

async function withAttackLock(attackerId, defenderId, fn) {
  const group = getLinkedGroup(attackerId);
  if (!group) return fn();
  return asyncLock.withLock(attackLockKey(group, defenderId), fn);
}

module.exports = {
  LINKED_ACCOUNT_GROUPS,
  LINKED_MAX_ATTACKERS_PER_TARGET,
  LINKED_ATTACK_WINDOW_MS,
  LINKED_TRANSFER_DAILY_LIMIT,
  LINKED_TRANSFER_WINDOW_MS,
  getLinkedGroup,
  isLinkedPair,
  enforceAttackLimit,
  withAttackLock,
};
