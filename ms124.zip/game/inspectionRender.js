'use strict';

const Jimp = require('jimp');
const C = require('./constants');
const R = require('./renderUtils');

const CELL = 150;
const GAP = 20;
const MARGIN_SIDE = 30;
const HEADER_HEIGHT = 74;
const PADDING_TOP = 26;
const MARGIN_BOTTOM = 26;
const BORDER = 3;
const CORNER_RADIUS = 14;
const ICON_SIZE = 46;

const MARGIN_TOP = HEADER_HEIGHT + PADDING_TOP;

// Иконки не зависят от конкретного раунда — строим один раз на модуль и переиспользуем
// (Jimp.composite не мутирует источник, поэтому это безопасно для параллельных рендеров).
let normalIconPromise = null;
let anomalyIconPromise = null;

async function buildFactoryIcon() {
  const icon = new Jimp(ICON_SIZE, ICON_SIZE, R.PALETTE.icon);
  for (let x = 0; x < ICON_SIZE; x++) {
    for (let y = 0; y < ICON_SIZE; y++) {
      if (x === 0 || y === 0 || x === ICON_SIZE - 1 || y === ICON_SIZE - 1) {
        icon.setPixelColor(R.PALETTE.iconBorder, x, y);
      }
    }
  }
  R.roundCorners(icon, 0, 0, ICON_SIZE, ICON_SIZE, 8);
  return icon;
}

function getNormalIcon() {
  if (!normalIconPromise) normalIconPromise = buildFactoryIcon();
  return normalIconPromise;
}

function getAnomalyIcon() {
  if (!anomalyIconPromise) {
    anomalyIconPromise = getNormalIcon().then((normal) => normal.clone().rotate(45, true));
  }
  return anomalyIconPromise;
}

// session: { round, size, cols, anomalyIndex }
async function renderRound(session) {
  const size = session.size;
  const cols = Math.ceil(Math.sqrt(size));
  const rows = Math.ceil(size / cols);

  const width = MARGIN_SIDE * 2 + cols * CELL + (cols - 1) * GAP;
  const height = MARGIN_TOP + rows * CELL + (rows - 1) * GAP + MARGIN_BOTTOM;

  const [image, { fontTitle, fontBadge }, normalIcon, anomalyIcon] = await Promise.all([
    R.buildBackground(width, height),
    R.getFonts(),
    getNormalIcon(),
    getAnomalyIcon(),
  ]);

  // Заголовок — отдельная полоса вверху со своей высотой, сетка начинается строго
  // под ней (раньше подпись номера ячейки верхнего ряда могла наезжать на заголовок
  // в правой части рендера — отсюда и "что-то торчит в правом верхнем углу").
  R.drawHeader(image, width, HEADER_HEIGHT, `🔍 ИНСПЕКЦИЯ — раунд ${session.round}/${C.INSPECTION_ROUNDS}`, fontTitle);

  for (let i = 0; i < size; i++) {
    const col = i % cols;
    const row = Math.floor(i / cols);
    const cellX = MARGIN_SIDE + col * (CELL + GAP);
    const cellY = MARGIN_TOP + row * (CELL + GAP);

    R.drawCardWithShadow(image, cellX, cellY, CELL, CELL, R.PALETTE.cell, CORNER_RADIUS);
    R.drawFrame(image, cellX, cellY, CELL, CELL, BORDER, R.PALETTE.cellBorder);

    const icon = i === session.anomalyIndex ? anomalyIcon : normalIcon;
    const iconX = cellX + Math.round((CELL - icon.bitmap.width) / 2);
    const iconY = cellY + Math.round((CELL - icon.bitmap.height) / 2);
    image.composite(icon, iconX, iconY);

    // Номер ячейки — компактный бейдж в углу карточки вместо отдельной строки
    // над ней: не отнимает вертикальное место и никогда не пересекается с заголовком.
    await R.drawBadge(image, cellX - 6, cellY - 6, i + 1, fontBadge);
  }

  return image.getBufferAsync(Jimp.MIME_PNG);
}

module.exports = { renderRound };
