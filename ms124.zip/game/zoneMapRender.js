'use strict';

// Рендер карты войны за зоны: сетка 9x9 (как на референсной карте города), 9 именованных
// клеток подсвечены цветом зоны и подписаны владельцем/статусом защиты. Обычная логика
// каждой команды сама решает, когда перегенерировать картинку — этот модуль просто рисует
// PNG по переданному состоянию (см. game/zoneWar.js: getFullStatus()).

const Jimp = require('jimp');
const R = require('./renderUtils');

const GRID_SIZE = 9;
const CELL = 108;
const MARGIN = 18;
const HEADER_HEIGHT = 74;
const GAP = 4;

const WIDTH = MARGIN * 2 + GRID_SIZE * CELL + (GRID_SIZE - 1) * GAP;
const HEIGHT = HEADER_HEIGHT + MARGIN + GRID_SIZE * CELL + (GRID_SIZE - 1) * GAP + MARGIN;

const NEUTRAL_CELL_COLOR = 0x2a3140ff;
const NEUTRAL_BORDER = 0x3d4557ff;
const PROTECTED_OVERLAY_ALPHA = 0x00000055; // затемнение поверх цвета зоны, если она под защитой

function hexToJimpInt(hex) {
  // '#RRGGBB' -> 0xRRGGBBff (Jimp хочет RGBA как одно целое число)
  const clean = hex.replace('#', '');
  return parseInt(clean + 'ff', 16);
}

function truncate(text, max) {
  if (!text) return '';
  return text.length > max ? text.slice(0, max - 1) + '…' : text;
}

// zones: результат zoneWar.getFullStatus() — массив из 9 объектов {id, cell, name, color,
// ownerName, isProtected, protectedUntil, stakes: [...]}
async function renderMap(zones, cycleInfo) {
  const image = await R.buildBackground(WIDTH, HEIGHT);
  const { fontTitle, fontLabel, fontBadge } = await R.getFonts();

  R.drawHeader(image, WIDTH, HEADER_HEIGHT, '🗺️ ВОЙНА КЛАНОВ ЗА ЗОНЫ', fontTitle);

  const zoneByCell = new Map(zones.map((z) => [z.cell, z]));

  for (let row = 0; row < GRID_SIZE; row++) {
    for (let col = 0; col < GRID_SIZE; col++) {
      const cellNumber = row * GRID_SIZE + col + 1;
      const x = MARGIN + col * (CELL + GAP);
      const y = HEADER_HEIGHT + MARGIN + row * (CELL + GAP);
      const zone = zoneByCell.get(cellNumber);

      if (!zone) {
        R.drawCardWithShadow(image, x, y, CELL, CELL, NEUTRAL_CELL_COLOR, 6);
        R.drawFrame(image, x, y, CELL, CELL, 1, NEUTRAL_BORDER);
        image.print(
          fontLabel,
          x,
          y,
          {
            text: R.sanitizeText(`${cellNumber}`),
            alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER,
            alignmentY: Jimp.VERTICAL_ALIGN_MIDDLE,
          },
          CELL,
          CELL
        );
        continue;
      }

      const fillColor = hexToJimpInt(zone.color);
      R.drawCardWithShadow(image, x, y, CELL, CELL, fillColor, 8);
      if (zone.isProtected) {
        const overlay = new Jimp(CELL, CELL, PROTECTED_OVERLAY_ALPHA);
        R.roundCorners(overlay, 0, 0, CELL, CELL, 8);
        image.composite(overlay, x, y);
      }
      R.drawFrame(image, x, y, CELL, CELL, 2, 0x000000cc);

      const statusIcon = zone.isProtected ? '🔒' : zone.ownerName ? '⚔️' : '⚪';
      const ownerLine = zone.ownerName ? truncate(zone.ownerName, 12) : 'ничьё';

      // Три текстовых блока внутри клетки (название / владелец / текущий лидер ставок) —
      // каждый печатается в СВОЙ обрезанный по высоте холст (см. R.printBoxed), а не прямо
      // на общее изображение. Раньше длинные строки, которые Jimp переносил на вторую
      // строку (нет ограничения по высоте у обычного image.print), "протекали" за пределы
      // цветной карточки зоны прямо на клетку снизу — выглядело как наползающий текст.
      // Фиксированные боксы ниже гарантируют, что лишнее просто обрежется, а не вылезет.
      R.printBoxed(
        image,
        fontBadge,
        x + 4,
        y + 6,
        CELL - 8,
        40,
        truncate(zone.name, 11),
        Jimp.HORIZONTAL_ALIGN_CENTER
      );
      R.printBoxed(
        image,
        fontLabel,
        x + 4,
        y + CELL - 46,
        CELL - 8,
        20,
        `${statusIcon} ${ownerLine}`,
        Jimp.HORIZONTAL_ALIGN_CENTER
      );
      // Текущий лидер по ставкам (пока цикл не закрылся) — отдельной строкой ниже
      // владельца/"ничьё", только для незащищённых зон и только если есть хоть одна ставка.
      // Не путать со статусом владения: это просто "кто сейчас впереди", ownerName меняется
      // только по факту закрытия цикла (см. game/zoneWar.js: maybeResolveCycle).
      if (!zone.isProtected && zone.leadingClanName) {
        R.printBoxed(
          image,
          fontLabel,
          x + 4,
          y + CELL - 22,
          CELL - 8,
          20,
          `🏁 ${truncate(zone.leadingClanName, 12)}`,
          Jimp.HORIZONTAL_ALIGN_CENTER
        );
      }
    }
  }

  return image.getBufferAsync(Jimp.MIME_PNG);
}

module.exports = { renderMap, WIDTH, HEIGHT };
