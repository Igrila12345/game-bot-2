'use strict';

const players = require('../db/players');
const stylesDb = require('../db/styles');

// ВАЖНО: owner_vk_id/seller_vk_id — колонки BIGINT, node-postgres возвращает такие
// колонки JS-строкой (не Number). Поэтому все проверки владения ниже сравнивают через
// Number(...) === / !== Number(...) — иначе "id_из_базы" !== "тот_же_id_числом" было бы
// ВСЕГДА true/false независимо от реального совпадения (см. тот же баг и его разбор в
// game/deposits.js: withdrawEarly).

const MIN_LISTING_PRICE = 100; // минимальная цена лота на витрине, чтобы не засоряли ценой в 1 вирт

// Выдаёт игроку новый стиль (обычный, не принудительный) и сразу его экипирует —
// используется командами "!админ фото/видео @юзер" (см. handlers/adminHandlers.js).
async function grantStyle(vkId, kind, attachment) {
  const style = await stylesDb.createStyle(vkId, kind, attachment, false);
  await equipStyle(vkId, style.id, { skipOwnershipCheck: true, skipLockCheck: true });
  return style;
}

// Принудительный стиль от админа: игрок не может его снять/продать/переключиться на
// другой, пока админ явно не отменит фиксацию (см. unlockForcedStyle).
async function grantForcedStyle(vkId, kind, attachment) {
  const style = await stylesDb.createStyle(vkId, kind, attachment, true);
  await players.setActiveStyle(
    vkId,
    style.id,
    kind === 'photo' ? attachment : null,
    kind === 'video' ? attachment : null
  );
  await players.setStyleLocked(vkId, true);
  return style;
}

// Снимает принудительную фиксацию с ТЕКУЩЕГО активного стиля игрока (если он forced).
// После этого игрок снова может менять/продавать стили как обычно (сам стиль остаётся
// в его инвентаре как обычный, уже не форсированный).
async function unlockForcedStyle(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  if (!player.style_locked) {
    return { ok: false, reason: 'not_locked' };
  }

  if (player.active_style_id) {
    const style = await stylesDb.getStyleById(player.active_style_id);
    if (style && Number(style.owner_vk_id) === Number(vkId)) {
      await stylesDb.setStyleForced(style.id, false);
    }
  }
  await players.setStyleLocked(vkId, false);
  return { ok: true };
}

async function getInventory(vkId) {
  return stylesDb.getStylesByOwner(vkId);
}

// Экипирует стиль из СВОЕГО инвентаря. options используется только внутренним вызовом
// grantStyle выше (там владение и блокировка заведомо корректны).
async function equipStyle(vkId, styleId, options = {}) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  if (!options.skipLockCheck && player.style_locked) {
    return { ok: false, reason: 'locked' };
  }

  const style = await stylesDb.getStyleById(styleId);
  if (!style) return { ok: false, reason: 'not_found' };

  if (!options.skipOwnershipCheck && Number(style.owner_vk_id) !== Number(vkId)) {
    return { ok: false, reason: 'not_owner' };
  }

  await players.setActiveStyle(
    vkId,
    style.id,
    style.kind === 'photo' ? style.attachment : null,
    style.kind === 'video' ? style.attachment : null
  );
  return { ok: true, style };
}

// Снимает текущий стиль полностью (возврат к обычному профилю без кастомного фото/видео).
async function unequipStyle(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };
  if (player.style_locked) return { ok: false, reason: 'locked' };

  await players.setActiveStyle(vkId, null, null, null);
  return { ok: true };
}

// Выставляет СВОЙ стиль на витрину за вирты. Можно продавать даже сейчас экипированный
// стиль (актив после продажи будет снят автоматически при подтверждении покупки).
async function listStyle(vkId, styleId, price) {
  if (!(price >= MIN_LISTING_PRICE)) {
    return { ok: false, reason: 'price_too_low', minPrice: MIN_LISTING_PRICE };
  }

  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const style = await stylesDb.getStyleById(styleId);
  if (!style) return { ok: false, reason: 'not_found' };
  if (Number(style.owner_vk_id) !== Number(vkId)) return { ok: false, reason: 'not_owner' };
  if (style.forced) return { ok: false, reason: 'forced' };

  const existing = await stylesDb.getListingByStyleId(styleId);
  if (existing) return { ok: false, reason: 'already_listed' };

  const listing = await stylesDb.createListing(styleId, vkId, Math.round(price));
  return { ok: true, listing };
}

async function cancelListing(vkId, listingId) {
  const listing = await stylesDb.getListingById(listingId);
  if (!listing) return { ok: false, reason: 'not_found' };
  if (Number(listing.seller_vk_id) !== Number(vkId)) return { ok: false, reason: 'not_owner' };

  await stylesDb.deleteListing(listingId);
  return { ok: true };
}

async function getShowcase(limit = 30) {
  return stylesDb.getAllListings(limit);
}

// Покупка стиля с витрины: списывает вирты с покупателя, зачисляет продавцу, переносит
// владение стилем. Если продаваемый стиль был у продавца ЭКИПИРОВАН — снимаем его
// (продавец больше им не владеет, показывать чужой стиль на своём профиле нельзя).
// Новому владельцу стиль НЕ экипируется автоматически — только добавляется в инвентарь,
// экипировать нужно отдельно командой "стиль выбрать".
async function buyListing(buyerVkId, listingId) {
  const listing = await stylesDb.getListingById(listingId);
  if (!listing) return { ok: false, reason: 'not_found' };

  if (Number(listing.seller_vk_id) === Number(buyerVkId)) {
    return { ok: false, reason: 'own_listing' };
  }

  const buyer = await players.getPlayer(buyerVkId);
  if (!buyer) return { ok: false, reason: 'not_registered' };
  if ((buyer.balance || 0) < listing.price) {
    return { ok: false, reason: 'insufficient_balance', price: listing.price, have: buyer.balance || 0 };
  }

  const seller = await players.getPlayer(listing.seller_vk_id);

  await players.updateBalance(buyerVkId, -listing.price);
  await players.updateBalance(listing.seller_vk_id, listing.price);
  await stylesDb.setStyleOwner(listing.style_id, buyerVkId);
  await stylesDb.deleteListing(listingId);

  // Если продавец сейчас щеголял именно этим стилем — сбрасываем его на дефолт.
  if (seller && seller.active_style_id === listing.style_id) {
    await players.setActiveStyle(listing.seller_vk_id, null, null, null);
  }

  return {
    ok: true,
    kind: listing.kind,
    price: listing.price,
    sellerVkId: listing.seller_vk_id,
    styleId: listing.style_id,
  };
}

module.exports = {
  grantStyle,
  grantForcedStyle,
  unlockForcedStyle,
  getInventory,
  equipStyle,
  unequipStyle,
  listStyle,
  cancelListing,
  getShowcase,
  buyListing,
  MIN_LISTING_PRICE,
};
