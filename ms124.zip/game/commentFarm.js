'use strict';

// ===================== БОНУС ЗА КОММЕНТАРИЙ "ФАРМ" =====================
// Игрок пишет комментарий со словом "фарм" под постом сообщества — получает разовый
// бонус (см. C.COMMENT_FARM_* в game/constants.js). Срабатывает ДВУМЯ независимыми путями,
// оба зовут tryClaim() ниже:
//   1) Мгновенно — через VK Bots Long Poll событие wall_reply_new (см. bot.js: onWallReply,
//      handlers/commentFarmHandlers.js). Требует, чтобы в настройках сообщества (Управление →
//      Работа с API → Long Poll API → Типы событий) был включён пункт "Добавление
//      комментария к записи" — иначе VK просто не пришлёт это событие боту.
//   2) С небольшой задержкой (без Long Poll вообще) — периодический опрос комментариев
//      напрямую через VK API, см. game/commentFarmPoll.js. Работает независимо от галочки
//      выше, поэтому бонус срабатывает даже если Long Poll событие недоступно/выключено.
// tryClaim() атомарно защищён от двойного начисления (см. commentFarmClaims.tryClaim), так
// что оба пути безопасно "гоняются" за одним и тем же комментарием — начислится только раз.

const C = require('./constants');
const players = require('../db/players');
const commentFarmClaims = require('../db/commentFarmClaims');
const calc = require('./calc');
const postLikes = require('./postLikes');

// Ищем слово "фарм" как ОТДЕЛЬНОЕ слово (без учёта регистра), а не подстроку — иначе
// триггерились бы "выфармил", "фармить", "фармзона" и т.п. Границы слова — не
// кириллическая буква (или начало/конец строки) с обеих сторон; цифры/подчёркивание
// в кириллице не участвуют, поэтому обычная \b (латинская) для этого не подходит.
const FARM_WORD_RE = new RegExp(`(?:^|[^а-яёa-z])${C.COMMENT_FARM_TRIGGER_WORD}(?:[^а-яёa-z]|$)`, 'i');

function containsTrigger(text) {
  return FARM_WORD_RE.test(String(text || '').toLowerCase());
}

// vkId — автор комментария, postId — id поста (wall_reply_new: post_id), на который
// он оставлен. Возвращает { ok, reason? } либо { ok: true, virt, tokens } при успехе.
async function tryClaim(vkId, postId, commentText) {
  if (!containsTrigger(commentText)) {
    return { ok: false, reason: 'no_trigger' };
  }

  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    return { ok: false, reason: 'not_registered' };
  }

  // Атомарная проверка "уже получал бонус под этим постом" — см. комментарий в
  // db/commentFarmClaims.js: одного запроса достаточно, отдельный SELECT не нужен.
  const claimed = await commentFarmClaims.tryClaim(vkId, postId);
  if (!claimed) {
    return { ok: false, reason: 'already_claimed' };
  }

  await players.updateBalance(vkId, C.COMMENT_FARM_VIRT_REWARD);
  await players.addTokens(vkId, C.COMMENT_FARM_TOKEN_REWARD);

  return { ok: true, virt: C.COMMENT_FARM_VIRT_REWARD, tokens: C.COMMENT_FARM_TOKEN_REWARD };
}

// Текст, которым бот отвечает игроку ПРЯМО В ВЕТКЕ КОММЕНТАРИЕВ (см. replyInComments
// ниже) — сразу с суммой награды и смайлом 💸, как и должно быть видно всем в комментариях,
// а не только самому игроку в личке.
function buildRewardReplyText(result) {
  return (
    `🌾 Бонус за «${C.COMMENT_FARM_TRIGGER_WORD}» засчитан: +${calc.formatNumber(result.virt)} вирт, ` +
    `+${result.tokens} 🎫 жетонов! 💸`
  );
}

// Отвечает НЕПОСРЕДСТВЕННО в ветке комментариев (wall.createComment с reply_to_comment) —
// от имени сообщества, тем же токеном, которым бот шлёт сообщения (bot.vk, см. bot.js).
// Не переиспользуем getWallApiClient()/VK_USER_TOKEN здесь: чтение стены (wall.get,
// wall.getComments) можно делать пользовательским токеном, а вот ПУБЛИКОВАТЬ комментарий
// от имени сообщества обязан именно токен самого сообщества (community/group access
// token) с правом "Стена" — это ограничение VK API, не обходится кодом.
// ownerId нужен явно (а не берётся из ctx), т.к. вся игра всегда работает с ОДНИМ
// сообществом из VK_GROUP_ID (см. game/postLikes.js: getGroupOwnerId) — так надёжнее, чем
// доверять полю owner_id из конкретного события/ответа VK API.
async function replyInComments(bot, ownerId, postId, commentId, text) {
  if (!bot || !bot.vk || !ownerId || !postId) return false;
  try {
    await bot.vk.api.wall.createComment({
      owner_id: ownerId,
      post_id: postId,
      message: text,
      reply_to_comment: commentId,
    });
    return true;
  } catch (err) {
    console.error(
      `[CommentFarm] Не удалось ответить в комментариях (пост ${postId}, комментарий ${commentId}):`,
      err.message
    );
    return false;
  }
}

module.exports = {
  tryClaim,
  containsTrigger,
  buildRewardReplyText,
  replyInComments,
  getGroupOwnerId: postLikes.getGroupOwnerId,
};
