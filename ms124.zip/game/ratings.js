'use strict';

const C = require('./constants');
const players = require('../db/players');
const clansDb = require('../db/clans');
const clanGame = require('./clan');
const dailyRewards = require('./dailyRewards');
const economyScale = require('./economyScale');

async function distributeDailyRewards(bot) {
  const topPlayers = await players.getTopByFactories(3);
  const factoryRewards = await dailyRewards.getConfig();
  for (let i = 0; i < topPlayers.length; i++) {
    const reward = factoryRewards[i];
    if (!reward) break;
    const p = topPlayers[i];
    await players.updateBalance(p.vk_id, reward.virts);
    let weaponLine = '';
    if (reward.weapon && reward.qty > 0) {
      await players.addToArsenal(p.vk_id, reward.weapon, reward.qty);
      weaponLine = `\n⚔️ +${reward.qty} шт. «${reward.weapon}»`;
    }
    if (bot) {
      await bot
        .notifyUser(
          p.vk_id,
          `🏆 Ежедневная награда за ${reward.place} место в топе заводов!\n💰 +${reward.virts} вирт${weaponLine}`
        )
        .catch(() => {});
    }
  }

  const topClans = await clanGame.getTopClansByIncome(3);
  for (let i = 0; i < topClans.length; i++) {
    const reward = C.DAILY_CLAN_REWARDS[i];
    if (!reward) break;
    const clan = topClans[i];
    const clanFactories = Number(clan.total_factories);
    const maxVault = clanFactories * C.CLAN_VAULT_PER_FACTORY;
    // Награда = база из constants × масштаб экономики (game/economyScale.js)
    const clanVirts = economyScale.reward(reward.virts);
    await clansDb.addVault(clan.id, clanVirts, maxVault);

    if (bot) {
      const members = await clansDb.getClanMembers(clan.id);
      for (const m of members) {
        await bot
          .notifyUser(
            m.vk_id,
            `🏆 Ваш клан «${clan.name}» занял ${reward.place} место в топе кланов!\n💰 В сейф клана зачислено +${clanVirts} вирт.`
          )
          .catch(() => {});
      }
    }
  }
}

module.exports = { distributeDailyRewards };
