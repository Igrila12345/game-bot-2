'use strict';

const shopDb = require('../db/shop');

// Глобальный временный буст дохода, который запускает АДМИН на всех игроков разом
// (не путать с личным донат-баффом "доход" — тот множится персонально одному игроку).
// Применяется в game/economy.js: hourlyTick() — читается ОДИН раз за тик, а не на
// каждого игрока отдельно.
const GLOBAL_BOOST_META_KEY = 'global_income_boost';

async function getBoost() {
  const raw = await shopDb.getMeta(GLOBAL_BOOST_META_KEY);
  if (!raw) return null;
  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    return null;
  }
  if (!data.expiresAt || new Date(data.expiresAt) < new Date()) return null;
  return data;
}

async function setBoost(multiplier, minutes, label) {
  const expiresAt = new Date(Date.now() + minutes * 60 * 1000).toISOString();
  const data = { multiplier, expiresAt, label: label || null, startedAt: new Date().toISOString() };
  await shopDb.setMeta(GLOBAL_BOOST_META_KEY, JSON.stringify(data));
  return data;
}

async function clearBoost() {
  await shopDb.setMeta(GLOBAL_BOOST_META_KEY, JSON.stringify({ expiresAt: null }));
}

module.exports = { getBoost, setBoost, clearBoost };
