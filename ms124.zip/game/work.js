'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const workGame = require('./workGame');
const asyncLock = require('./asyncLock');

// Дневной лимит "работы" с учётом донат-ускорителя (доп. попытки сверх обычных
// C.WORK_MAX_PER_DAY — см. DONATE_WORK_EXTRA_* в constants.js, players.work_bonus_attempts_today).
function dailyLimit(player) {
  return C.WORK_MAX_PER_DAY + (player.work_bonus_attempts_today || 0);
}

// Дата "по игре" — всегда по московскому времени, чтобы дневной лимит сбрасывался
// ровно в 00:00 МСК (как и остальные ежедневные события, см. game/scheduler.js), а не
// в полночь по системному часовому поясу сервера (который может быть в UTC).
function todayStr() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Moscow',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date());
  const map = {};
  for (const p of parts) map[p.type] = p.value;
  return `${map.year}-${map.month}-${map.day}`; // YYYY-MM-DD
}

// Если день сменился — обнуляем дневной счётчик работ.
// work_day теперь приходит из БД как обычная строка 'YYYY-MM-DD' (см. db/pool.js,
// где отключён часовой-поясной парсинг типа DATE), поэтому сравниваем строки
// напрямую, без прогона через new Date()/toISOString() — раньше это могло
// сдвигать дату на день из-за локального часового пояса процесса.
async function ensureDayReset(player) {
  const today = todayStr();
  const storedDay = player.work_day ? String(player.work_day).slice(0, 10) : null;
  if (storedDay !== today) {
    await players.resetWorkDay(player.vk_id, today);
    player.work_count_today = 0;
    player.work_day = today;
  }
  return player;
}

function buildSession(round, roundNumber) {
  return {
    round: roundNumber,
    boxes: round.boxes,
    correctIndex: round.correctIndex,
    expiresAt: new Date(Date.now() + C.WORK_ROUND_TIMEOUT_MS).toISOString(),
  };
}

// Начинает новую сессию мини-игры "работа" (или возвращает уже идущую, если есть).
// Попытка (дневной счётчик) и кулдаун списываются сразу при старте, а не по итогу,
// чтобы нельзя было спамить попытками, угадывая коробку наугад без потерь.
// Обёрнуто в withLock по vkId (см. game/asyncLock.js): без этого быстрый двойной тап по
// кнопке "работа"/коробке (или повтор недоставленного апдейта от VK) мог запустить два
// параллельных вызова, которые читают одно и то же состояние (сессию/счётчик попыток) до
// того, как первый успеет его сохранить — раунд "плывёт", попытка может списаться дважды
// или наоборот потеряться, а игроку это ощущается как "лагает"/"обрабатывается слишком долго".
async function startWork(vkId) {
  return asyncLock.withLock(`work:${vkId}`, () => startWorkLocked(vkId));
}

async function startWorkLocked(vkId) {
  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  player = await ensureDayReset(player);

  if (player.work_session) {
    const session = player.work_session;
    const expired = session.expiresAt && new Date(session.expiresAt) < new Date();
    if (!expired) {
      const attemptsLeft = Math.max(0, dailyLimit(player) - (player.work_count_today || 0));
      return { ok: true, resumed: true, session, attemptsLeft, dailyLimitToday: dailyLimit(player) };
    }
    // Сессия протухла — считаем попытку сгоревшей и открываем возможность начать заново
    await players.setWorkSession(vkId, null);
  }

  if ((player.work_count_today || 0) >= dailyLimit(player)) {
    return { ok: false, reason: 'daily_limit', attemptsLeft: 0, dailyLimitToday: dailyLimit(player) };
  }

  if (player.last_work_time) {
    const elapsed = Date.now() - new Date(player.last_work_time).getTime();
    if (elapsed < C.WORK_COOLDOWN_MS) {
      return { ok: false, reason: 'cooldown', remainingMs: C.WORK_COOLDOWN_MS - elapsed };
    }
  }

  const round = workGame.generateRound();
  const session = buildSession(round, 1);

  await players.incrementWorkCount(vkId, todayStr()); // тратит попытку + обновляет last_work_time
  await players.setWorkSession(vkId, session);

  const attemptsLeft = dailyLimit(player) - ((player.work_count_today || 0) + 1);

  return { ok: true, resumed: false, session, attemptsLeft, dailyLimitToday: dailyLimit(player) };
}

// Обрабатывает нажатие кнопки с коробкой в текущем раунде.
// Тот же withLock по vkId, что и в startWork — см. комментарий там же.
async function pickBox(vkId, boxIndex, expectedRound) {
  return asyncLock.withLock(`work:${vkId}`, () => pickBoxLocked(vkId, boxIndex, expectedRound));
}

async function pickBoxLocked(vkId, boxIndex, expectedRound) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const attemptsLeft = Math.max(0, dailyLimit(player) - (player.work_count_today || 0));
  const dailyLimitToday = dailyLimit(player);

  const session = player.work_session;
  if (!session || Number(session.round) !== Number(expectedRound)) {
    return { ok: false, reason: 'no_session' };
  }

  if (session.expiresAt && new Date(session.expiresAt) < new Date()) {
    await players.setWorkSession(vkId, null);
    return { ok: false, reason: 'timeout', attemptsLeft, dailyLimitToday };
  }

  if (!Number.isInteger(boxIndex) || boxIndex < 0 || boxIndex >= session.boxes.length) {
    return { ok: false, reason: 'invalid_box' };
  }

  if (boxIndex !== session.correctIndex) {
    await players.setWorkSession(vkId, null);
    return { ok: false, reason: 'wrong', attemptsLeft, dailyLimitToday };
  }

  if (session.round >= C.WORK_ROUNDS) {
    await players.setWorkSession(vkId, null);
    let tokens = calc.randomWorkTokens();
    // Донат-бафф "двойные жетоны за работу" (см. DONATE_WORK_DOUBLE_* в constants.js)
    const doubled = calc.isWorkDoubleActive(player);
    if (doubled) tokens *= 2;
    // VIP отдельно удваивает награду за "работу" (см. C.VIP_WORK_INSPECTION_BONUS_MULTIPLIER) —
    // эффект независим от донат-баффа выше и складывается с ним умножением.
    const vip = calc.isVipActive(player);
    if (vip) tokens *= C.VIP_WORK_INSPECTION_BONUS_MULTIPLIER;
    const totalTokens = await players.addTokens(vkId, tokens);
    return { ok: true, status: 'completed', tokens, doubled, vip, totalTokens, attemptsLeft, dailyLimitToday };
  }

  const round = workGame.generateRound();
  const nextSession = buildSession(round, session.round + 1);
  await players.setWorkSession(vkId, nextSession);

  return { ok: true, status: 'next_round', session: nextSession, attemptsLeft, dailyLimitToday };
}

// Статус для меню "работа": сколько попыток использовано сегодня, есть ли
// незавершённая попытка (и на каком она раунде), сколько жетонов у игрока.
// Ничего не списывает и не начинает — только читает состояние.
async function getStatus(vkId) {
  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  player = await ensureDayReset(player);

  const attemptsUsed = player.work_count_today || 0;
  const dailyLimitToday = dailyLimit(player);
  const attemptsLeft = Math.max(0, dailyLimitToday - attemptsUsed);

  let activeRound = null;
  if (player.work_session) {
    const session = player.work_session;
    const expired = session.expiresAt && new Date(session.expiresAt) < new Date();
    if (!expired) activeRound = session.round;
  }

  return {
    ok: true,
    attemptsUsed,
    attemptsLeft,
    dailyLimitToday,
    activeRound,
    tokens: player.tokens || 0,
  };
}

module.exports = { startWork, pickBox, getStatus };
