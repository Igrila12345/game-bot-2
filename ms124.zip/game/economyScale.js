'use strict';

// ===================== ЕДИНЫЙ МАСШТАБ ЭКОНОМИКИ =====================
//
// Проблема, которую это решает: по мере роста игроков приходилось вручную поднимать суммы в
// десятках мест (награды за топ кланов/заводов/казино, курс фермы, цены и ассортимент
// магазина...). Теперь в constants.js лежат БАЗОВЫЕ значения (как «настроены сейчас»), а
// реальная выплата/цена = база × МАСШТАБ. Поднять всё сразу — значит поднять один множитель.
//
// Как считается масштаб:
//   • АВТО: раз в час берём медиану чистого дохода/час у топ-N игроков (без временных
//     бустов — VIP, донат-буст, радиация, штраф за лайки не учитываются, иначе индекс
//     прыгал бы от акций). Первый же замер становится «точкой отсчёта» (масштаб 1.00), так
//     что при включении ничего не меняется. Дальше масштаб = доход_топа / точка_отсчёта и
//     только РАСТЁТ (храповик) — награды не должны падать, если топ-игроков снесли в войне.
//   • РУЧНОЙ override: !админ экономика [число] — жёстко задаёт масштаб (можно и меньше 1);
//     !админ экономика авто — вернуть автоматику; !админ экономика сброс — заново принять
//     текущую экономику за 1.00.
//
// Использование в коде (всё синхронное — читает кэш в памяти, который обновляется
// load() при старте, раз в 5 минут планировщиком и сразу после админ-команд):
//   economyScale.reward(30000)   — награда/приз (база × масштаб, «красивое» округление)
//   economyScale.shopPrice(300)  — цена в магазине оружия/ПВО
//   economyScale.assortmentFactor() — во сколько раз шире ассортимент/больше штук в магазине

const shopDb = require('../db/shop');

const META_AUTO = 'economy_scale_auto';
const META_OVERRIDE = 'economy_scale_override';
const META_BASELINE = 'economy_scale_baseline';

const CONFIG = {
  TOP_N: 10, // сколько топ-игроков по доходу участвует в замере (берётся медиана)
  SCALE_MIN: 0.1,
  SCALE_MAX: 100,
  STEP: 0.05, // авто-масштаб округляется до шага 0.05, чтобы не дёргаться на каждой мелочи
  // Как сильно масштаб влияет на разные части (множитель = масштаб ^ показатель):
  REWARD_EXPONENT: 1, // награды растут 1:1 с экономикой
  SHOP_PRICE_EXPONENT: 1, // цены магазина оружия/ПВО — тоже 1:1 (поставьте >1, чтобы магазин «душил» деньги сильнее)
  SHOP_ASSORTMENT_EXPONENT: 0.5, // ширина ассортимента и число штук растут медленнее цены (√масштаба)
};

const state = { auto: 1, override: null, baseline: null };

function clamp(x, lo, hi) {
  return Math.min(hi, Math.max(lo, x));
}

async function load() {
  const [a, o, b] = await Promise.all([
    shopDb.getMeta(META_AUTO),
    shopDb.getMeta(META_OVERRIDE),
    shopDb.getMeta(META_BASELINE),
  ]);
  const auto = parseFloat(a);
  state.auto = Number.isFinite(auto) && auto >= 1 ? auto : 1;
  const ov = parseFloat(o);
  state.override = Number.isFinite(ov) && ov > 0 ? ov : null;
  const base = parseFloat(b);
  state.baseline = Number.isFinite(base) && base > 0 ? base : null;
}

// Текущий эффективный масштаб (override, иначе авто).
function getScale() {
  const raw = state.override != null ? state.override : state.auto;
  return clamp(raw, CONFIG.SCALE_MIN, CONFIG.SCALE_MAX);
}

// Округление до 3 значащих цифр (274 318 -> 274 000), чтобы цены/награды выглядели «человечно».
function niceRound(n) {
  n = Math.round(n);
  if (n < 1000) return n;
  const step = Math.pow(10, String(n).length - 3);
  return Math.round(n / step) * step;
}

function scaleValue(base, exponent) {
  const mult = Math.pow(getScale(), exponent);
  // При масштабе 1.00 отдаём базу как есть (без «красивого» округления) — иначе, например,
  // цена 11250 превратилась бы в 11300 просто от включения системы.
  if (mult === 1) return Math.round(base);
  return niceRound(base * mult);
}

function reward(base) {
  return scaleValue(base, CONFIG.REWARD_EXPONENT);
}

function shopPrice(base) {
  return scaleValue(base, CONFIG.SHOP_PRICE_EXPONENT);
}

// >= 1. Магазин умножает на него разброс «сколько видов» и «сколько штук».
function assortmentFactor() {
  return Math.max(1, Math.pow(getScale(), CONFIG.SHOP_ASSORTMENT_EXPONENT));
}

// ===================== ЗАМЕР ЭКОНОМИКИ =====================

function median(sortedDesc) {
  const n = sortedDesc.length;
  const mid = Math.floor(n / 2);
  return n % 2 ? sortedDesc[mid] : (sortedDesc[mid - 1] + sortedDesc[mid]) / 2;
}

// Медиана «чистого» дохода/час у топ-N игроков. Возвращает null, если игроков с доходом нет.
async function measureTopIncome() {
  // Ленивые require — чтобы не ловить циклические зависимости при загрузке модулей.
  const players = require('../db/players');
  const calc = require('./calc');

  const all = await players.getAllActivePlayers();
  const incomes = all
    .map((p) =>
      calc.incomePerHour({
        ...p,
        vip_until: null,
        income_boost_until: null,
        radiation_until: null,
        like_penalty_active: false,
      })
    )
    .filter((x) => x > 0)
    .sort((a, b) => b - a)
    .slice(0, CONFIG.TOP_N);

  if (!incomes.length) return null;
  return median(incomes);
}

async function saveAuto(value) {
  state.auto = value;
  await shopDb.setMeta(META_AUTO, String(value));
}

// Вызывается раз в час планировщиком. Возвращает { measured, baseline, auto, changed }.
async function recalcAuto() {
  const measured = await measureTopIncome();
  if (measured == null) return { measured: null, baseline: state.baseline, auto: state.auto, changed: false };

  if (state.baseline == null) {
    // Первый замер: принимаем нынешнюю экономику за 1.00 — включение ничего не меняет.
    state.baseline = measured;
    await shopDb.setMeta(META_BASELINE, String(Math.round(measured)));
    await saveAuto(1);
    return { measured, baseline: state.baseline, auto: 1, changed: true };
  }

  const raw = measured / state.baseline;
  const stepped = Math.round(raw / CONFIG.STEP) * CONFIG.STEP;
  const next = Math.round(clamp(Math.max(state.auto, stepped, 1), 1, CONFIG.SCALE_MAX) * 100) / 100;
  const changed = next !== state.auto;
  if (changed) await saveAuto(next);
  return { measured, baseline: state.baseline, auto: state.auto, changed };
}

// ===================== АДМИН-УПРАВЛЕНИЕ =====================

async function setOverride(value) {
  const clean = Math.round(clamp(value, CONFIG.SCALE_MIN, CONFIG.SCALE_MAX) * 100) / 100;
  state.override = clean;
  await shopDb.setMeta(META_OVERRIDE, String(clean));
  return clean;
}

async function clearOverride() {
  state.override = null;
  await shopDb.setMeta(META_OVERRIDE, '');
}

// Принять текущую экономику за 1.00: пересчитать точку отсчёта, обнулить авто и override.
async function resetBaseline() {
  const measured = await measureTopIncome();
  await clearOverride();
  await saveAuto(1);
  if (measured != null) {
    state.baseline = measured;
    await shopDb.setMeta(META_BASELINE, String(Math.round(measured)));
  } else {
    state.baseline = null;
    await shopDb.setMeta(META_BASELINE, '');
  }
  return { baseline: state.baseline };
}

function getInfo() {
  return {
    scale: getScale(),
    auto: state.auto,
    override: state.override,
    baseline: state.baseline,
    rewardMult: Math.pow(getScale(), CONFIG.REWARD_EXPONENT),
    shopPriceMult: Math.pow(getScale(), CONFIG.SHOP_PRICE_EXPONENT),
    assortmentFactor: assortmentFactor(),
  };
}

module.exports = {
  CONFIG,
  load,
  getScale,
  getInfo,
  reward,
  shopPrice,
  assortmentFactor,
  niceRound,
  measureTopIncome,
  recalcAuto,
  setOverride,
  clearOverride,
  resetBaseline,
};
