'use strict';

// ===================== РАСХОДУЕМЫЕ ДОНАТ-ТОВАРЫ =====================
// Всё, что тут выдаётся, — сгорает: мгновенные ускорители тратятся сразу, дневные баффы
// истекают через фиксированное время (см. DONATE_* в game/constants.js). Оплата и выдача,
// как и весь остальной донат в этом проекте, — ВРУЧНУЮ через администратора после получения
// денег (см. handlers/adminHandlers.js: новые команды сброс/финиш/работа/обмен/доход/щит/
// дубль/ускорение/акция).

const C = require('./constants');
const players = require('../db/players');
const production = require('../db/production');
const shopDb = require('../db/shop');
const calc = require('./calc');
const gameDate = require('./gameDate');

// ===================== МГНОВЕННЫЕ УСКОРИТЕЛИ =====================

// Мгновенный сброс кулдауна робота/суперробота/дозора — просто обнуляем last_*_at.
async function resetRobotCooldown(vkId) {
  await players.setRobotLastFarm(vkId, null);
  await players.setRobotLastSend(vkId, null);
}

async function resetRobotAttackCooldown(vkId) {
  await players.setRobotLastAttack(vkId, null);
}

async function resetSuperRobotCooldown(vkId) {
  await players.setSuperRobotLastAttack(vkId, null);
}

async function resetPatrolCooldown(vkId) {
  await players.resetPatrolLastAt(vkId);
}

// Мгновенное завершение всего текущего (ещё не собранного) производства. Возвращает
// количество затронутых записей — собрать оружие всё равно нужно обычной командой.
async function finishProductionNow(vkId) {
  const count = await production.finishAllNow(vkId);
  return { count };
}

// Доп. попытки "работы" сверх обычного дневного лимита — сгорают вместе с обычным
// лимитом при смене дня (см. game/work.js: dailyLimit()/ensureDayReset()).
async function grantWorkExtraAttempts(vkId, amount = C.DONATE_WORK_EXTRA_ATTEMPTS) {
  const total = await players.addWorkBonusAttempts(vkId, amount);
  return { granted: amount, total };
}

// Снятие сегодняшнего лимита обмена жетонов на завод/науку — просто обнуляем
// сегодняшние счётчики (тот же эффект, что и естественная смена дня по МСК).
async function liftExchangeLimitsToday(vkId) {
  const today = gameDate.todayStr();
  await players.resetExchangeFactoryDay(vkId, today);
  await players.resetExchangeScienceDay(vkId, today);
}

// ===================== СТРИК ДНЕВНЫХ БАФФОВ =====================
// Вызывается КАЖДЫЙ раз при выдаче дневного баффа (доход/щит/дубль/ускорение).
// Стрик считается по МСК-дате (см. gameDate.todayStr): та же дата — стрик не растёт
// повторно (но бонус всё равно применяется), день в день подряд — +1, был пропуск —
// сброс на 1. Возвращает { streak, bonusMs } — бонусное время сверх заявленной
// длительности (капается DONATE_STREAK_MAX_BONUS_HOURS), которое вызывающий код
// прибавляет к длительности покупаемого баффа.
async function touchStreak(vkId, player) {
  const today = gameDate.todayStr();
  const lastDate = player.donate_streak_date ? String(player.donate_streak_date).slice(0, 10) : null;
  let streak = player.donate_streak || 0;

  if (lastDate !== today) {
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const yesterdayStr = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Moscow' }).format(yesterday);
    streak = lastDate === yesterdayStr ? streak + 1 : 1;
    await players.setDonateStreak(vkId, streak, today);
  }

  const bonusHours = Math.min((streak - 1) * C.DONATE_STREAK_BONUS_HOURS_PER_DAY, C.DONATE_STREAK_MAX_BONUS_HOURS);
  return { streak, bonusMs: bonusHours * 60 * 60 * 1000 };
}

function extendUntil(currentUntil, addMs) {
  const now = Date.now();
  const base = currentUntil && new Date(currentUntil).getTime() > now ? new Date(currentUntil).getTime() : now;
  return new Date(base + addMs);
}

// ===================== ДНЕВНЫЕ БАФФЫ =====================

// mult — 1.5 или 2 (см. DONATE_INCOME_BOOST_PRICE_RUB_X15 / _X2 в constants.js)
async function grantIncomeBoost(vkId, mult, hours = C.DONATE_INCOME_BOOST_DURATION_HOURS) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const { streak, bonusMs } = await touchStreak(vkId, player);
  const until = extendUntil(player.income_boost_until, hours * 60 * 60 * 1000 + bonusMs);
  await players.setIncomeBoost(vkId, until, mult);
  return { ok: true, until, mult, streak, bonusMs };
}

// Щит: защищает заводы от НЕядерного оружия (см. game/combat.js, game/robot.js,
// game/superRobot.js) — ядерное оружие щит намеренно не блокирует.
async function grantShield(vkId, days = C.DONATE_SHIELD_DURATION_DAYS) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const { streak, bonusMs } = await touchStreak(vkId, player);
  const until = extendUntil(player.shield_until, days * 24 * 60 * 60 * 1000 + bonusMs);
  await players.setShieldUntil(vkId, until);
  return { ok: true, until, streak, bonusMs };
}

async function grantWorkDouble(vkId, hours = C.DONATE_WORK_DOUBLE_DURATION_HOURS) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const { streak, bonusMs } = await touchStreak(vkId, player);
  const until = extendUntil(player.work_double_until, hours * 60 * 60 * 1000 + bonusMs);
  await players.setWorkDoubleUntil(vkId, until);
  return { ok: true, until, streak, bonusMs };
}

async function grantFarmBoost(vkId, hours = C.DONATE_FARM_BOOST_DURATION_HOURS) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  // Фиксируем накопленное на ферме ДО начала буста и "перевзводим" точку отсчёта на
  // текущий момент (farm_since_at = now). Без этого сегментный расчёт в game/farm.js:
  // computeLiveState() не знает, КОГДА начался буст, и мог бы задним числом применить
  // ускоренную ставку ко всему уже накопленному интервалу добычи, а не только к части
  // после покупки — что было бы читом.
  const farm = require('./farm');
  const live = await farm.settleFarm(vkId, player);
  if (player.farm_enabled) {
    await players.setFarmState(vkId, { enabled: true, balance: live.balance, sinceAt: new Date() });
  }

  const { streak, bonusMs } = await touchStreak(vkId, player);
  const fresh = await players.getPlayer(vkId);
  const until = extendUntil(fresh.farm_boost_until, hours * 60 * 60 * 1000 + bonusMs);
  await players.setFarmBoostUntil(vkId, until);
  return { ok: true, until, streak, bonusMs };
}

// x2 к награде за попадание по мировому боссу — намеренно БЕЗ стрика и БЕЗ гибкой
// длительности (в отличие от остальных дневных баффов выше): продаётся строго на
// DONATE_BOSS_DOUBLE_DURATION_DAYS (1 день) как разовое усиление под конкретный забег.
async function grantBossDouble(vkId, days = C.DONATE_BOSS_DOUBLE_DURATION_DAYS) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const until = extendUntil(player.boss_double_until, days * 24 * 60 * 60 * 1000);
  await players.setBossDoubleUntil(vkId, until);
  return { ok: true, until };
}

// ===================== НОВЫЕ ВРЕМЕННЫЕ ДОНАТ-ТОВАРЫ =====================
// Отдельная, более "лёгкая" линейка баффов — БЕЗ стрика (см. touchStreak выше), продлеваются
// сверху остатка так же, как остальной донат (см. extendUntil).

// 😎 Смайлик-статус: чисто косметика, emoji/короткий тег рядом с ником в профиле. Каждая новая
// выдача полностью заменяет emoji (не суммируется), но срок продлевается сверху остатка, если
// уже был активен ЛЮБОЙ смайлик.
async function grantEmojiTag(vkId, emoji, days = C.DONATE_EMOJI_TAG_DURATION_DAYS) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const currentUntil = calc.isEmojiTagActive(player) ? player.emoji_tag_until : null;
  const until = extendUntil(currentUntil, days * 24 * 60 * 60 * 1000);
  await players.setEmojiTag(vkId, emoji, until);
  return { ok: true, emoji, until };
}

// 🎓 x2 научных центров при обмене жетонов на науку (см. game/warehouse.js: exchangeForScience)
async function grantScienceBoost(vkId, hours = C.DONATE_SCIENCE_BOOST_DURATION_HOURS) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const until = extendUntil(player.science_boost_until, hours * 60 * 60 * 1000);
  await players.setScienceBoostUntil(vkId, until);
  return { ok: true, until };
}

// 🍀 x2 доля вора от украденного при "краже" (см. game/steal.js: attemptSteal)
async function grantStealBoost(vkId, hours = C.DONATE_STEAL_BOOST_DURATION_HOURS) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const until = extendUntil(player.steal_boost_until, hours * 60 * 60 * 1000);
  await players.setStealBoostUntil(vkId, until);
  return { ok: true, until };
}

// 🎯 x2 награда (вирты и жетоны) за "дозор" (см. game/patrol.js: runPatrol)
async function grantPatrolBoost(vkId, hours = C.DONATE_PATROL_BOOST_DURATION_HOURS) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const until = extendUntil(player.patrol_boost_until, hours * 60 * 60 * 1000);
  await players.setPatrolBoostUntil(vkId, until);
  return { ok: true, until };
}

// 🔍 x2 награда за успешную "инспекцию" (см. game/inspection.js), стакается с VIP-бонусом.
async function grantInspectionBoost(vkId, hours = C.DONATE_INSPECTION_BOOST_DURATION_HOURS) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const until = extendUntil(player.inspection_boost_until, hours * 60 * 60 * 1000);
  await players.setInspectionBoostUntil(vkId, until);
  return { ok: true, until };
}

// ===================== ЕЖЕДНЕВНОЕ ОКНО ПРЕДЛОЖЕНИЯ (FLASH-АКЦИЯ) =====================
// Одна общая акция на всех игроков (не персональное состояние) — хранится в game_meta
// через db/shop.js: getMeta/setMeta. Реальная продажа всё равно идёт вручную через
// администратора (как и весь донат в проекте) — акция лишь показывает скидку и таймер,
// админ применяет её сам при выдаче товара после оплаты.
async function setFlashOffer(itemLabel, discountPercent, minutes) {
  const expiresAt = new Date(Date.now() + minutes * 60 * 1000);
  const offer = { itemLabel, discountPercent, expiresAt: expiresAt.toISOString() };
  await shopDb.setMeta(C.FLASH_OFFER_META_KEY, JSON.stringify(offer));
  return offer;
}

async function clearFlashOffer() {
  await shopDb.setMeta(C.FLASH_OFFER_META_KEY, null);
}

async function getFlashOffer() {
  const raw = await shopDb.getMeta(C.FLASH_OFFER_META_KEY);
  if (!raw) return null;
  let offer;
  try {
    offer = JSON.parse(raw);
  } catch {
    return null;
  }
  if (!offer || !offer.expiresAt || new Date(offer.expiresAt) <= new Date()) return null;
  return offer;
}

module.exports = {
  resetRobotCooldown,
  resetRobotAttackCooldown,
  resetSuperRobotCooldown,
  resetPatrolCooldown,
  finishProductionNow,
  grantWorkExtraAttempts,
  liftExchangeLimitsToday,
  touchStreak,
  grantIncomeBoost,
  grantShield,
  grantWorkDouble,
  grantFarmBoost,
  grantBossDouble,
  grantEmojiTag,
  grantScienceBoost,
  grantStealBoost,
  grantPatrolBoost,
  grantInspectionBoost,
  setFlashOffer,
  clearFlashOffer,
  getFlashOffer,
};
