'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const economy = require('./economy');
const scienceExchangeDb = require('../db/scienceExchange');

async function buildCenter(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const limit = calc.currentScienceLimit(player.science_limit_level);
  if ((player.science_centers || 0) >= limit) {
    return { ok: false, reason: 'limit_reached', limit };
  }

  // Порог входа растёт 1:1 вместе с уже построенными центрами (не ниже пола
  // SCIENCE_BUILD_MIN_FACTORIES) — см. calc.scienceBuildFactoryThreshold. Например, имея
  // 500 центров, для 501-го нужно держать на балансе уже 500 заводов, а не фиксированные 20.
  const factoryThreshold = calc.scienceBuildFactoryThreshold(player.science_centers || 0);
  if (player.factories < factoryThreshold) {
    return {
      ok: false,
      reason: 'factory_threshold',
      need: factoryThreshold,
      have: player.factories,
    };
  }

  if (player.factories < C.SCIENCE_BUILD_FACTORY_COST) {
    return {
      ok: false,
      reason: 'not_enough_factories',
      need: C.SCIENCE_BUILD_FACTORY_COST,
      have: player.factories,
    };
  }

  // Цена растёт каждые SCIENCE_BUILD_COST_STEP_SIZE построенных центров (см. calc.scienceBuildCost)
  const cost = calc.scienceBuildCost(player.science_centers || 0);
  if (Number(player.balance) < cost) {
    return {
      ok: false,
      reason: 'not_enough_money',
      cost,
      missing: cost - Number(player.balance),
    };
  }

  await players.decrementFactories(vkId, C.SCIENCE_BUILD_FACTORY_COST);
  await players.updateBalance(vkId, -cost);
  await players.addScienceCenters(vkId, 1);

  // Наука тоже считается в пороге «бонуса новичка» (1 наука = 10 заводов, см.
  // calc.newbieEquivalentFactories) — отключаем бонус сразу, если этот центр стал
  // порогом. Прочие способы получить науку (склад, аукцион, ивенты, кража) отдельно не
  // перехватываются: их подберёт ближайший часовой тик (economy.syncNewbieBoostFlag).
  const after = await players.getPlayer(vkId);
  await economy.syncNewbieBoostFlag(after);

  return { ok: true, cost };
}

async function expandLimit(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const currentLevel = player.science_limit_level || 1;
  const nextRow = C.SCIENCE_LIMIT_LEVELS.find((l) => l.level === currentLevel + 1);
  if (!nextRow) {
    return { ok: false, reason: 'max_level' };
  }

  if (Number(player.balance) < nextRow.cost) {
    return { ok: false, reason: 'not_enough_money', cost: nextRow.cost, missing: nextRow.cost - Number(player.balance) };
  }

  await players.updateBalance(vkId, -nextRow.cost);
  await players.setScienceLimitLevel(vkId, nextRow.level);

  return { ok: true, newLevel: nextRow.level, newLimit: nextRow.limit, cost: nextRow.cost };
}

// Обратный обмен: научные центры -> заводы. Курс — доля SCIENCE_TO_FACTORY_RATE от цены
// постройки в заводах (SCIENCE_BUILD_FACTORY_COST), округление вниз, не меньше 1 завода
// за центр. Вирты, потраченные при постройке центра, НЕ возвращаются — обмен обратно всегда
// в убыток, чтобы не превращать науку в бесплатный обход часового лимита постройки заводов.
// Нельзя опускаться ниже порога защиты новичков по науке, и обмен ограничен ОТДЕЛЬНЫМ
// (не тем же самым, что и постройка) скользящим часовым лимитом — 10/час всем, 20/час VIP
// (см. C.SCIENCE_TO_FACTORY_LIMIT_PER_HOUR / VIP_EXCHANGE_LIMIT_MULTIPLIER; было 6 в день).
async function exchangeToFactories(vkId, count) {
  if (!Number.isInteger(count) || count <= 0) {
    return { ok: false, reason: 'invalid_quantity' };
  }

  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const limit = calc.isVipActive(player)
    ? C.SCIENCE_TO_FACTORY_LIMIT_PER_HOUR * C.VIP_EXCHANGE_LIMIT_MULTIPLIER
    : C.SCIENCE_TO_FACTORY_LIMIT_PER_HOUR;
  const usedRecently = await scienceExchangeDb.countRecentExchanges(vkId, 60 * 60 * 1000);
  const remainingThisHour = limit - usedRecently;
  if (remainingThisHour <= 0) {
    return { ok: false, reason: 'hourly_limit', limit };
  }
  if (count > remainingThisHour) {
    return { ok: false, reason: 'exceeds_hourly_limit', remainingThisHour, limit, requested: count };
  }

  const available = (player.science_centers || 0) - C.NEWBIE_PROTECTION_SCIENCE_CENTERS;
  if (available < count) {
    return {
      ok: false,
      reason: 'not_enough_science',
      have: player.science_centers || 0,
      protectedFloor: C.NEWBIE_PROTECTION_SCIENCE_CENTERS,
      maxExchangeable: Math.max(0, available),
    };
  }

  const factoriesPerCenter = Math.max(1, Math.floor(C.SCIENCE_BUILD_FACTORY_COST * C.SCIENCE_TO_FACTORY_RATE));
  const factoriesGained = factoriesPerCenter * count;

  await players.decrementScienceCenters(vkId, count);
  await players.addFactories(vkId, factoriesGained, false);

  // Один лог-ряд за каждый обменянный центр — так лимит "10/час" считает именно центры,
  // а не вызовы команды (обменять 5 разом = использовано 5 из часового лимита).
  for (let i = 0; i < count; i++) {
    await scienceExchangeDb.logExchange(vkId);
  }

  return {
    ok: true,
    centersSpent: count,
    factoriesGained,
    factoriesPerCenter,
    remainingThisHour: remainingThisHour - count,
    limit,
  };
}

// Массовый обмен ("наука обменять всё") — меняет СРАЗУ столько центров, на сколько хватает
// и часового лимита, и самой науки сверх защиты новичков (тот же принцип, что и
// warehouse.exchangeForFactoryBulk/exchangeForScienceBulk для обмена жетонов). Никогда не
// делает "частичный" вызов exchangeToFactories с числом больше возможного — сразу считает
// точный максимум и обменивает его целиком одним вызовом.
async function exchangeAllToFactories(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };

  const limit = calc.isVipActive(player)
    ? C.SCIENCE_TO_FACTORY_LIMIT_PER_HOUR * C.VIP_EXCHANGE_LIMIT_MULTIPLIER
    : C.SCIENCE_TO_FACTORY_LIMIT_PER_HOUR;
  const usedRecently = await scienceExchangeDb.countRecentExchanges(vkId, 60 * 60 * 1000);
  const remainingThisHour = limit - usedRecently;
  if (remainingThisHour <= 0) {
    return { ok: false, reason: 'hourly_limit', limit };
  }

  const available = (player.science_centers || 0) - C.NEWBIE_PROTECTION_SCIENCE_CENTERS;
  if (available <= 0) {
    return {
      ok: false,
      reason: 'not_enough_science',
      have: player.science_centers || 0,
      protectedFloor: C.NEWBIE_PROTECTION_SCIENCE_CENTERS,
      maxExchangeable: 0,
    };
  }

  const count = Math.min(remainingThisHour, available);
  return exchangeToFactories(vkId, count);
}

module.exports = { buildCenter, expandLimit, exchangeToFactories, exchangeAllToFactories };
