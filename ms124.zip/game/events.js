'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const gameMeta = require('../db/shop'); // getMeta/setMeta живут в db/shop.js (общая таблица game_meta)

const META_ACTIVE_EVENT = 'active_event';
const META_SHOP_OPEN = 'event_shop_open';

// ===================== АКТИВНЫЙ СЕЗОН =====================

// Возвращает объект сезона из C.EVENT_SEASONS или null, если ивент выключен.
async function getActiveSeason() {
  const key = await gameMeta.getMeta(META_ACTIVE_EVENT);
  return key && C.EVENT_SEASONS[key] ? C.EVENT_SEASONS[key] : null;
}

// key — один из ключей C.EVENT_SEASONS ('winter'/'spring'/'summer'/'autumn') либо null,
// чтобы выключить ивент (валюта за действия капать перестаёт, но уже накопленная остаётся).
async function setActiveSeason(key) {
  if (key === null) {
    await gameMeta.setMeta(META_ACTIVE_EVENT, '');
    return null;
  }
  if (!C.EVENT_SEASONS[key]) return null;
  await gameMeta.setMeta(META_ACTIVE_EVENT, key);
  return C.EVENT_SEASONS[key];
}

function findSeasonKey(arg) {
  const lower = (arg || '').toLowerCase();
  const aliases = {
    зима: 'winter',
    зиму: 'winter',
    winter: 'winter',
    весна: 'spring',
    весну: 'spring',
    spring: 'spring',
    лето: 'summer',
    summer: 'summer',
    осень: 'autumn',
    autumn: 'autumn',
  };
  return aliases[lower] || null;
}

// ===================== НАЧИСЛЕНИЕ ВАЛЮТЫ ЗА ДЕЙСТВИЯ =====================

// Вызывается из хендлеров после УСПЕШНОГО игрового действия (постройка завода, постройка
// научного центра, сбор ежедневного бонуса, атака другого игрока). Если сезон не активен —
// ничего не делает и возвращает null. Иначе начисляет случайное количество валюты сезона
// (C.EVENT_DROP_MIN..C.EVENT_DROP_MAX) и возвращает {season, amount} для уведомления игрока.
async function awardDrop(vkId) {
  const season = await getActiveSeason();
  if (!season) return null;

  const amount = calc.randomInt(C.EVENT_DROP_MIN, C.EVENT_DROP_MAX);
  await players.addEventCurrency(vkId, amount);
  return { season, amount };
}

// Короткая приписка к сообщению об успешном действии, например: "\n☀️ +2 (Лето)".
// Ничего не возвращает (пустую строку), если ивент не активен — вызывающему коду не нужно
// самому проверять активность ивента на каждом месте вызова.
function dropSuffix(drop) {
  if (!drop) return '';
  return `\n${drop.season.emoji} +${drop.amount} (${drop.season.name})`;
}

// ===================== ИВЕНТ-МАГАЗИН =====================
// Раньше товары ивент-магазина были жёстко зашиты в SHOP_ITEMS (3 штуки: завод/наука/вип).
// Теперь список НАСТРАИВАЕТСЯ администратором в рантайме (!админ ивентприз — см.
// handlers/adminHandlers.js) и хранится как JSON в game_meta (db/shop.js: getMeta/setMeta,
// та же таблица, что и META_ACTIVE_EVENT/META_SHOP_OPEN выше) — без миграции схемы БД.
// Каждый товар — { key, title, price, rewardType, amount } — rewardType определяет, ЧТО именно
// начисляет покупка (см. REWARD_TYPES ниже), amount — "доза" за 1 купленную единицу (для
// каунтабельных призов типа завода это обычно 1, для вип/майнера — дни, и т.д.), price — цена в
// ивент-валюте за 1 единицу. Админ может добавить/поменять/удалить ЛЮБОЙ товар, включая вип,
// майнер (в т.ч. навсегда), суперробота, доп. слоты бизнеса/донат-бизнеса, вирты и жетоны
// напрямую — то есть буквально любой значимый предмет из игры.

async function isShopOpen() {
  const v = await gameMeta.getMeta(META_SHOP_OPEN);
  return v === '1';
}

async function setShopOpen(open) {
  await gameMeta.setMeta(META_SHOP_OPEN, open ? '1' : '0');
}

const META_SHOP_ITEMS = 'event_shop_items';

// Реестр типов наград: aliases — как админ называет тип в команде (!админ ивентприз добавить),
// needsAmount — нужно ли указывать "дозу" (для майнера-навсегда, например, не нужно — он либо
// есть, либо нет), unit — подпись количества для автогенерации title, maxQtyPerPurchase —
// сколько максимум единиц можно взять ЗА ОДНУ покупку (для разовых/навсегда — 1).
const REWARD_TYPES = {
  virts: {
    aliases: ['вирты', 'вирт', 'virts'],
    needsAmount: true,
    unit: 'вирт',
    autoTitle: (amount) => `💰 ${calc.formatNumber(amount)} вирт`,
  },
  tokens: {
    aliases: ['жетоны', 'жетон', 'tokens'],
    needsAmount: true,
    unit: 'жетонов',
    autoTitle: (amount) => `🎫 ${calc.formatNumber(amount)} жетонов`,
  },
  science: {
    aliases: ['наука', 'science'],
    needsAmount: true,
    unit: 'науч. центров',
    autoTitle: (amount) => `🔬 ${amount} науч. центр${amount === 1 ? '' : 'ов'}`,
  },
  factory: {
    aliases: ['завод', 'factory'],
    needsAmount: true,
    unit: 'заводов',
    autoTitle: (amount) => `🏭 ${amount} завод${amount === 1 ? '' : 'ов'}`,
  },
  vip_days: {
    aliases: ['вип', 'vip'],
    needsAmount: true,
    unit: 'дней VIP',
    autoTitle: (amount) => `👑 VIP на ${amount} дней`,
  },
  miner_days: {
    aliases: ['майнер', 'miner'],
    needsAmount: true,
    unit: 'дней майнера',
    autoTitle: (amount) => `⛏️ Майнер на ${amount} дней`,
  },
  miner_forever: {
    aliases: ['майнернавсегда', 'майнер_навсегда', 'minerforever'],
    needsAmount: false,
    maxQtyPerPurchase: 1,
    autoTitle: () => `⛏️ Майнер НАВСЕГДА`,
  },
  superrobot_level: {
    aliases: ['суперробот', 'superrobot'],
    needsAmount: true,
    unit: 'ур. суперробота',
    autoTitle: (amount) => `🤖 Суперробот +${amount} ур.`,
  },
  business_slot: {
    aliases: ['слот', 'бизнесслот', 'slot'],
    needsAmount: true,
    unit: 'доп. слотов бизнеса',
    autoTitle: (amount) => `🏢 +${amount} слот${amount === 1 ? '' : 'а'} бизнеса`,
  },
  donate_business_slot: {
    aliases: ['донатслот', 'donateslot'],
    needsAmount: true,
    unit: 'доп. слотов донат-бизнеса',
    autoTitle: (amount) => `🏢 +${amount} слот${amount === 1 ? '' : 'а'} донат-бизнеса`,
  },
};

function findRewardType(arg) {
  const lower = (arg || '').toLowerCase();
  const id = Object.keys(REWARD_TYPES).find(
    (key) => key === lower || REWARD_TYPES[key].aliases.includes(lower)
  );
  return id || null;
}

// Дефолтные 3 товара (как было раньше) — используются, пока админ не настроил свои через
// "!админ ивентприз", и возвращаются обратно командой "!админ ивентприз сброс".
function defaultItems() {
  return [
    { key: 'factory', title: '🏭 Завод', price: C.EVENT_SHOP_PRICE_FACTORY, rewardType: 'factory', amount: 1 },
    { key: 'science', title: '🔬 Научный центр', price: C.EVENT_SHOP_PRICE_SCIENCE, rewardType: 'science', amount: 1 },
    {
      key: 'vip',
      title: `👑 VIP на ${C.EVENT_SHOP_PRICE_VIP_DAYS} дней`,
      price: C.EVENT_SHOP_PRICE_VIP,
      rewardType: 'vip_days',
      amount: C.EVENT_SHOP_PRICE_VIP_DAYS,
    },
  ];
}

async function getShopItems() {
  const raw = await gameMeta.getMeta(META_SHOP_ITEMS);
  if (!raw) return defaultItems();
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length ? parsed : defaultItems();
  } catch {
    return defaultItems();
  }
}

async function saveShopItems(items) {
  await gameMeta.setMeta(META_SHOP_ITEMS, JSON.stringify(items));
}

async function resetShopItems() {
  await gameMeta.setMeta(META_SHOP_ITEMS, '');
  return defaultItems();
}

// Добавляет новый товар либо обновляет существующий с тем же key (регистронезависимо).
// rewardTypeArg — строка из REWARD_TYPES.aliases (или сам id). title опционален — если не
// передан, генерируется автоматически из rewardType+amount (см. REWARD_TYPES[...].autoTitle).
async function upsertShopItem({ key, price, rewardTypeArg, amount, title }) {
  const rewardType = findRewardType(rewardTypeArg);
  if (!rewardType) return { ok: false, reason: 'unknown_reward_type' };

  const def = REWARD_TYPES[rewardType];
  const finalAmount = def.needsAmount ? Math.max(1, parseInt(amount, 10) || 0) : 1;
  if (def.needsAmount && !finalAmount) return { ok: false, reason: 'invalid_amount' };
  if (!Number.isInteger(price) || price <= 0) return { ok: false, reason: 'invalid_price' };

  const finalTitle = title || def.autoTitle(finalAmount);
  const normalizedKey = key.toLowerCase();

  const items = await getShopItems();
  const idx = items.findIndex((i) => i.key.toLowerCase() === normalizedKey);
  const newItem = { key: normalizedKey, title: finalTitle, price, rewardType, amount: finalAmount };
  if (def.maxQtyPerPurchase) newItem.maxQtyPerPurchase = def.maxQtyPerPurchase;

  if (idx >= 0) items[idx] = newItem;
  else items.push(newItem);

  await saveShopItems(items);
  return { ok: true, item: newItem, updated: idx >= 0 };
}

async function removeShopItem(key) {
  const items = await getShopItems();
  const normalizedKey = (key || '').toLowerCase();
  const filtered = items.filter((i) => i.key.toLowerCase() !== normalizedKey);
  if (filtered.length === items.length) return { ok: false, reason: 'not_found' };
  await saveShopItems(filtered);
  return { ok: true };
}

async function findShopItem(arg) {
  const lower = (arg || '').toLowerCase();
  const items = await getShopItems();
  return items.find((i) => i.key.toLowerCase() === lower) || null;
}

// Применяет награду товара игроку. Возвращает { ok, ...extra } — extra зависит от rewardType
// (vipUntil/minerUntil/level/slots), чтобы хендлер мог показать игроку осмысленный ответ.
async function applyReward(vkId, player, item, qty) {
  const total = item.amount * qty;

  switch (item.rewardType) {
    case 'factory': {
      const maxFactories = calc.currentFactoryLimit(player.factory_limit_level);
      if (player.factories + total > maxFactories) {
        return { ok: false, reason: 'factory_limit', max: maxFactories, have: player.factories };
      }
      await players.addFactories(vkId, total, false);
      return { ok: true };
    }
    case 'science': {
      const limit = calc.currentScienceLimit(player.science_limit_level);
      if ((player.science_centers || 0) + total > limit) {
        return { ok: false, reason: 'science_limit', max: limit, have: player.science_centers || 0 };
      }
      await players.addScienceCenters(vkId, total);
      return { ok: true };
    }
    case 'vip_days': {
      const now = new Date();
      const currentUntil = player.vip_until && new Date(player.vip_until) > now ? new Date(player.vip_until) : now;
      const newUntil = new Date(currentUntil.getTime() + total * 24 * 60 * 60 * 1000);
      await players.setVipUntil(vkId, newUntil);
      return { ok: true, vipUntil: newUntil };
    }
    case 'miner_days': {
      const now = new Date();
      const currentUntil = player.miner_until && new Date(player.miner_until) > now ? new Date(player.miner_until) : now;
      const newUntil = new Date(currentUntil.getTime() + total * 24 * 60 * 60 * 1000);
      await players.setMinerUntil(vkId, newUntil);
      return { ok: true, minerUntil: newUntil };
    }
    case 'miner_forever': {
      const newUntil = new Date(Date.now() + C.MINER_FOREVER_YEARS * 365 * 24 * 60 * 60 * 1000);
      await players.setMinerUntil(vkId, newUntil);
      return { ok: true, minerUntil: newUntil, forever: true };
    }
    case 'superrobot_level': {
      const current = player.super_robot_level || 0;
      if (current >= C.SUPER_ROBOT_MAX_LEVEL) return { ok: false, reason: 'superrobot_max', max: C.SUPER_ROBOT_MAX_LEVEL };
      const newLevel = Math.min(current + total, C.SUPER_ROBOT_MAX_LEVEL);
      await players.setSuperRobotLevel(vkId, newLevel);
      return { ok: true, level: newLevel };
    }
    case 'business_slot': {
      const current = Math.min(player.business_extra_slots || 0, C.BUSINESS_MAX_EXTRA_SLOTS);
      if (current >= C.BUSINESS_MAX_EXTRA_SLOTS) return { ok: false, reason: 'slot_limit', max: C.BUSINESS_MAX_EXTRA_SLOTS };
      const newValue = await players.addBusinessExtraSlots(vkId, total);
      return { ok: true, slots: Math.min(newValue, C.BUSINESS_MAX_EXTRA_SLOTS) };
    }
    case 'donate_business_slot': {
      const current = Math.min(player.donate_business_extra_slots || 0, C.DONATE_BUSINESS_MAX_EXTRA_SLOTS);
      if (current >= C.DONATE_BUSINESS_MAX_EXTRA_SLOTS) {
        return { ok: false, reason: 'slot_limit', max: C.DONATE_BUSINESS_MAX_EXTRA_SLOTS };
      }
      const newValue = await players.addDonateBusinessExtraSlots(vkId, total);
      return { ok: true, slots: Math.min(newValue, C.DONATE_BUSINESS_MAX_EXTRA_SLOTS) };
    }
    case 'tokens': {
      await players.addTokens(vkId, total);
      return { ok: true };
    }
    case 'virts': {
      await players.updateBalance(vkId, total);
      return { ok: true };
    }
    default:
      return { ok: false, reason: 'unknown_item' };
  }
}

// Покупка предмета за ивент-валюту. Требует, чтобы магазин был открыт админом
// (см. setShopOpen / !админ ивентмагазин). quantity — сколько штук купить за раз.
async function purchase(vkId, itemArg, quantity = 1) {
  const shopOpen = await isShopOpen();
  if (!shopOpen) return { ok: false, reason: 'shop_closed' };

  const item = await findShopItem(itemArg);
  if (!item) return { ok: false, reason: 'unknown_item' };

  let qty = Math.max(1, Math.floor(quantity) || 1);
  if (item.maxQtyPerPurchase) qty = Math.min(qty, item.maxQtyPerPurchase);
  const totalPrice = item.price * qty;

  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') return { ok: false, reason: 'not_registered' };

  if ((player.event_currency || 0) < totalPrice) {
    return { ok: false, reason: 'not_enough_currency', have: player.event_currency || 0, need: totalPrice };
  }

  const rewardResult = await applyReward(vkId, player, item, qty);
  if (!rewardResult.ok) return rewardResult;

  await players.addEventCurrency(vkId, -totalPrice);

  return { ok: true, item, qty, totalPrice, ...rewardResult };
}

module.exports = {
  getActiveSeason,
  setActiveSeason,
  findSeasonKey,
  awardDrop,
  dropSuffix,
  isShopOpen,
  setShopOpen,
  REWARD_TYPES,
  findRewardType,
  getShopItems,
  saveShopItems,
  resetShopItems,
  upsertShopItem,
  removeShopItem,
  findShopItem,
  purchase,
};
