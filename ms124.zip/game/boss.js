'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const shopDb = require('../db/shop');
const gameDate = require('./gameDate');
const economyScale = require('./economyScale');

// ===================== МИРОВОЙ БОСС =====================
// Общее (не персональное) состояние ивента хранится в game_meta под ключом BOSS_META_KEY
// (тот же принцип, что и флеш-акция в game/donateBuffs.js). Личный дневной лимит ракет —
// в players (см. db/players.js: incrementBossLaunchCount/resetBossLaunchDay).
//
// Босса НЕЛЬЗЯ убить — у него нет HP. Событие идёт, пока админ не завершит его вручную
// (см. finishBoss), после чего всем участникам выдаются награды и статистика сбрасывается
// для следующего запуска.

async function readState() {
  const raw = await shopDb.getMeta(C.BOSS_META_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

async function writeState(state) {
  await shopDb.setMeta(C.BOSS_META_KEY, JSON.stringify(state));
}

async function getState() {
  return readState();
}

async function isActive() {
  const state = await readState();
  return !!(state && state.active);
}

// Запускает нового босса — обнуляет статистику предыдущего забега.
async function startBoss() {
  const state = {
    active: true,
    startedAt: new Date().toISOString(),
    totalHits: 0,
    totalMisses: 0,
    totalRocketsFired: 0,
    participants: {}, // vkId -> { hits, misses, fired, spent, earned }
  };
  await writeState(state);
  return state;
}

function ensureParticipant(state, vkId) {
  const key = String(vkId);
  if (!state.participants[key]) {
    state.participants[key] = { hits: 0, misses: 0, fired: 0, spent: 0, earned: 0 };
  }
  return state.participants[key];
}

async function ensureDayReset(player) {
  const today = gameDate.todayStr();
  const storedDay = player.boss_launch_day ? String(player.boss_launch_day).slice(0, 10) : null;
  if (storedDay !== today) {
    await players.resetBossLaunchDay(player.vk_id, today);
    player.boss_launch_count_today = 0;
    player.boss_launch_day = today;
  }
  return player;
}

// При промахе босс забирает 1 научный центр ИЛИ 1 завод — с проверкой, что у игрока вообще
// есть что забрать, и не опускаясь ниже порогов защиты новичков. Случайно выбираем, что
// пробовать забрать первым, чтобы не был всегда предсказуемо один и тот же ресурс.
async function applyMissPenalty(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player) return { type: 'none' };

  const canTakeScience = (player.science_centers || 0) > C.BOSS_MISS_PENALTY_MIN_SCIENCE;
  const canTakeFactory = (player.factories || 0) > C.BOSS_MISS_PENALTY_MIN_FACTORIES;

  if (!canTakeScience && !canTakeFactory) {
    return { type: 'none' };
  }

  // Если доступно и то, и то — рандомим порядок; если доступно только одно — берём его.
  const preferScienceFirst = Math.random() < 0.5;
  const order = preferScienceFirst ? ['science', 'factory'] : ['factory', 'science'];

  for (const kind of order) {
    if (kind === 'science' && canTakeScience) {
      await players.decrementScienceCenters(vkId, 1);
      return { type: 'science' };
    }
    if (kind === 'factory' && canTakeFactory) {
      await players.destroyOneFactory(vkId);
      return { type: 'factory' };
    }
  }

  return { type: 'none' };
}

// Покупает и запускает пачку ракет "Орешник" по боссу. requestedCount автоматически
// урезается до того, что игрок может себе позволить и что у него осталось в дневном лимите —
// функция никогда не роняет запрос целиком из-за нехватки чего-то одного, а честно
// сообщает, сколько реально было выпущено.
async function launchRockets(vkId, requestedCount) {
  const active = await isActive();
  if (!active) return { ok: false, reason: 'no_boss' };

  let player = await players.getPlayer(vkId);
  if (!player) return { ok: false, reason: 'not_registered' };
  player = await ensureDayReset(player);

  const dailyLeft = Math.max(0, C.BOSS_MAX_ROCKETS_PER_DAY - (player.boss_launch_count_today || 0));
  if (dailyLeft <= 0) {
    return { ok: false, reason: 'daily_limit', dailyLimitToday: C.BOSS_MAX_ROCKETS_PER_DAY };
  }

  let count = Math.min(requestedCount, dailyLeft);

  const affordable = Math.floor((player.balance || 0) / C.BOSS_ROCKET_PRICE);
  if (affordable <= 0) {
    return { ok: false, reason: 'insufficient_balance' };
  }
  count = Math.min(count, affordable);

  if (count <= 0) return { ok: false, reason: 'nothing_to_fire' };

  const cost = count * C.BOSS_ROCKET_PRICE;
  await players.updateBalance(vkId, -cost);
  await players.incrementBossLaunchCount(vkId, count, gameDate.todayStr());

  const doubled = calc.isBossDoubleActive(player);

  let hits = 0;
  let misses = 0;
  let earned = 0;
  const penalties = { science: 0, factory: 0 };

  for (let i = 0; i < count; i++) {
    if (Math.random() < C.BOSS_HIT_CHANCE) {
      hits++;
      let reward = calc.randomInt(C.BOSS_HIT_REWARD_MIN, C.BOSS_HIT_REWARD_MAX);
      if (doubled) reward *= 2;
      earned += reward;
      await players.updateBalance(vkId, reward);
    } else {
      misses++;
      const penalty = await applyMissPenalty(vkId);
      if (penalty.type === 'science') penalties.science++;
      else if (penalty.type === 'factory') penalties.factory++;
    }
  }

  // Обновляем общее состояние ивента (счётчики + личный вклад игрока в топ урона).
  const state = (await readState()) || (await startBoss());
  const p = ensureParticipant(state, vkId);
  p.hits += hits;
  p.misses += misses;
  p.fired += count;
  p.spent += cost;
  p.earned += earned;
  state.totalHits += hits;
  state.totalMisses += misses;
  state.totalRocketsFired += count;
  await writeState(state);

  const capped = requestedCount > count;

  return {
    ok: true,
    fired: count,
    requestedCount,
    capped,
    cost,
    hits,
    misses,
    earned,
    doubled,
    penalties,
    dailyLeft: dailyLeft - count,
  };
}

// Топ участников по числу попаданий — для статуса/финала.
function topParticipants(state, limit = 10) {
  return Object.entries(state.participants || {})
    .map(([vkId, p]) => ({ vkId: Number(vkId), ...p }))
    .sort((a, b) => b.hits - a.hits)
    .slice(0, limit);
}

// Завершает ивент: выдаёт всем участникам награду (флэт за участие + бонус топ-3 по
// попаданиям), гасит состояние (active=false), но оставляет статистику доступной для
// последнего отчёта админу до следующего !админ босс старт.
async function finishBoss() {
  const state = await readState();
  if (!state || !state.active) return { ok: false, reason: 'no_boss' };

  const ranked = topParticipants(state, state.participants ? Object.keys(state.participants).length : 0);
  const rewards = [];

  for (let i = 0; i < ranked.length; i++) {
    const entry = ranked[i];
    if (entry.fired <= 0) continue;
    const topBonus = economyScale.reward(C.BOSS_FINISH_TOP_BONUS[i] || 0);
    const totalBonus = economyScale.reward(C.BOSS_FINISH_PARTICIPATION_BONUS) + topBonus;
    await players.updateBalance(entry.vkId, totalBonus);
    rewards.push({ vkId: entry.vkId, hits: entry.hits, fired: entry.fired, bonus: totalBonus, place: i + 1 });
  }

  state.active = false;
  state.finishedAt = new Date().toISOString();
  await writeState(state);

  return {
    ok: true,
    totalHits: state.totalHits,
    totalMisses: state.totalMisses,
    totalRocketsFired: state.totalRocketsFired,
    participantsCount: ranked.length,
    rewards,
  };
}

module.exports = {
  getState,
  isActive,
  startBoss,
  launchRockets,
  finishBoss,
  topParticipants,
};
