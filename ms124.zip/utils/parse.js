'use strict';

// Разбирает упоминание вида [id123|Имя] или @id123 или просто числовой id
function extractMentionId(token) {
  if (!token) return null;
  const bracketMatch = token.match(/\[id(\d+)\|[^\]]*\]/);
  if (bracketMatch) return Number(bracketMatch[1]);
  const atMatch = token.match(/^@?(?:id)?(\d+)$/);
  if (atMatch) return Number(atMatch[1]);
  return null;
}

// Ищет первое упоминание/id в тексте сообщения (или в массиве fwd/reply, обрабатывается отдельно)
function findMentionInText(text) {
  const bracketMatch = text.match(/\[id(\d+)\|[^\]]*\]/);
  if (bracketMatch) return Number(bracketMatch[1]);
  return null;
}

// Разбирает ссылку на профиль ВК вида:
// https://vk.com/id123456, vk.com/id123456, m.vk.com/id123456, vk.com/durov (короткое имя)
// Возвращает "id123456" (числовой id как строка) или короткое имя ("durov") без резолва —
// сам резолв короткого имени в числовой id делается отдельно через VK API (нужен доступ к боту).
function extractVkLinkPart(text) {
  if (!text) return null;
  const match = text.match(/(?:https?:\/\/)?(?:www\.|m\.)?vk\.(?:com|ru)\/([a-zA-Z0-9_.]+)/i);
  if (!match) return null;
  return match[1];
}

function splitArgs(text) {
  return text.trim().split(/\s+/).filter(Boolean);
}

module.exports = { extractMentionId, findMentionInText, extractVkLinkPart, splitArgs };
