'use strict';

// ПОЛНОСТЬЮ САМОСТОЯТЕЛЬНЫЙ скрипт (не требует остальных файлов проекта, только
// пакеты pg и dotenv, которые уже стоят у вас, раз бот работает).
//
// Передаёт лидерство клана "MUX" со старого (забаненного в VK) аккаунта на
// новый (альтернативный) аккаунт того же игрока.
//
// ═══════════════════════════════════════════════════════════════════════════
// КАК ЗАПУСТИТЬ В TERMUX:
//   1. Положите этот файл в корень проекта бота (туда же, где лежит .env) —
//      либо просто в папку с ботом рядом с node_modules, не важно, где именно,
//      главное чтобы файл .env со строкой DATABASE_URL=... был в ТЕКУЩЕЙ
//      папке при запуске, либо на уровень выше.
//   2. cd в папку бота (там, где .env), затем:
//        node transfer-clan-leader.js
//   3. Готово. Скрипт сам подключится к вашей БД (данные для подключения
//      берутся из .env — я их не знаю и не могу вписать сюда, это ваш пароль
//      от БД, ему тут не место).
// ═══════════════════════════════════════════════════════════════════════════
//
// Что делает:
//   1. Находит клан "MUX".
//   2. Проверяет, что клан реально возглавляет OLD_LEADER_VK_ID (693918943).
//   3. Проверяет, что NEW_LEADER_VK_ID (1068200906) зарегистрирован в игре
//      и либо не состоит ни в каком клане, либо уже состоит именно в этом.
//   4. Одной транзакцией: новый аккаунт становится лидером клана, а старый —
//      исключается из клана (см. флаг KICK_OLD_LEADER ниже, если нужно иначе).

require('dotenv').config();

const { Pool, types } = require('pg');

// Отключаем автопарсинг DATE в JS Date (та же настройка, что и в самом боте,
// db/pool.js) — здесь это не критично, но для единообразия оставляю как есть.
types.setTypeParser(1082, (value) => value);

if (!process.env.DATABASE_URL) {
  console.error(
    'Не найден DATABASE_URL в переменных окружения. Убедитесь, что рядом со скриптом (или на уровень выше) ' +
      'лежит .env с строкой DATABASE_URL=... — тот же файл, который использует сам бот.'
  );
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

// ─── Ваши данные ────────────────────────────────────────────────────────────
const CLAN_NAME = 'MUX';
const OLD_LEADER_VK_ID = 693918943; // забаненный в VK аккаунт (текущий лидер)
const NEW_LEADER_VK_ID = 1068200906; // новый (альтернативный) аккаунт

// true  — старый аккаунт полностью убирается из клана (clan_id/clan_role = NULL)
// false — старый аккаунт остаётся в клане обычным участником ('member')
const KICK_OLD_LEADER = true;
// ────────────────────────────────────────────────────────────────────────────

async function main() {
  console.log(`Клан: «${CLAN_NAME}», перенос лидерки: ${OLD_LEADER_VK_ID} -> ${NEW_LEADER_VK_ID}`);

  const clanRes = await pool.query('SELECT * FROM clans WHERE LOWER(name) = LOWER($1)', [CLAN_NAME]);
  const clan = clanRes.rows[0];
  if (!clan) {
    throw new Error(`Клан «${CLAN_NAME}» не найден.`);
  }

  const oldLeaderRes = await pool.query('SELECT * FROM players WHERE vk_id = $1', [OLD_LEADER_VK_ID]);
  const oldLeader = oldLeaderRes.rows[0];
  if (!oldLeader) {
    throw new Error(`Игрок ${OLD_LEADER_VK_ID} не найден в БД.`);
  }
  if (oldLeader.clan_id !== clan.id || oldLeader.clan_role !== 'leader') {
    throw new Error(
      `Игрок ${OLD_LEADER_VK_ID} не является лидером клана «${CLAN_NAME}» ` +
        `(clan_id=${oldLeader.clan_id}, clan_role=${oldLeader.clan_role}). Останавливаюсь на всякий случай — ` +
        `проверьте вручную, кто сейчас реальный лидер клана, прежде чем перезапускать.`
    );
  }

  const newLeaderRes = await pool.query('SELECT * FROM players WHERE vk_id = $1', [NEW_LEADER_VK_ID]);
  const newLeader = newLeaderRes.rows[0];
  if (!newLeader) {
    throw new Error(
      `Игрок ${NEW_LEADER_VK_ID} не найден в БД — второй аккаунт должен быть зарегистрирован в боте ` +
        `(написать !старт в сообщения группы с этого аккаунта) перед переносом лидерки.`
    );
  }
  if (newLeader.clan_id && newLeader.clan_id !== clan.id) {
    throw new Error(
      `Игрок ${NEW_LEADER_VK_ID} уже состоит в другом клане (clan_id=${newLeader.clan_id}). ` +
        `Сначала выведите его оттуда (команда "!клан выйти" с этого аккаунта) и запустите скрипт заново.`
    );
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Новый лидер: вступает в клан (если ещё не состоял) и получает роль лидера.
    await client.query('UPDATE players SET clan_id = $2, clan_role = $3 WHERE vk_id = $1', [
      NEW_LEADER_VK_ID,
      clan.id,
      'leader',
    ]);
    await client.query('UPDATE clans SET leader_id = $2 WHERE id = $1', [clan.id, NEW_LEADER_VK_ID]);

    // Старый лидер: убираем из клана или понижаем до участника — см. KICK_OLD_LEADER.
    if (KICK_OLD_LEADER) {
      await client.query('UPDATE players SET clan_id = $2, clan_role = $3 WHERE vk_id = $1', [
        OLD_LEADER_VK_ID,
        null,
        null,
      ]);
    } else {
      await client.query('UPDATE players SET clan_id = $2, clan_role = $3 WHERE vk_id = $1', [
        OLD_LEADER_VK_ID,
        clan.id,
        'member',
      ]);
    }

    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }

  console.log('Готово.');
  console.log(`Новый лидер клана «${CLAN_NAME}»: ${NEW_LEADER_VK_ID} (${newLeader.state_name || 'без имени'})`);
  console.log(
    KICK_OLD_LEADER
      ? `Старый аккаунт ${OLD_LEADER_VK_ID} исключён из клана.`
      : `Старый аккаунт ${OLD_LEADER_VK_ID} понижен до обычного участника клана.`
  );
}

main()
  .catch((err) => {
    console.error('Ошибка:', err.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    await pool.end();
  });
