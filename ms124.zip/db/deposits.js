'use strict';

const { query } = require('./pool');

async function createDeposit(playerId, amount, termDays, profitPercent, maturesAt) {
  const res = await query(
    `INSERT INTO deposits (player_id, amount, term_days, profit_percent, matures_at)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`,
    [playerId, amount, termDays, profitPercent, maturesAt]
  );
  return res.rows[0];
}

async function getActiveDepositsByPlayer(playerId) {
  const res = await query(
    `SELECT * FROM deposits WHERE player_id = $1 AND status = 'active' ORDER BY created_at ASC`,
    [playerId]
  );
  return res.rows;
}

async function countActiveDeposits(playerId) {
  const res = await query(
    `SELECT COUNT(*)::int AS count FROM deposits WHERE player_id = $1 AND status = 'active'`,
    [playerId]
  );
  return res.rows[0] ? res.rows[0].count : 0;
}

async function getDepositById(id) {
  const res = await query('SELECT * FROM deposits WHERE id = $1', [id]);
  return res.rows[0] || null;
}

// Закрывает депозит (выплата по сроку или досрочное снятие) — переводит в конечный
// статус атомарно, только если он всё ещё 'active' (защита от двойной выплаты, если
// плановый тик и ручное снятие пересекутся по времени).
async function closeDeposit(id, status, payout) {
  const res = await query(
    `UPDATE deposits SET status = $2, payout = $3, closed_at = NOW()
     WHERE id = $1 AND status = 'active'
     RETURNING *`,
    [id, status, payout]
  );
  return res.rows[0] || null;
}

// Депозиты, у которых срок уже наступил, но игрок ещё не получал уведомление об этом
// (см. game/deposits.js: processMaturedDeposits — теперь по сроку депозит НЕ выплачивается
// автоматически, только уведомление; сама выплата происходит по ручному "депозит собрать").
async function getUnnotifiedMaturedDeposits() {
  const res = await query(
    `SELECT * FROM deposits WHERE status = 'active' AND matures_at <= NOW() AND matured_notified_at IS NULL`
  );
  return res.rows;
}

// Атомарно помечает депозит как "уведомление отправлено" — только если он всё ещё активен
// и ещё не был помечен (защита от повторной отправки, если планировщик пересечётся сам с
// собой по времени). Возвращает обновлённую строку или null, если помечать было нечего.
async function markMaturedNotified(id) {
  const res = await query(
    `UPDATE deposits SET matured_notified_at = NOW()
     WHERE id = $1 AND status = 'active' AND matured_notified_at IS NULL
     RETURNING *`,
    [id]
  );
  return res.rows[0] || null;
}

// Пользовательское название вклада. name = null снимает название.
async function renameDeposit(id, name) {
  const res = await query(`UPDATE deposits SET name = $2 WHERE id = $1 RETURNING *`, [id, name]);
  return res.rows[0] || null;
}

// Топ игроков по деньгам, фактически снятым/полученным с депозитов (сумма payout закрытых
// вкладов). Засчитываются только вклады, "пролежавшие" от открытия до закрытия минимум
// minHoldHours часов (см. game/constants.js: DEPOSIT_TOP_MIN_HOLD_HOURS) — отсекает
// накрутку топа открытием и немедленным досрочным снятием вкладов.
async function getTopByDepositPayout(limit = 10, minHoldHours = 24) {
  const res = await query(
    `SELECT p.*, COALESCE(SUM(d.payout), 0)::bigint AS deposit_total
     FROM players p
     JOIN deposits d ON d.player_id = p.vk_id
     WHERE d.status IN ('paid', 'withdrawn')
       AND d.payout IS NOT NULL
       AND d.closed_at - d.created_at >= make_interval(hours => $2)
     GROUP BY p.vk_id
     HAVING COALESCE(SUM(d.payout), 0) > 0
     ORDER BY deposit_total DESC
     LIMIT $1`,
    [limit, minHoldHours]
  );
  return res.rows;
}

module.exports = {
  createDeposit,
  getActiveDepositsByPlayer,
  countActiveDeposits,
  getDepositById,
  closeDeposit,
  getUnnotifiedMaturedDeposits,
  markMaturedNotified,
  renameDeposit,
  getTopByDepositPayout,
};
