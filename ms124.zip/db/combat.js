'use strict';

const { query } = require('./pool');

async function createAttack(attackerId, defenderId, weapon, quantity, distanceKm, arrivalAt, peerId) {
  const res = await query(
    `INSERT INTO attacks_in_flight (attacker_id, defender_id, weapon, quantity, distance_km, arrival_at, peer_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
    [attackerId, defenderId, weapon, quantity, distanceKm, arrivalAt, peerId || null]
  );
  return res.rows[0];
}

async function getDueAttacks() {
  const res = await query(
    `SELECT * FROM attacks_in_flight WHERE resolved = FALSE AND arrival_at <= NOW()`
  );
  return res.rows;
}

async function getAllPendingAttacks() {
  const res = await query(`SELECT * FROM attacks_in_flight WHERE resolved = FALSE`);
  return res.rows;
}

async function markAttackResolved(id) {
  await query('UPDATE attacks_in_flight SET resolved = TRUE WHERE id = $1', [id]);
}

// Для ограничения на связанные (мульти) аккаунты: сколько РАЗНЫХ attacker_id из
// переданного списка атаковали defenderId за последние windowMs миллисекунд.
// Считаем по launched_at, а не только по resolved-атакам — блокировать нужно уже
// в момент запуска, не дожидаясь прилёта.
async function getDistinctAttackersInWindow(attackerIds, defenderId, windowMs) {
  if (!attackerIds || attackerIds.length === 0) return [];
  const res = await query(
    `SELECT DISTINCT attacker_id FROM attacks_in_flight
     WHERE defender_id = $1
       AND attacker_id = ANY($2)
       AND launched_at >= NOW() - ($3 || ' milliseconds')::interval`,
    [defenderId, attackerIds, windowMs]
  );
  return res.rows.map((r) => Number(r.attacker_id));
}

async function setCooldown(attackerId, defenderId) {
  await query(
    `INSERT INTO attack_cooldowns (attacker_id, defender_id, last_attack_at)
     VALUES ($1, $2, NOW())
     ON CONFLICT (attacker_id, defender_id) DO UPDATE SET last_attack_at = NOW()`,
    [attackerId, defenderId]
  );
}

async function getCooldown(attackerId, defenderId) {
  const res = await query(
    'SELECT last_attack_at FROM attack_cooldowns WHERE attacker_id = $1 AND defender_id = $2',
    [attackerId, defenderId]
  );
  return res.rows[0] ? res.rows[0].last_attack_at : null;
}

module.exports = {
  createAttack,
  getDueAttacks,
  getAllPendingAttacks,
  markAttackResolved,
  setCooldown,
  getCooldown,
  getDistinctAttackersInWindow,
};
