'use strict';

const { query } = require('./pool');

// Пытается ЗАФИКСИРОВАТЬ заявку на бонус за конкретный пост атомарно — если пара
// (vk_id, post_id) уже есть, ON CONFLICT DO NOTHING просто ничего не вставит и вернёт
// пустой rowCount. Так вызывающий код (game/commentFarm.js) узнаёт "выдавали уже или
// нет" ОДНИМ запросом, без отдельного SELECT перед INSERT — это исключает гонку между
// двумя почти одновременными комментариями "фарм" от одного игрока под одним постом
// (например, если VK Long Poll вдруг продублирует событие).
async function tryClaim(vkId, postId) {
  const res = await query(
    'INSERT INTO comment_farm_claims (vk_id, post_id) VALUES ($1, $2) ON CONFLICT (vk_id, post_id) DO NOTHING',
    [vkId, postId]
  );
  return res.rowCount > 0;
}

module.exports = { tryClaim };
