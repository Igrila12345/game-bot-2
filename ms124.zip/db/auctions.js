'use strict';

const { query } = require('./pool');

async function createAuction(sellerId, itemType, itemName, quantity, startPrice, minStep, endTime) {
  const res = await query(
    `INSERT INTO auctions (seller_id, item_type, item_name, quantity, start_price, min_step, end_time)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING *`,
    [sellerId, itemType, itemName, quantity, startPrice, minStep, endTime]
  );
  return res.rows[0];
}

// Лот-стиль: то же самое, но с привязкой к конкретной записи в player_styles (см. game/auction.js:
// createStyleLot). item_name — просто человекочитаемая метка ('Фото-стиль'/'Видео-стиль').
async function createStyleAuction(sellerId, itemName, styleId, startPrice, minStep, endTime) {
  const res = await query(
    `INSERT INTO auctions (seller_id, item_type, item_name, quantity, start_price, min_step, end_time, style_id)
     VALUES ($1, 'style', $2, 1, $3, $4, $5, $6)
     RETURNING *`,
    [sellerId, itemName, startPrice, minStep, endTime, styleId]
  );
  return res.rows[0];
}

async function getActiveAuctions(limit = 15) {
  const res = await query(
    `SELECT * FROM auctions WHERE status = 'active' ORDER BY end_time ASC LIMIT $1`,
    [limit]
  );
  return res.rows;
}

async function getAuctionById(id) {
  const res = await query('SELECT * FROM auctions WHERE id = $1', [id]);
  return res.rows[0] || null;
}

async function getMyLots(sellerId) {
  const res = await query(
    `SELECT * FROM auctions WHERE seller_id = $1 ORDER BY created_at DESC LIMIT 20`,
    [sellerId]
  );
  return res.rows;
}

async function placeBid(id, bidderId, amount, newEndTime) {
  const res = await query(
    `UPDATE auctions SET current_bid = $2, current_bidder_id = $3, end_time = $4 WHERE id = $1 RETURNING *`,
    [id, amount, bidderId, newEndTime]
  );
  return res.rows[0];
}

async function setStatus(id, status) {
  await query('UPDATE auctions SET status = $2 WHERE id = $1', [id, status]);
}

async function getDueAuctions() {
  const res = await query(
    `SELECT * FROM auctions WHERE status = 'active' AND end_time <= NOW()`
  );
  return res.rows;
}

module.exports = {
  createAuction,
  createStyleAuction,
  getActiveAuctions,
  getAuctionById,
  getMyLots,
  placeBid,
  setStatus,
  getDueAuctions,
};
