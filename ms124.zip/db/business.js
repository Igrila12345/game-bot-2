'use strict';

const { query } = require('./pool');

async function getBusinessesByPlayer(playerId) {
  const res = await query(
    `SELECT * FROM player_businesses WHERE player_id = $1 ORDER BY id ASC`,
    [playerId]
  );
  return res.rows;
}

async function countByPlayer(playerId) {
  const res = await query(
    `SELECT COUNT(*)::int AS count FROM player_businesses WHERE player_id = $1`,
    [playerId]
  );
  return res.rows[0].count;
}

async function getBusinessById(id) {
  const res = await query(`SELECT * FROM player_businesses WHERE id = $1`, [id]);
  return res.rows[0] || null;
}

// Возвращает бизнес по id, только если он принадлежит playerId (защита от чужих id в командах)
async function getOwnedBusiness(playerId, id) {
  const res = await query(
    `SELECT * FROM player_businesses WHERE id = $1 AND player_id = $2`,
    [id, playerId]
  );
  return res.rows[0] || null;
}

async function createBusiness(playerId, businessTypeId, stockUntil) {
  const res = await query(
    `INSERT INTO player_businesses (player_id, business_type_id, level, accrued_balance, since_at, stock_until)
     VALUES ($1, $2, 1, 0, NOW(), $3) RETURNING *`,
    [playerId, businessTypeId, stockUntil]
  );
  return res.rows[0];
}

async function deleteBusiness(id) {
  await query(`DELETE FROM player_businesses WHERE id = $1`, [id]);
}

// Сохраняет "расчёт" (settle) — накопленный доход, точку отсчёта, и опционально уровень/сырьё/учёт 4 уровня
async function updateBusiness(id, fields) {
  const sets = [];
  const values = [];
  let i = 1;

  const map = {
    level: 'level',
    accruedBalance: 'accrued_balance',
    sinceAt: 'since_at',
    stockUntil: 'stock_until',
    graceUntil: 'grace_until',
    level4SinceAt: 'level4_since_at',
  };

  for (const [key, column] of Object.entries(map)) {
    if (Object.prototype.hasOwnProperty.call(fields, key)) {
      sets.push(`${column} = $${i}`);
      values.push(fields[key]);
      i += 1;
    }
  }

  if (!sets.length) return getBusinessById(id);

  values.push(id);
  const res = await query(
    `UPDATE player_businesses SET ${sets.join(', ')} WHERE id = $${i} RETURNING *`,
    values
  );
  return res.rows[0];
}

// Все бизнесы, у которых сырьё кончилось и льготный период истёк — кандидаты на удаление
// (см. game/business.js: processDecay). Считаем НАПРЯМУЮ от stock_until + graceHours, а не от
// поля grace_until — оно проставляется только лениво при следующем settle() игрока, и если
// игрок не заходил в игру вообще, grace_until мог бы никогда не появиться.
async function getExpiredGrace(graceHours) {
  const res = await query(
    `SELECT * FROM player_businesses WHERE stock_until <= NOW() - ($1 || ' hours')::interval`,
    [graceHours]
  );
  return res.rows;
}

module.exports = {
  getBusinessesByPlayer,
  countByPlayer,
  getBusinessById,
  getOwnedBusiness,
  createBusiness,
  deleteBusiness,
  updateBusiness,
  getExpiredGrace,
};
