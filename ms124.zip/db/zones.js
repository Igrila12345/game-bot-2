'use strict';

const { query } = require('./pool');

// ===================== СОСТОЯНИЕ ЗОН (владелец/защита) =====================

async function getAllZoneStates() {
  const res = await query('SELECT * FROM clan_zones');
  return res.rows;
}

async function getZoneState(zoneId) {
  const res = await query('SELECT * FROM clan_zones WHERE zone_id = $1', [zoneId]);
  return res.rows[0] || null;
}

// Гарантирует, что для зоны есть строка состояния (первое обращение — зона нейтральная)
async function ensureZoneRow(zoneId) {
  await query('INSERT INTO clan_zones (zone_id) VALUES ($1) ON CONFLICT (zone_id) DO NOTHING', [zoneId]);
}

async function setZoneOwner(zoneId, clanId, protectedUntil) {
  await query(
    `UPDATE clan_zones SET owner_clan_id = $2, captured_at = NOW(), protected_until = $3 WHERE zone_id = $1`,
    [zoneId, clanId, protectedUntil]
  );
}

async function setZoneBonusOverride(zoneId, bonusOrNull) {
  await ensureZoneRow(zoneId);
  await query('UPDATE clan_zones SET bonus_override = $2 WHERE zone_id = $1', [zoneId, bonusOrNull]);
}

// Все зоны, которыми сейчас владеет клан (для бонуса к доходу)
async function getZonesOwnedByClan(clanId) {
  const res = await query('SELECT * FROM clan_zones WHERE owner_clan_id = $1', [clanId]);
  return res.rows;
}

// ===================== СТАВКИ ТЕКУЩЕГО ЦИКЛА =====================

async function addStake(zoneId, clanId, amount) {
  const res = await query(
    `INSERT INTO clan_zone_stakes (zone_id, clan_id, amount, updated_at)
     VALUES ($1, $2, $3, NOW())
     ON CONFLICT (zone_id, clan_id) DO UPDATE SET amount = clan_zone_stakes.amount + $3, updated_at = NOW()
     RETURNING amount`,
    [zoneId, clanId, amount]
  );
  return res.rows[0].amount;
}

async function getStakesForZone(zoneId) {
  const res = await query(
    `SELECT s.*, c.name AS clan_name FROM clan_zone_stakes s
     JOIN clans c ON c.id = s.clan_id
     WHERE s.zone_id = $1 ORDER BY s.amount DESC`,
    [zoneId]
  );
  return res.rows;
}

async function getAllStakes() {
  const res = await query(
    `SELECT s.*, c.name AS clan_name FROM clan_zone_stakes s
     JOIN clans c ON c.id = s.clan_id
     ORDER BY s.zone_id, s.amount DESC`
  );
  return res.rows;
}

async function clearStakesForZone(zoneId) {
  await query('DELETE FROM clan_zone_stakes WHERE zone_id = $1', [zoneId]);
}

// ===================== ДОНАТ-БУСТ =====================

async function getBoost(clanId) {
  const res = await query('SELECT * FROM clan_zone_boosts WHERE clan_id = $1', [clanId]);
  return res.rows[0] || null;
}

async function setBoost(clanId, multiplier, boostUntil) {
  await query(
    `INSERT INTO clan_zone_boosts (clan_id, multiplier, boost_until) VALUES ($1, $2, $3)
     ON CONFLICT (clan_id) DO UPDATE SET multiplier = $2, boost_until = $3`,
    [clanId, multiplier, boostUntil]
  );
}

// ===================== ИСТОРИЯ =====================

async function logCapture(zoneId, clanId, amount) {
  await query('INSERT INTO clan_zone_history (zone_id, clan_id, amount) VALUES ($1, $2, $3)', [
    zoneId,
    clanId,
    amount,
  ]);
}

async function getRecentHistory(limit = 15) {
  const res = await query(
    `SELECT h.*, c.name AS clan_name FROM clan_zone_history h
     LEFT JOIN clans c ON c.id = h.clan_id
     ORDER BY h.captured_at DESC LIMIT $1`,
    [limit]
  );
  return res.rows;
}

module.exports = {
  getAllZoneStates,
  getZoneState,
  ensureZoneRow,
  setZoneOwner,
  setZoneBonusOverride,
  getZonesOwnedByClan,
  addStake,
  getStakesForZone,
  getAllStakes,
  clearStakesForZone,
  getBoost,
  setBoost,
  logCapture,
  getRecentHistory,
};
