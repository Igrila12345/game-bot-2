'use strict';

// ═══════════════════════════════════════════════════════════════════════════
// АВТОПЕРЕНОС ДАННЫХ СО СТАРОЙ БД (Neon) НА НОВУЮ ПРИ СТАРТЕ БОТА
//
// Идея: вы дописываете в .env одну строку — OLD_DATABASE_URL (старый адрес
// Neon), а DATABASE_URL уже указывает на новую локальную базу. Запускаете
// бота как обычно (npm start / pm2) — при старте, ДО открытия для игроков,
// бот сам:
//   1) убеждается, что перенос ещё не выполнялся (по отметке в новой базе);
//   2) убеждается, что новая база пустая (чтобы не задвоить/не затереть
//      уже существующие данные, если перенос уже делали руками);
//   3) снимает дамп старой базы и накатывает его в новую;
//   4) СВЕРЯЕТ количество игроков до и после — если числа не совпали,
//      бот НЕ запускается и НЕ помечает перенос успешным, а печатает, где
//      лежит дамп, чтобы можно было разобраться руками;
//   5) при успехе — ставит отметку в новой базе, чтобы при следующих
//      перезапусках перенос больше не повторялся (и не падал на дублях).
//
// Если OLD_DATABASE_URL не задан — вся эта логика просто пропускается, бот
// стартует как обычно на DATABASE_URL. Это значит, что после первого
// успешного переноса переменную OLD_DATABASE_URL можно (не обязательно)
// убрать из .env — отметка в новой базе и так не даст перенести данные
// повторно.
//
// Ручной способ (pgsetup/02-migrate-data.sh) никуда не делся и продолжает
// работать — это просто автоматизация того же самого сценария.
// ═══════════════════════════════════════════════════════════════════════════

const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function run(cmd, args) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, { maxBuffer: 1024 * 1024 * 512 }, (err, stdout, stderr) => {
      if (err) {
        err.stdout = stdout;
        err.stderr = stderr;
        return reject(err);
      }
      resolve({ stdout, stderr });
    });
  });
}

async function binaryAvailable(bin) {
  try {
    await run(bin, ['--version']);
    return true;
  } catch (_err) {
    return false;
  }
}

function isConnectionError(err) {
  return ['ECONNREFUSED', 'ENOTFOUND', 'ETIMEDOUT'].includes(err && err.code);
}

function isLocalDatabaseUrl(connectionString) {
  if (!connectionString) return false;
  try {
    const { hostname } = new URL(connectionString);
    return hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1';
  } catch (_err) {
    return false;
  }
}

async function withPool(connectionString, fn) {
  const pool = new Pool({
    connectionString,
    ssl: isLocalDatabaseUrl(connectionString) ? false : { rejectUnauthorized: false },
    max: 1,
  });
  try {
    return await fn(pool);
  } finally {
    await pool.end();
  }
}

// Считает игроков. Возвращает 0, если таблицы players ещё нет вообще
// (например, новая база создана только что и абсолютно пустая) — это не
// ошибка, а нормальное состояние "с нуля".
async function countPlayers(connectionString) {
  return withPool(connectionString, async (pool) => {
    const exists = await pool.query(
      "SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'players') AS ok"
    );
    if (!exists.rows[0].ok) return 0;
    const res = await pool.query('SELECT COUNT(*)::int AS c FROM players');
    return res.rows[0].c;
  });
}

async function ensureMigrationStateTable(connectionString) {
  return withPool(connectionString, (pool) =>
    pool.query(`
      CREATE TABLE IF NOT EXISTS _migration_state (
        key TEXT PRIMARY KEY,
        value TEXT,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `)
  );
}

async function getMigrationFlag(connectionString) {
  return withPool(connectionString, async (pool) => {
    const res = await pool.query("SELECT value FROM _migration_state WHERE key = 'migrated_from_old'");
    return res.rows[0] ? res.rows[0].value : null;
  });
}

async function setMigrationFlag(connectionString, value) {
  return withPool(connectionString, (pool) =>
    pool.query(
      `INSERT INTO _migration_state (key, value, updated_at) VALUES ('migrated_from_old', $1, NOW())
       ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`,
      [value]
    )
  );
}

// Новая локальная база может ещё не успеть подняться к моменту старта бота
// (например, оба поднимаются одновременно в докере/systemd). Даём несколько
// попыток именно на ПОДКЛЮЧЕНИЕ, а не на логические ошибки (несовпадение
// количества игроков и т.п. — их ретраить нельзя, это не временный сбой).
async function withConnectRetry(fn, { attempts = 5, delayMs = 3000 } = {}) {
  let lastErr;
  for (let i = 1; i <= attempts; i += 1) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      if (!isConnectionError(err) || i === attempts) throw err;
      console.error(
        `[Migrate] Не удалось подключиться к базе (попытка ${i}/${attempts}), повтор через ${delayMs / 1000} с.`,
        err.message
      );
      await sleep(delayMs);
    }
  }
  throw lastErr;
}

async function autoMigrateFromOldIfConfigured() {
  const oldUrl = process.env.OLD_DATABASE_URL;
  const newUrl = process.env.DATABASE_URL;

  if (!oldUrl) {
    return; // Ничего не настроено — обычный запуск на DATABASE_URL, без переноса.
  }

  console.log('[Migrate] Задан OLD_DATABASE_URL — проверяю, нужен ли автоперенос данных на новую БД.');

  if (!newUrl) {
    throw new Error('[Migrate] OLD_DATABASE_URL задан, а DATABASE_URL (новая база) — нет. Проверьте .env.');
  }
  if (oldUrl.trim() === newUrl.trim()) {
    throw new Error(
      '[Migrate] OLD_DATABASE_URL и DATABASE_URL совпадают — это одна и та же строка подключения. ' +
      'Проверьте .env (похоже, забыли вписать новый адрес).'
    );
  }

  await withConnectRetry(() => ensureMigrationStateTable(newUrl));

  const flag = await getMigrationFlag(newUrl);
  if (flag === 'done') {
    console.log('[Migrate] Перенос уже был выполнен ранее (есть отметка в новой БД) — пропускаю, запуск как обычно.');
    return;
  }

  // Главная защита от порчи данных: если в новой базе УЖЕ есть игроки, но
  // отметки об успешном автопереносе нет — это подозрительно (например,
  // перенос уже делали руками через 02-migrate-data.sh, или DATABASE_URL
  // случайно указывает не туда). НЕ трогаем такую базу автоматически.
  const newCount = await countPlayers(newUrl);
  if (newCount > 0) {
    throw new Error(
      `[Migrate] В новой базе (DATABASE_URL) уже есть игроков: ${newCount}, но отметки об успешном ` +
      'автопереносе нет. Останавливаюсь, чтобы не рискнуть задвоить или перезаписать данные. ' +
      'Если перенос уже сделан (в т.ч. вручную) — просто уберите OLD_DATABASE_URL из .env. ' +
      'Если это неожиданно — проверьте, на ту ли базу указывает DATABASE_URL.'
    );
  }

  const oldCount = await countPlayers(oldUrl);
  console.log(`[Migrate] Игроков в старой базе (OLD_DATABASE_URL): ${oldCount}.`);

  const [hasPgDump, hasPsql] = await Promise.all([binaryAvailable('pg_dump'), binaryAvailable('psql')]);
  if (!hasPgDump || !hasPsql) {
    throw new Error(
      '[Migrate] На сервере не найдены утилиты pg_dump/psql (пакет postgresql-client, ставится вместе с ' +
      'postgresql-contrib в pgsetup/01-install-postgres.sh). Останавливаюсь — без них автоперенос делать ' +
      'небезопасно (бот иначе стартовал бы на пустой новой базе, как будто у игроков всё обнулилось).'
    );
  }

  const backupsDir = path.join(__dirname, '..', 'migration-backups');
  fs.mkdirSync(backupsDir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const dumpFile = path.join(backupsDir, `old_db_dump_${stamp}.sql`);

  console.log(`[Migrate] Снимаю дамп старой базы (это может занять некоторое время)... -> ${dumpFile}`);
  await run('pg_dump', [oldUrl, '--no-owner', '--no-privileges', '-f', dumpFile]);
  console.log(`[Migrate] Дамп снят (${(fs.statSync(dumpFile).size / 1024 / 1024).toFixed(2)} МБ). Загружаю в новую базу...`);

  try {
    await run('psql', [newUrl, '-v', 'ON_ERROR_STOP=1', '-f', dumpFile]);
  } catch (err) {
    throw new Error(
      '[Migrate] Ошибка при загрузке дампа в новую базу: ' +
      `${(err.stderr || err.message || '').toString().slice(-2000)}\n` +
      `Старые данные не потеряны — дамп сохранён тут: ${dumpFile}. Можно разобраться и загрузить вручную: ` +
      `psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "${dumpFile}". Останавливаю бота, не запускаю на неполной базе.`
    );
  }

  const migratedCount = await countPlayers(newUrl);
  console.log(`[Migrate] Игроков в новой базе после переноса: ${migratedCount} (было в старой: ${oldCount}).`);

  if (migratedCount !== oldCount) {
    throw new Error(
      `[Migrate] Количество игроков не совпало после переноса (старая: ${oldCount}, новая: ${migratedCount}). ` +
      `НЕ помечаю перенос успешным и останавливаю бота — не хочу запускать игру на неполных данных. ` +
      `Дамп сохранён: ${dumpFile}. Разберитесь и при необходимости накатите его вручную ` +
      `(см. dampFile выше), затем перезапустите бота.`
    );
  }

  await setMigrationFlag(newUrl, 'done');
  console.log(
    `[Migrate] ✅ Перенос данных завершён успешно: ${migratedCount} игроков перенесено на новую базу. ` +
    `Резервный дамп на всякий случай сохранён тут: ${dumpFile} (не удаляйте его, пока не убедитесь, что ` +
    'всё в игре работает как раньше — балансы, кланы и т.д.). ' +
    'Скопируйте этот файл куда-то ВНЕ сервера (на свой компьютер/облако) — на всякий случай. ' +
    'OLD_DATABASE_URL из .env теперь можно (не обязательно) убрать — повторный автоперенос и так не запустится.'
  );
}

module.exports = { autoMigrateFromOldIfConfigured };
