'use strict';

const { query } = require('./pool');

async function insertHistory(winnerVkId, pot, payout, playersCount) {
  await query(
    'INSERT INTO bank_of_luck_history (winner_vk_id, pot, payout, players_count) VALUES ($1, $2, $3, $4)',
    [winnerVkId, pot, payout, playersCount]
  );
}

// JOIN на players — чтобы взять актуальное текущее имя победителя (state_name может
// меняться после раунда через "переименовать"), а не хранить копию имени на момент выигрыша.
async function getRecentHistory(limit) {
  const res = await query(
    `SELECT h.winner_vk_id, h.pot, h.payout, h.players_count, h.created_at, p.state_name
       FROM bank_of_luck_history h
       LEFT JOIN players p ON p.vk_id = h.winner_vk_id
      ORDER BY h.created_at DESC
      LIMIT $1`,
    [limit]
  );
  return res.rows;
}

module.exports = { insertHistory, getRecentHistory };
