'use strict';

const { query } = require('./pool');

async function countRecentExchanges(vkId, sinceMs) {
  const res = await query(
    `SELECT COUNT(*)::int AS cnt FROM science_exchange_log
     WHERE player_id = $1 AND exchanged_at > NOW() - ($2 || ' milliseconds')::interval`,
    [vkId, sinceMs]
  );
  return res.rows[0] ? res.rows[0].cnt : 0;
}

async function logExchange(vkId) {
  await query('INSERT INTO science_exchange_log (player_id) VALUES ($1)', [vkId]);
}

module.exports = { countRecentExchanges, logExchange };
