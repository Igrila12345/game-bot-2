'use strict';

// HTTP-API казино для мини-приложения VK. Вся игровая логика — прежняя (game/casino.js,
// game/blackjack.js: ставки, RTP, кулдауны, блокировки, запись в БД, админский буст шанса),
// тут только «обёртка»: проверка игрока, приведение результата к JSON и — важно — сокрытие
// закрытой карты дилера, пока раздача не закончена (клиенту её знать нельзя, иначе чит).

const C = require('../game/constants');
const economyScale = require('../game/economyScale');
const players = require('../db/players');
const casinoDb = require('../db/casino');
const blackjackDb = require('../db/blackjack');
const casino = require('../game/casino');
const blackjack = require('../game/blackjack');

const REASON_TEXT = {
  not_registered: 'Сначала создайте государство в боте: напишите !старт',
  banned: 'Аккаунт заблокирован администрацией.',
  already_spinning: 'Барабаны ещё крутятся.',
  already_playing: 'У вас уже есть незакрытая раздача — возьмите карту или остановитесь.',
  no_active_hand: 'Нет активной раздачи. Сделайте ставку, чтобы начать новую.',
  cooldown: 'Слишком часто — подождите немного.',
  bad_bet: 'Введите ставку числом.',
  bet_too_small: `Минимальная ставка — ${C.CASINO_MIN_BET} вирт.`,
  bet_too_big: `Максимальная ставка — ${C.CASINO_MAX_BET} вирт.`,
  not_enough_balance: 'Недостаточно вирт для такой ставки.',
};

function fail(reason, extra) {
  return { ok: false, reason, message: REASON_TEXT[reason] || 'Не удалось выполнить действие. Попробуйте ещё раз.', ...(extra || {}) };
}

function botUrl() {
  const groupId = process.env.VK_GROUP_ID;
  return groupId ? `https://vk.me/club${String(groupId).replace(/^-/, '')}` : null;
}

// Игрок, от имени которого идёт запрос (vkId уже проверен по подписи VK в api/server.js).
async function loadPlayer(vkId) {
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') return { error: fail('not_registered', { botUrl: botUrl() }) };
  if (player.is_banned) return { error: fail('banned') };
  return { player };
}

// Раздача глазами клиента. Пока идёт ход игрока — из карт дилера отдаём только первую.
function blackjackView(r) {
  if (r.phase === 'turn') {
    return {
      phase: 'turn',
      bet: r.bet,
      playerCards: r.playerCards,
      dealerCards: r.dealerCards.slice(0, 1),
      dealerHidden: true,
      playerTotal: r.playerTotal,
      balance: typeof r.balance === 'number' ? r.balance : undefined,
    };
  }
  return {
    phase: 'finished',
    bet: r.bet,
    win: r.win,
    net: r.net,
    outcome: r.outcome,
    playerCards: r.playerCards,
    dealerCards: r.dealerCards,
    playerTotal: r.playerTotal,
    dealerTotal: r.dealerTotal,
    balance: r.balance,
  };
}

function activeHandView(vkId) {
  const hand = blackjack.getHand(vkId);
  if (!hand || hand.finished) return null;
  return blackjackView({
    phase: 'turn',
    bet: hand.bet,
    playerCards: hand.playerCards,
    dealerCards: hand.dealerCards,
    playerTotal: blackjack.handValue(hand.playerCards),
  });
}

function cardsOut(view) {
  // Карты наружу — только rank/suit (без служебного value).
  const strip = (cards) => cards.map((c) => ({ rank: c.rank, suit: c.suit }));
  return { ...view, playerCards: strip(view.playerCards), dealerCards: strip(view.dealerCards) };
}

function statsRow(row, countKey) {
  return {
    games: Number(row[countKey]) || 0,
    totalBet: Number(row.total_bet) || 0,
    totalWin: Number(row.total_win) || 0,
    totalNet: Number(row.total_net) || 0,
    todayBet: Number(row.today_bet) || 0,
    todayWin: Number(row.today_win) || 0,
  };
}

// ===================== ENDPOINTS =====================

async function getState({ vkId }) {
  const { player, error } = await loadPlayer(vkId);
  if (error) return error;

  const [slotStats, bjStats] = await Promise.all([casinoDb.getPlayerStats(vkId), blackjackDb.getPlayerStats(vkId)]);
  return {
    ok: true,
    player: { name: player.state_name, balance: Number(player.balance) },
    config: {
      minBet: C.CASINO_MIN_BET,
      maxBet: C.CASINO_MAX_BET,
      spinMs: C.CASINO_SPIN_MS,
      blackjackNaturalMult: C.BLACKJACK_NATURAL_MULT,
      blackjackTimeoutMin: Math.round(C.BLACKJACK_HAND_TIMEOUT_MS / 60000),
      symbols: C.CASINO_SLOT_SYMBOLS.map((s) => ({ key: s.key, label: s.label, mult: s.threeMult })),
      dailyRewards: C.CASINO_DAILY_REWARDS.map((r) => economyScale.reward(r.virts)),
    },
    cooldowns: {
      slotMs: casino.getSlotCooldownRemainingMs(vkId),
      blackjackMs: blackjack.getStartCooldownRemainingMs(vkId),
    },
    stats: { slots: statsRow(slotStats, 'spins'), blackjack: statsRow(bjStats, 'hands') },
    blackjack: (() => {
      const v = activeHandView(vkId);
      return v ? cardsOut({ ...v, balance: Number(player.balance) }) : null;
    })(),
    botUrl: botUrl(),
  };
}

async function postSlot({ vkId, body }) {
  const { player, error } = await loadPlayer(vkId);
  if (error) return error;

  const result = await casino.spin(vkId, body && body.bet, player);
  if (!result.ok) return fail(result.reason, { cooldownMs: result.cooldownMs, balance: result.balance });

  return {
    ok: true,
    bet: result.bet,
    win: result.win,
    net: result.net,
    matchType: result.matchType,
    symbol: result.symbol ? result.symbol.key : null,
    reels: result.reels.map((s) => s.key),
    balance: result.balance,
    animMs: C.CASINO_SPIN_MS,
    // сколько ещё нельзя запускать следующую партию (кулдаун считается от старта)
    cooldownMs: casino.getSlotCooldownRemainingMs(vkId),
  };
}

async function postBlackjackStart({ vkId, body }) {
  const { player, error } = await loadPlayer(vkId);
  if (error) return error;

  const result = await blackjack.start(vkId, body && body.bet, player);
  if (!result.ok) return fail(result.reason, { cooldownMs: result.cooldownMs, balance: result.balance });
  return { ok: true, hand: cardsOut(blackjackView(result)), cooldownMs: blackjack.getStartCooldownRemainingMs(vkId) };
}

async function postBlackjackHit({ vkId }) {
  const { error } = await loadPlayer(vkId);
  if (error) return error;
  const result = await blackjack.hit(vkId);
  if (!result.ok) return fail(result.reason);
  return { ok: true, hand: cardsOut(blackjackView(result)) };
}

async function postBlackjackStand({ vkId }) {
  const { error } = await loadPlayer(vkId);
  if (error) return error;
  const result = await blackjack.stand(vkId);
  if (!result.ok) return fail(result.reason);
  return { ok: true, hand: cardsOut(blackjackView(result)) };
}

const PERIODS = new Set(['day', 'week', 'month', 'all']);

async function getTop({ vkId, query }) {
  const { error } = await loadPlayer(vkId);
  if (error) return error;

  const game = query.get('game') === 'blackjack' ? 'blackjack' : 'slots';
  const period = PERIODS.has(query.get('period')) ? query.get('period') : 'day';
  const db = game === 'blackjack' ? blackjackDb : casinoDb;

  const rows = await db.getTopWinners(period, 15);
  return {
    ok: true,
    game,
    period,
    // Награда 00:00 МСК выдаётся только за топ слотов за сутки (см. game/casino.js: distributeDailyRewards)
    dailyRewards: game === 'slots' && period === 'day' ? C.CASINO_DAILY_REWARDS.map((r) => economyScale.reward(r.virts)) : null,
    top: rows.map((row, i) => ({
      place: i + 1,
      name: row.state_name,
      totalWin: Number(row.total_win),
      isMe: Number(row.vk_id) === vkId,
    })),
  };
}

module.exports = {
  routes: {
    'GET /api/casino/state': getState,
    'POST /api/casino/slot': postSlot,
    'POST /api/casino/blackjack/start': postBlackjackStart,
    'POST /api/casino/blackjack/hit': postBlackjackHit,
    'POST /api/casino/blackjack/stand': postBlackjackStand,
    'GET /api/casino/top': getTop,
  },
  // для тестов
  _internal: { blackjackView, cardsOut },
};
