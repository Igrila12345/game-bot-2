'use strict';

const crypto = require('crypto');

// Проверка подписи параметров запуска VK Mini Apps
// (https://dev.vk.com/ru/mini-apps/development/launch-params-sign).
//
// VK при открытии мини-приложения добавляет в URL параметры vk_user_id, vk_app_id, vk_ts, ... и sign.
// sign = base64url(HMAC-SHA256(secret, "vk_a=1&vk_b=2&...")), где в строку входят ТОЛЬКО параметры,
// начинающиеся с "vk_", отсортированные по имени, значения — encodeURIComponent.
// secret — «Защищённый ключ» приложения (Настройки приложения → Ключи доступа). Он есть только
// на сервере; клиент подделать подпись не может, поэтому vk_user_id из проверенных параметров
// можно считать личностью игрока.

const MAX_AGE_SEC = 24 * 60 * 60; // запуск старше суток — просим открыть приложение заново

function verifyLaunchParams(rawParams, secret, expectedAppId) {
  if (!rawParams || typeof rawParams !== 'string' || rawParams.length > 4000) return { ok: false, reason: 'no_params' };

  const params = new URLSearchParams(rawParams.startsWith('?') ? rawParams.slice(1) : rawParams);
  const sign = params.get('sign');
  if (!sign) return { ok: false, reason: 'no_sign' };

  const pairs = [];
  for (const [key, value] of params) {
    if (key.startsWith('vk_')) pairs.push([key, value]);
  }
  pairs.sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
  const signedString = pairs.map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');

  const expected = crypto
    .createHmac('sha256', secret)
    .update(signedString)
    .digest('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');

  const a = Buffer.from(expected);
  const b = Buffer.from(sign);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return { ok: false, reason: 'bad_sign' };

  if (expectedAppId && params.get('vk_app_id') !== String(expectedAppId)) return { ok: false, reason: 'wrong_app' };

  const userId = Number(params.get('vk_user_id'));
  if (!Number.isInteger(userId) || userId <= 0) return { ok: false, reason: 'no_user' };

  const ts = Number(params.get('vk_ts'));
  if (!Number.isFinite(ts) || Date.now() / 1000 - ts > MAX_AGE_SEC) return { ok: false, reason: 'expired' };

  return { ok: true, userId };
}

module.exports = { verifyLaunchParams };
