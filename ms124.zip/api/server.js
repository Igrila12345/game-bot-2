'use strict';

// HTTP-сервер мини-приложения «Казино»: раздаёт статику из /miniapp и JSON-API /api/*.
// Без внешних зависимостей (только встроенные http/https/fs/crypto). VK требует https: либо сам
// сервер отдаёт HTTPS по купленному сертификату (MINIAPP_SSL_CERT/KEY), либо перед ним стоит nginx
// (см. deploy/nginx.e-zavodik.ru.conf) и тогда слушаем 127.0.0.1.
//
// Запускается из index.js в том же процессе, что и бот: блокировки и кулдауны игр
// (game/casino.js, game/blackjack.js) живут в памяти процесса, поэтому и бот, и API
// должны работать в одном процессе — иначе состояние раздачи блэкджека было бы не общим.

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { verifyLaunchParams } = require('./vkAuth');
const casinoApi = require('./casinoApi');

const STATIC_ROOT = path.join(__dirname, '..', 'miniapp');
const MAX_BODY_BYTES = 4 * 1024;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
  '.woff2': 'font/woff2',
};

// Простейший лимит частоты запросов на игрока: не больше RATE_MAX за RATE_WINDOW_MS.
// Игровые кулдауны (3 сек на партию) уже защищают экономику; это защита самого сервера.
const RATE_WINDOW_MS = 10 * 1000;
const RATE_MAX = 30;
const rateBuckets = new Map();

function rateLimited(userId) {
  const now = Date.now();
  const bucket = (rateBuckets.get(userId) || []).filter((t) => now - t < RATE_WINDOW_MS);
  bucket.push(now);
  rateBuckets.set(userId, bucket);
  return bucket.length > RATE_MAX;
}

setInterval(() => {
  const now = Date.now();
  for (const [id, bucket] of rateBuckets) {
    if (!bucket.length || now - bucket[bucket.length - 1] > RATE_WINDOW_MS) rateBuckets.delete(id);
  }
}, 60 * 1000).unref();

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(body);
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    let tooLarge = false;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        tooLarge = true;
        return; // дочитываем и выбрасываем, ответ отправим на 'end'
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (tooLarge) return reject(Object.assign(new Error('body_too_large'), { status: 413 }));
      if (!chunks.length) return resolve({});
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        resolve(parsed && typeof parsed === 'object' ? parsed : {});
      } catch {
        reject(Object.assign(new Error('bad_json'), { status: 400 }));
      }
    });
    req.on('error', reject);
  });
}

function serveStatic(req, res, pathname) {
  let rel;
  try {
    rel = decodeURIComponent(pathname);
  } catch {
    res.writeHead(400);
    return res.end('Bad request');
  }
  if (rel === '/' || rel === '') rel = '/index.html';
  const filePath = path.normalize(path.join(STATIC_ROOT, rel));
  // Защита от выхода за пределы папки (../)
  if (filePath !== STATIC_ROOT && !filePath.startsWith(STATIC_ROOT + path.sep)) {
    res.writeHead(403);
    return res.end('Forbidden');
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Not found');
    }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream',
      // Файлы маленькие — не кэшируем, чтобы обновления игры доходили до игроков сразу.
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
    });
    res.end(req.method === 'HEAD' ? undefined : data);
  });
}

function createRequestHandler({ appId, appSecret }) {
  return async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');

      if (!url.pathname.startsWith('/api/')) {
        if (req.method !== 'GET' && req.method !== 'HEAD') {
          res.writeHead(405);
          return res.end();
        }
        return serveStatic(req, res, url.pathname);
      }

      const handler = casinoApi.routes[`${req.method} ${url.pathname}`];
      if (!handler) return sendJson(res, 404, { ok: false, reason: 'not_found' });

      const auth = verifyLaunchParams(req.headers['x-launch-params'], appSecret, appId);
      if (!auth.ok) {
        return sendJson(res, 401, {
          ok: false,
          reason: auth.reason,
          message:
            auth.reason === 'expired'
              ? 'Сессия устарела — закройте и снова откройте приложение.'
              : 'Откройте приложение из VK.',
        });
      }

      if (rateLimited(auth.userId)) {
        return sendJson(res, 429, { ok: false, reason: 'rate_limited', message: 'Слишком много запросов — подождите секунду.' });
      }

      const body = req.method === 'POST' ? await readJsonBody(req) : {};
      const result = await handler({ vkId: auth.userId, query: url.searchParams, body });
      return sendJson(res, 200, result);
    } catch (err) {
      if (err && err.status) return sendJson(res, err.status, { ok: false, reason: err.message });
      console.error('[MiniApp API] Ошибка обработки запроса:', err);
      return sendJson(res, 500, { ok: false, reason: 'server_error', message: 'Ошибка сервера. Попробуйте ещё раз.' });
    }
  };
}

// HTTP-сервер (за nginx) — как раньше.
function createServer(opts) {
  return http.createServer(createRequestHandler(opts));
}

// Запуск. Два режима:
//  • Прямой HTTPS (без nginx) — если в .env заданы MINIAPP_SSL_CERT и MINIAPP_SSL_KEY (пути к файлам
//    купленного сертификата). Тогда слушаем 0.0.0.0:443, а на :80 поднимается редирект на https.
//  • За nginx — как раньше: обычный HTTP на 127.0.0.1:3000, HTTPS делает nginx.
// Возвращает server либо null, если не заданы VK_APP_SECRET / VK_APP_ID (тогда бот просто
// работает без мини-приложения, ничего не ломается).
function startApiServer() {
  const appId = process.env.VK_APP_ID;
  const appSecret = process.env.VK_APP_SECRET;
  if (!appId || !appSecret) {
    console.error('[MiniApp] Не заданы VK_APP_ID и/или VK_APP_SECRET в .env — сервер мини-приложения НЕ запущен.');
    return null;
  }

  const certPath = process.env.MINIAPP_SSL_CERT;
  const keyPath = process.env.MINIAPP_SSL_KEY;

  if (certPath || keyPath) {
    if (!certPath || !keyPath) {
      console.error('[MiniApp] Для HTTPS нужны ОБА параметра: MINIAPP_SSL_CERT и MINIAPP_SSL_KEY. Сервер мини-приложения НЕ запущен.');
      return null;
    }
    let tlsOptions;
    try {
      tlsOptions = { cert: fs.readFileSync(certPath), key: fs.readFileSync(keyPath) };
    } catch (err) {
      console.error(`[MiniApp] Не удалось прочитать файлы сертификата (${certPath}, ${keyPath}): ${err.message}. Сервер мини-приложения НЕ запущен.`);
      return null;
    }

    const httpsPort = Number(process.env.MINIAPP_PORT) || 443;
    const host = process.env.MINIAPP_HOST || '0.0.0.0';
    let server;
    try {
      server = https.createServer(tlsOptions, createRequestHandler({ appId, appSecret }));
    } catch (err) {
      // Например, ключ не подходит к сертификату или файл повреждён.
      console.error(`[MiniApp] Сертификат/ключ не приняты: ${err.message}. Сервер мини-приложения НЕ запущен.`);
      return null;
    }
    server.on('error', (err) => console.error('[MiniApp] Ошибка HTTPS-сервера:', err.message));
    server.listen(httpsPort, host, () => console.log(`[MiniApp] Казино-мини-приложение слушает https://${host}:${httpsPort}`));

    // Редирект http → https (порт 80). Не критично: если порт занят/нет прав — просто пишем в лог.
    const redirectPort = process.env.MINIAPP_HTTP_REDIRECT_PORT === undefined ? 80 : Number(process.env.MINIAPP_HTTP_REDIRECT_PORT);
    if (redirectPort > 0) {
      const redirect = http.createServer((req, res) => {
        const hostHeader = String(req.headers.host || '').replace(/:\d+$/, '');
        res.writeHead(301, { Location: `https://${hostHeader}${req.url}` });
        res.end();
      });
      redirect.on('error', (err) => console.error(`[MiniApp] Редирект http→https на порту ${redirectPort} не запущен: ${err.message}`));
      redirect.listen(redirectPort, host);
    }
    return server;
  }

  const port = Number(process.env.MINIAPP_PORT) || 3000;
  const host = process.env.MINIAPP_HOST || '127.0.0.1';
  const server = createServer({ appId, appSecret });
  server.on('error', (err) => console.error('[MiniApp] Ошибка HTTP-сервера:', err));
  server.listen(port, host, () => console.log(`[MiniApp] Казино-мини-приложение слушает http://${host}:${port}`));
  return server;
}

module.exports = { startApiServer, createServer, createRequestHandler };
