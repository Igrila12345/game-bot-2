'use strict';

const combat = require('./combat');
const combatDb = require('../db/combat');
const calc = require('./calc');
const C = require('./constants');
const msg = require('../utils/messages');

function formatAdSummary(adUsedCounts) {
  const parts = Object.entries(adUsedCounts || {}).map(([key, count]) => `${key} (x${count})`);
  return parts.join(', ');
}

async function resolvePendingAttacks(bot) {
  const due = await combatDb.getDueAttacks();

  for (const attackRecord of due) {
    await combatDb.markAttackResolved(attackRecord.id);

    const result = await combat.resolveAttack(attackRecord);
    if (!result.ok) continue;

    const { attacker, defender, weapon, intercepted, penetrated, quantity, adUsedCounts } = result;
    const attackerLink = msg.mentionLink(attacker.vk_id, attacker.state_name);
    const defenderLink = msg.mentionLink(defender.vk_id, defender.state_name);
    const adSummary = formatAdSummary(adUsedCounts);

    // ===== Волна полностью отражена =====
    if (result.allIntercepted) {
      await bot
        .notifyUser(
          attacker.vk_id,
          `💥 Ваше ${weapon.key} (x${quantity}) полностью сбито ПВО противника (${defenderLink}): ${adSummary}. Потери: ${quantity} шт.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `🎯 Ваше ПВО отразило всю атаку «${attackerLink}»: ${weapon.key} x${quantity} — сбито силами ${adSummary}!`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(attackRecord.peer_id, `🛡️ «${defenderLink}» полностью отразил атаку «${attackerLink}» (${weapon.key} x${quantity})`)
          .catch(() => {});
      }
      continue;
    }

    // ===== Волна прорвалась частично или полностью =====
    // Если ПВО сбило часть партии — сообщаем об этом отдельной строкой перед эффектом атаки.
    const interceptLine =
      intercepted > 0
        ? `🛡️ ПВО сбило ${intercepted} из ${quantity} (${adSummary}), но ${penetrated} прорвалось!\n`
        : '';
    const interceptLineDefender =
      intercepted > 0
        ? `🛡️ Ваше ПВО сбило ${intercepted} из ${quantity} (${adSummary}), но ${penetrated} прорвалось!\n`
        : '';

    const { effectResult, loot } = result;

    if (effectResult.type === 'block') {
      const destroyedLine = effectResult.destroyedCount
        ? `\n💀 Снесено навсегда: ${effectResult.destroyedCount} ${msg.pluralFactories(effectResult.destroyedCount)}!`
        : '';

      await bot
        .notifyUser(
          attacker.vk_id,
          `${interceptLine}🔥 ПРЯМОЕ ПОПАДАНИЕ по городу «${defenderLink}»! Прорвалось ${penetrated} из ${quantity} ${weapon.key}.${destroyedLine} Трофеи: +${loot} вирт.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `${interceptLineDefender}💥 Государство «${attackerLink}» прорвало вашу оборону: ${penetrated} из ${quantity} ${weapon.key} долетело!${destroyedLine}`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `💥 «${attackerLink}» нанёс удар по «${defenderLink}» (${penetrated}/${quantity} прорвалось)${
              effectResult.destroyedCount ? `, снесено ${effectResult.destroyedCount}` : ''
            }`
          )
          .catch(() => {});
      }
    } else if (effectResult.type === 'nuke_strike') {
      // Ядерное оружие: всегда сносит несколько заводов + у некоторых видов есть побочный эффект.
      const destroyedLine = effectResult.destroyedCount
        ? `\n💀 Снесено навсегда: ${effectResult.destroyedCount} ${msg.pluralFactories(effectResult.destroyedCount)}!`
        : '';
      const extraLines =
        (effectResult.radiation ? `\n☢️ + радиация: -20% дохода на 2 часа всем оставшимся заводам.` : '') +
        (effectResult.wipedAirDefense ? `\n🌊 + всё ПВО противника уничтожено!` : '');

      await bot
        .notifyUser(
          attacker.vk_id,
          `${interceptLine}☢️ ЯДЕРНЫЙ УДАР по городу «${defenderLink}»!${destroyedLine}${extraLines} Трофеи: +${loot} вирт.`
        )
        .catch(() => {});

      await bot
        .notifyUser(
          defender.vk_id,
          `${interceptLineDefender}☢️ ЯДЕРНЫЙ УДАР государства «${attackerLink}» по вашему городу!${destroyedLine}${extraLines}`
        )
        .catch(() => {});

      if (attackRecord.peer_id) {
        await bot
          .sendToChat(
            attackRecord.peer_id,
            `☢️ «${attackerLink}» нанёс ядерный удар по «${defenderLink}» (${weapon.key})${
              effectResult.destroyedCount ? `: снесено ${effectResult.destroyedCount} ${msg.pluralFactories(effectResult.destroyedCount)}` : ''
            }${effectResult.wipedAirDefense ? ', ПВО уничтожено' : ''}`
          )
          .catch(() => {});
      }
    }
  }
}

module.exports = { resolvePendingAttacks };
