'use strict';

const C = require('./constants');
const calc = require('./calc');
const players = require('../db/players');
const combatDb = require('../db/combat');
const clans = require('../db/clans');

async function launchAttack(attackerId, defenderId, weaponKey, quantity, peerId) {
  const weapon = C.WEAPONS[weaponKey];
  if (!weapon) return { ok: false, reason: 'unknown_weapon' };

  if (attackerId === defenderId) return { ok: false, reason: 'self_attack' };

  const attacker = await players.getPlayer(attackerId);
  const defender = await players.getPlayer(defenderId);
  if (!attacker || !defender) return { ok: false, reason: 'not_registered' };

  if (defender.factories < C.MIN_FACTORIES_TO_BE_ATTACKED) {
    return { ok: false, reason: 'defender_too_small' };
  }

  const daysSinceLastSeen = (Date.now() - new Date(defender.last_seen).getTime()) / (1000 * 60 * 60 * 24);
  if (daysSinceLastSeen > C.INACTIVITY_ATTACK_BAN_DAYS) {
    return { ok: false, reason: 'defender_inactive' };
  }

  if (quantity <= 0 || quantity > weapon.maxPerAttack) {
    return { ok: false, reason: 'invalid_quantity', max: weapon.maxPerAttack };
  }

  const arsenal = attacker.arsenal || {};
  if ((arsenal[weaponKey] || 0) < quantity) {
    return { ok: false, reason: 'not_enough_weapons', have: arsenal[weaponKey] || 0 };
  }

  // Кулдаун на цель убран по решению баланса: атаковать одну и ту же цель можно
  // сколько угодно раз подряд — единственное ограничение теперь запас оружия
  // в арсенале атакующего. Это открывает волновую тактику: сначала закидать
  // дешёвыми дронами, чтобы истощить ПВО, потом добить дорогим оружием.

  // Вместо кулдауна на цель — общий кулдаун атакующего на запуск оружия данной
  // КАТЕГОРИИ (не зависит от того, кого атакуют): БПЛА — 2 мин, ракеты — 10 мин,
  // ядерное оружие — 1 час. У диверсантов (saboteur) отдельного кулдауна нет.
  const categoryCooldownMs = {
    drone: C.DRONE_LAUNCH_COOLDOWN_MS,
    missile: C.MISSILE_LAUNCH_COOLDOWN_MS,
    nuke: C.NUKE_LAUNCH_COOLDOWN_MS,
  }[weapon.category];
  const categoryLastAttackField = {
    drone: 'last_drone_attack_at',
    missile: 'last_missile_attack_at',
    nuke: 'last_nuke_attack_at',
  }[weapon.category];

  if (categoryCooldownMs && attacker[categoryLastAttackField]) {
    const elapsed = Date.now() - new Date(attacker[categoryLastAttackField]).getTime();
    if (elapsed < categoryCooldownMs) {
      return {
        ok: false,
        reason: 'category_cooldown',
        category: weapon.category,
        remainingMs: categoryCooldownMs - elapsed,
      };
    }
  }

  // Списываем оружие
  arsenal[weaponKey] -= quantity;
  if (arsenal[weaponKey] <= 0) delete arsenal[weaponKey];
  await players.setArsenal(attackerId, arsenal);

  // Расстояние и время полёта
  const distance = calc.distanceKm(attacker.x, attacker.y, defender.x, defender.y);
  let speed = weapon.speedKmh;

  // Клановый бонус "Форсаж" x2 скорости
  if (attacker.clan_id) {
    const clan = await clans.getClanById(attacker.clan_id);
    if (clan && clan.bonus_forsazh_until && new Date(clan.bonus_forsazh_until) > new Date()) {
      speed *= 2;
    }
  }

  const flightHours = distance / speed;
  const arrivalAt = new Date(Date.now() + flightHours * 60 * 60 * 1000);

  const attackRecord = await combatDb.createAttack(
    attackerId,
    defenderId,
    weaponKey,
    quantity,
    distance,
    arrivalAt,
    peerId
  );

  await players.touchLastSeen(attackerId);
  if (categoryLastAttackField) {
    await players.touchCategoryAttack(attackerId, weapon.category);
  }

  return {
    ok: true,
    attackRecord,
    distance,
    flightMs: flightHours * 60 * 60 * 1000,
    attackerId: attacker.vk_id,
    defenderId: defender.vk_id,
    attackerName: attacker.state_name,
    defenderName: defender.state_name,
  };
}

// ===================== РАЗРЕШЕНИЕ АТАКИ: ПВО ПО ЕДИНИЦАМ =====================
// Раньше защита делала ОДИН общий бросок на всю партию оружия (хоть 1 штука, хоть 10) —
// это не позволяло "заваливать" ПВО количеством. Теперь каждая прилетевшая единица
// оружия проверяется на перехват независимо, и на каждый успешный перехват тратится
// своя единица ПВО. Если ПВО закончилось (или его не было), все оставшиеся единицы
// гарантированно долетают — это и есть истощение обороны массой дешёвого оружия.
async function resolveAttack(attackRecord) {
  const weapon = C.WEAPONS[attackRecord.weapon];
  const attacker = await players.getPlayer(attackRecord.attacker_id);
  const defender = await players.getPlayer(attackRecord.defender_id);

  if (!attacker || !defender) {
    return { ok: false, reason: 'player_missing' };
  }

  const quantity = attackRecord.quantity;
  const airDefense = defender.air_defense || {};

  // Клановый бонус "Эшелон" +20% точности ПВО
  let chanceMultiplier = 1;
  if (defender.clan_id) {
    const clan = await clans.getClanById(defender.clan_id);
    if (clan && clan.bonus_eshelon_until && new Date(clan.bonus_eshelon_until) > new Date()) {
      chanceMultiplier = 1.2;
    }
  }

  // Скилл защитника: бонус к шансу перехвата ПВО за количество заводов
  const defenderSkill = calc.getSkillTier(defender.factories);
  const skillBonus = defenderSkill ? defenderSkill.airDefenseBonus : 0;

  let intercepted = 0;
  let penetrated = 0;
  const adUsedCounts = {}; // сколько раз какой комплекс ПВО реально сбил цель
  let airDefenseChanged = false;

  for (let i = 0; i < quantity; i++) {
    const candidates = Object.entries(airDefense).filter(
      ([key, qty]) => qty > 0 && C.AIR_DEFENSE[key] && C.AIR_DEFENSE[key].covers.includes(weapon.category)
    );

    if (!candidates.length) {
      // ПВО, способного сбить этот тип оружия, у защитника не осталось — единица долетает
      penetrated += 1;
      continue;
    }

    const [adKey] = candidates[Math.floor(Math.random() * candidates.length)];
    const chance = Math.min(C.AIR_DEFENSE[adKey].chance * chanceMultiplier + skillBonus, 1);

    if (Math.random() < chance) {
      intercepted += 1;
      adUsedCounts[adKey] = (adUsedCounts[adKey] || 0) + 1;
      // ПВО расходуется только при успешном перехвате
      airDefense[adKey] -= 1;
      if (airDefense[adKey] <= 0) delete airDefense[adKey];
      airDefenseChanged = true;
    } else {
      penetrated += 1;
    }
  }

  if (airDefenseChanged) {
    await players.setAirDefense(defender.vk_id, airDefense);
  }

  if (penetrated === 0) {
    // Вся партия сбита — ничего не прорвалось
    return {
      ok: true,
      allIntercepted: true,
      intercepted,
      penetrated,
      quantity,
      adUsedCounts,
      attacker,
      defender,
      weapon,
    };
  }

  // Хотя бы часть оружия прорвалась — эффект применяется по числу прорвавшихся единиц
  const effectResult = await applyWeaponEffect(defender, weapon, penetrated, attacker);

  // Трофеи атакующему (начисляются, если хотя бы одна единица долетела)
  const calc_ = require('./calc');
  const productionDb = require('../db/production');
  const factoriesInProd = await productionDb.getFactoriesInUse(defender.vk_id);
  const defenderIncome = calc_.incomePerHour(await players.getPlayer(defender.vk_id), factoriesInProd);
  let loot = Math.round(defenderIncome * C.LOOT_RATE);
  loot = Math.max(C.LOOT_MIN, Math.min(C.LOOT_MAX, loot));
  await players.updateBalance(attacker.vk_id, loot);

  return {
    ok: true,
    allIntercepted: false,
    intercepted,
    penetrated,
    quantity,
    adUsedCounts,
    attacker,
    defender,
    weapon,
    effectResult,
    loot,
  };
}

// Скилл атакующего (SKILL_TIERS.damageBonus) даёт множитель к урону — общий для всего оружия.
function getAttackerDamageMultiplier(attacker) {
  if (!attacker) return 1;
  const attackerSkill = calc.getSkillTier(attacker.factories);
  return attackerSkill ? 1 + attackerSkill.damageBonus : 1;
}

// Сносит N заводов у defender, по одному, останавливаясь на пороге защиты новичков.
// Возвращает фактическое число снесённых заводов (может быть меньше запрошенного).
async function destroyFactories(defenderVkId, count) {
  let destroyedCount = 0;
  for (let i = 0; i < count; i++) {
    const current = await players.getPlayer(defenderVkId);
    if (current.factories <= C.NEWBIE_PROTECTION_FACTORIES) break;
    await players.destroyOneFactory(defenderVkId);
    destroyedCount += 1;
  }
  return destroyedCount;
}

async function applyWeaponEffect(defender, weapon, quantity, attacker) {
  const player = await players.getPlayer(defender.vk_id);
  const damageMultiplier = getAttackerDamageMultiplier(attacker);

  if (weapon.effect === 'block_random') {
    // ===== Урон по заводам противника (окончательный снос, без временной блокировки) =====
    let destroyedCount = 0;

    if (weapon.factoriesPerHit) {
      // Сильное оружие: КАЖДОЕ попадание сразу сносит несколько заводов (без накопления урона).
      const perHit = Math.max(1, Math.round(weapon.factoriesPerHit * damageMultiplier));
      destroyedCount = await destroyFactories(defender.vk_id, perHit * quantity);
    } else if (weapon.hitsToDestroy) {
      // Слабое/среднее оружие: нужно накопить несколько попаданий, чтобы снести 1 завод.
      // Каждое попадание даёт (FACTORY_HP_UNIT / hitsToDestroy) единиц урона.
      const baseDamagePerHit = Math.floor(C.FACTORY_HP_UNIT / weapon.hitsToDestroy);
      const damagePerHit = Math.round(baseDamagePerHit * damageMultiplier);

      let accumulated = (player.factory_damage || 0) + damagePerHit * quantity;
      while (accumulated >= C.FACTORY_HP_UNIT) {
        const current = await players.getPlayer(defender.vk_id);
        if (current.factories <= C.NEWBIE_PROTECTION_FACTORIES) break;
        await players.destroyOneFactory(defender.vk_id);
        destroyedCount += 1;
        accumulated -= C.FACTORY_HP_UNIT;
      }
      await players.setFactoryDamage(defender.vk_id, accumulated);
    }

    if (destroyedCount > 0 && attacker) {
      await players.incrementEnemyFactoriesDestroyed(attacker.vk_id, destroyedCount);
    }

    return { type: 'block', count: quantity, destroyedCount };
  }

  if (weapon.effect === 'nuke_strike') {
    // ===== Ядерное оружие: всегда сносит несколько заводов за удар (мощнее любой ракеты), =====
    // ===== плюс у каждого вида — свой уникальный побочный эффект.                          =====
    const perHit = Math.max(1, Math.round((weapon.factoriesPerHit || 1) * damageMultiplier));
    const destroyedCount = await destroyFactories(defender.vk_id, perHit * quantity);

    if (destroyedCount > 0 && attacker) {
      await players.incrementEnemyFactoriesDestroyed(attacker.vk_id, destroyedCount);
    }

    let radiation = false;
    if (weapon.radiation) {
      const radiationUntil = new Date(Date.now() + C.RADIATION_DURATION_MS);
      await players.setRadiationUntil(defender.vk_id, radiationUntil);
      radiation = true;
    }

    let wipedAirDefense = false;
    if (weapon.wipeAirDefense) {
      await players.setAirDefense(defender.vk_id, {});
      wipedAirDefense = true;
    }

    return { type: 'nuke_strike', destroyedCount, radiation, wipedAirDefense };
  }

  return { type: 'none' };
}

module.exports = {
  launchAttack,
  resolveAttack,
  applyWeaponEffect,
};
