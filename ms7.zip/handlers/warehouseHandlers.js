'use strict';

const players = require('../db/players');
const warehouse = require('../game/warehouse');
const calc = require('../game/calc');
const C = require('../game/constants');
const msg = require('../utils/messages');

async function handleShow(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const boxes = Array.from({ length: C.WAREHOUSE_BOX_COUNT }, (_, i) => i + 1).join(' | ');

  await ctx.send(
    `📦 ВОЕННЫЙ СКЛАД — кейс (цена: ${C.WAREHOUSE_COST_TOKENS} жетонов)\n` +
      `+---+---+---+---+---+\n| ${boxes} |\n+---+---+---+---+---+\n` +
      `🪙 Ваши жетоны: ${player.tokens || 0}\n\n` +
      `${msg.warehouseRewardsMessage()}\n\n` +
      `Введите номер коробки: выбрать [номер]\n` +
      `Либо обменяйте жетоны напрямую на завод: обменять (${C.EXCHANGE_FACTORY_COST_TOKENS} жетонов = 1 завод)`
  );
}

// Показывает только содержимое кейса и шансы, без открытия (команда "кейс шансы")
async function handleRewardsInfo(ctx) {
  await ctx.send(msg.warehouseRewardsMessage());
}

const REWARD_LABELS = {
  virts: (qty) => `💰 ${calc.formatNumber(qty)} вирт`,
  factory: () => `🏭 Бесплатный завод (+1)`,
};

async function handleSelect(ctx, boxArg) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const boxNumber = parseInt(boxArg, 10);
  const result = await warehouse.openBox(vkId, boxNumber);

  if (!result.ok) {
    if (result.reason === 'invalid_box') {
      await ctx.send(`⛔ Выберите номер коробки от 1 до ${C.WAREHOUSE_BOX_COUNT}: выбрать [номер]`);
    } else if (result.reason === 'not_enough_tokens') {
      await ctx.send(`⛔ Недостаточно жетонов. Не хватает ${result.missing}. Заработать: работа`);
    } else {
      await ctx.send('⛔ Не удалось открыть коробку.');
    }
    return;
  }

  const { reward, qty } = result;
  let rewardText;
  if (REWARD_LABELS[reward.type]) {
    rewardText = REWARD_LABELS[reward.type](qty);
  } else {
    rewardText = `${reward.key} x${qty}`;
  }

  await ctx.send(`📦 Коробка №${boxNumber} открыта!\n🎁 Вы получили: ${rewardText}`);
}

// Прямой обмен жетонов на завод без рандома
async function handleExchangeFactory(ctx) {
  const vkId = ctx.senderId;
  const player = await players.getPlayer(vkId);
  if (!player || player.registration_step !== 'done') {
    await ctx.send('⛔ Вы ещё не зарегистрированы. Напишите старт');
    return;
  }

  const result = await warehouse.exchangeForFactory(vkId);

  if (!result.ok) {
    if (result.reason === 'not_enough_tokens') {
      await ctx.send(
        `⛔ Недостаточно жетонов. Нужно ${C.EXCHANGE_FACTORY_COST_TOKENS}, не хватает ${result.missing}. Заработать: работа`
      );
    } else {
      await ctx.send('⛔ Не удалось обменять жетоны.');
    }
    return;
  }

  await ctx.send(
    `✅ Обмен выполнен! Списано ${C.EXCHANGE_FACTORY_COST_TOKENS} жетонов, получен 🏭 1 завод.\n` +
      `Осталось жетонов: ${result.remainingTokens}`
  );
}

module.exports = { handleShow, handleSelect, handleExchangeFactory, handleRewardsInfo };
